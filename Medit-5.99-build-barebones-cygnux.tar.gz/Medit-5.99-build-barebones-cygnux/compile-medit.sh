if [ -z "${1}" ]
then
	echo "version-number parameter missing"
	echo "Usage: ${0} <version>"
	exit
fi

cc -s cc-64bit-or-32bit.c -o cc-64bit-or-32bit
if [ -x cc-64bit-or-32bit ]
then
	BITS=$(./cc-64bit-or-32bit)
	rm -f cc-64bit-or-32bit
else
	echo "Cannot determine if CC is 64bit or 32bit"
	exit
fi

rm -f medit*.o

if [ "$(uname | grep -ci cygwin)" = 1 ] 
then
	cc -DBITS$BITS -DCYGWIN -s -O1 medit-${1}.c term-5.xx.c *.o -o med-${1} -lcurses
elif [ "$(uname | grep -ci linux)" = 1 ] 
then
	cc -DBITS$BITS -s -O1 medit-${1}.c term-5.xx.c *.o -o med-${1} -lcurses
elif [ "$(uname | grep -ci sunos)" = 1 ] 
then
	cc -DBITS$BITS -DSUNOS -s -O1 medit-${1}.c term-5.xx.c *.o -o med-${1} -lcurses
else
	echo "Cannot determin O.S. type"
fi

