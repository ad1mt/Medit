cc -s -c -O1 chartables.c*
cc -s -c -O1 pcre_compile.c
cc -s -c -O1 pcre_config.c
cc -s -c -O1 pcre_dfa_exec.c
cc -s -c -O1 pcre_exec.c
cc -s -c -O1 pcre_fullinfo.c
cc -s -c -O1 pcre_get.c
cc -s -c -O1 pcre_globals.c
cc -s -c -O1 pcre_info.c
cc -s -c -O1 pcre_maketables.c
cc -s -c -O1 pcre_ord2utf8.c
cc -s -c -O1 pcre_refcount.c
cc -s -c -O1 pcre_study.c
cc -s -c -O1 pcre_tables.c
cc -s -c -O1 pcre_try_flipped.c
cc -s -c -O1 pcre_ucp_searchfuncs.c
cc -s -c -O1 pcre_valid_utf8.c
cc -s -c -O1 pcre_version.c
cc -s -c -O1 pcre_xclass.c
### cc -s -c -O1 pcredemo.c
### cc -s -c -O1 pcregrep.c
### cc -s -c -O1 pcreposix.c
### cc -s -c -O1 pcretest.c
### cc -s -c -O1 ucptable.c
