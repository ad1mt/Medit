
./clean-medit.sh ${1}
cd pcre-6.7-barebones
./clean-pcre.sh
cd ..

