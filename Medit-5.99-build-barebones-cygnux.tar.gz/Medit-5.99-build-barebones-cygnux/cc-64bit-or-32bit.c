#include<stdio.h>
#include<stdlib.h>
void main()
{
int*p;
printf("%d\n",(int)(sizeof(p)*8));
}

