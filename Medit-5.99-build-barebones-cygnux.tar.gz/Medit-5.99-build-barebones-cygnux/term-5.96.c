/*****************************************************************************
TERM.C
------------------------------------------------------------------------------
Medit - Terminal handling module.

Amendment History:
------------------
6.1.2001   v5.45 1. Cygwin version.
                 2. Ambiguity: tcsetattr or fcntl for setting non_blocking
                    term IO ?
                 3. Bug fix: act on return value from read() in x_getch()
                    instead of ignoring it.
                 4. Refer to fileno(stdin) rather than 0, ditto stdout.
10.7.2003 5.49   1. Fixed unavailable ^S ^Q ^O ^V.
                 2. Made setup_term more posix portable.
8.3.2007  5.50   1. if unable to get ccflag_vdisable then use hard-coded
                    default of zero.
2009.4.24 5.xx   1. make cygwin colours match current unix colour scheme.
2009.5.1  5.xx   1. make replace-query colour more visible.
2023.3.17 5.92   1. fix warnings
*****************************************************************************/
#include "medit-5.xx.h"

#ifndef MSDOS
/* #include <termios.h> */
#include <unistd.h>
#include <fcntl.h>

#ifdef CYGWIN
#include <ncurses/term.h>
#else
#include <curses.h>
#include <term.h>
#endif

#endif

#ifdef MSDOS
#include <bios.h>
#include <conio.h>
#include <time.h>
#include <sys/exceptn.h>
#endif

int rows = 0;
int kb_blocking;
int kb_delay = 100;
int kb_buffer_i = 0;
int kb_buffer_end = 0;
int stdin_descriptor;
int stdout_descriptor;
int stdin_fcntl_flags;
long ccflag_vdisable;

unsigned char kb_buffer[SCR_BUFFER_LEN];

#ifndef MSDOS
static struct termios old_term;
static struct termios new_term;
#endif

/**************************/
void flush_scr_buffer()
{
#ifndef MSDOS
if (scr_buffer_i > 0)
  temp_error = write(stdout_descriptor,scr_buffer,scr_buffer_i);
scr_buffer_i =0;
#endif
;
}

/**************************/
void x_buffch(unsigned int c)
{
#ifndef MSDOS

if (!macexec)
  {
  scr_buffer[scr_buffer_i] = (unsigned char) c;
  scr_buffer_i += 1;
  if (scr_buffer_i >= SCR_BUFFER_LEN)
    flush_scr_buffer();
  }

#else
if (!macexec)
  {
  putch(c);
  }
#endif
}

#ifdef MSDOS
/**************************/
int getkey()
{
return getch();
}
#endif


/**************************/
int x_getch()
{
int c,i,j;
unsigned char x;

#ifndef MSDOS
flush_scr_buffer();
#endif

if (kb_buffer_i == kb_buffer_end)
  {
  kb_buffer_i = 0;
  kb_buffer_end = 0;
#ifndef MSDOS
  i = (read(stdin_descriptor, &kb_buffer, SCR_BUFFER_LEN));
  if (i > 0) kb_buffer_end = i;
#else
  if (kb_blocking)
    {
    do
      {
      c = getkey();

      if (c == 0)
        {
        c = getkey();
        c = c+100;
        }

      /* this converts the code returned for the
         '|' key to the correct ascii value */
      if (c == 221)
        c = 124;

      kb_buffer[kb_buffer_end] = c;
      kb_buffer_end++;
      } while (  (kb_buffer_end < SCR_BUFFER_LEN)
              && (_bios_keybrd(_KEYBRD_READY) != 0)
              );
    }
  else
    {
        
/* This section of code is not for correct execution of program,
   but to make the MSDOS version behave more like the Unix version,
   in respect to keyboard reading, so that status lines bugs & glitches
   can be seen more easily.
*/

      if (  (kb_delay != 0)
         && (!macexec)
         )
        {
        i = 0;
        j = 10;
        while (  (i < j)
              && (!_bios_keybrd(_KEYBRD_READY))
              )
          {
          delay(kb_delay);
          i++;
          }
        }

/* end of delay code */

      while (  (kb_buffer_end < SCR_BUFFER_LEN)
            && (_bios_keybrd(_KEYBRD_READY))
            )
        {
        c = getkey();
        if (c == 0)
          {
          c = getkey();
          c = c+100;
          }
        kb_buffer[kb_buffer_end] = c;
        kb_buffer_end++;
        }
    }
#endif

  }

if (SCR_BUFFER_LEN == kb_buffer_end)
  kb_buffer_end = SCR_BUFFER_LEN-1;

if (kb_buffer_i != kb_buffer_end)
  {
  c = (int) kb_buffer[kb_buffer_i];

#ifdef CYGWIN

  if (c == 166)
    c = 124;

#endif

  kb_buffer_i += 1;
  if (c == 0)
    c = KB_ERR;
  }
else
  c = KB_ERR;

return c;
}

#ifdef SUNOS
/*********************************/
int writechar(char c)
{
unsigned int x;

x = c;
x_buffch(x);
return 0;
}
#else
/*********************************/
int writechar(int c)
{
unsigned int x;

x = c;
x_buffch(x);
return 0;
}
#endif



/*********************************/
int get_key_str(unsigned char * p,char k[])
{
#ifndef MSDOS
unsigned char * cp;

cp = (unsigned char *) tigetstr(k);
if (  (cp == (unsigned char *) 0)
   || (cp == (unsigned char *) -1)
   )
  {
  strcpy((char *)p,"");
  return FALSE;
  }
else
  {
  strncpy((char *)p,(char *)cp,SCREENMAX-1);
  return TRUE;
  }
#else
  return FALSE;
#endif
;
}

/*************************/
void set_raw()
{
#ifndef MSDOS
new_term.c_iflag = new_term.c_iflag & ~IXON & ~BRKINT;
new_term.c_lflag = new_term.c_lflag & ~ECHO & ~ICANON & ~ISIG & ~IEXTEN;
new_term.c_cc[VSTART] = ccflag_vdisable;
new_term.c_cc[VSTOP] = ccflag_vdisable;

if (tcsetattr(stdin_descriptor,TCSANOW,&new_term))
  {
  fprintf(stderr,"\nUnable to setup terminal - tcsetattr() failed.\n");
  exit(1);
  }
kb_blocking = TRUE;

#else

__djgpp_set_ctrl_c(FALSE);

#endif
}

/*************************/
void unset_term()
{
#ifndef MSDOS

#ifdef CYGWIN
  tputs(tparm(set_a_foreground,WHITE),1,writechar);
  tputs(tparm(set_a_background,BLACK),1,writechar);
#endif

#ifdef SUNOS
  tputs(exit_attribute_mode,1,(int (*)(char))writechar);
#else
  tputs(exit_attribute_mode,1,writechar);
#endif

if (tcsetattr(stdin_descriptor,TCSANOW,&old_term))
  fprintf(stderr,"Unable to reset initial terminal characteristics.\n");
#else
    __djgpp_set_ctrl_c(TRUE);
    textcolor(WHITE);
    textbackground(BLACK);
    putch(' ');                      
#endif
}

/*********************************/
void setup_term()
{
#ifndef MSDOS
int err;
char * t;

t = (char *) getenv("TERM");
setupterm( t, 1, (int *) &err );
if (err != 1)
  {
  sprintf(errortext,"Terminal type \"%s\" is unknown.\n",t);
  fprintf(stderr,"%s",errortext);
  exit(1);
  }

stdin_descriptor = fileno(stdin);
stdout_descriptor = fileno(stdout);

if ( (ccflag_vdisable = fpathconf(stdin_descriptor,_PC_VDISABLE)) < 0)
  {
  ccflag_vdisable = 0;

#ifndef CYGWIN
  fprintf(stderr,"\nWARNING: Unable to get ccflag vdisable value.\n");
  fprintf(stderr,"WARNING: using default vdisable value of zero.\n");
  temp_error = system("sleep 4");
#endif
  }

if (tcgetattr(stdin_descriptor,&old_term))
  {
  fprintf(stderr,"\nUnable to get initial terminal characteristics.\n");
  exit(1);
  }

new_term = old_term;

if ((stdin_fcntl_flags = fcntl(stdin_descriptor,F_GETFL,0)) == -1)
  {
  fprintf(stderr,"\nUnable to get initial stdin fcntl flags.\n");
  exit(1);
  }

set_raw();

#ifdef CYGWIN
tputs(enter_bold_mode,1,writechar);
#endif

#else

int i,j;
int len;
char copyright[]="Medit loading...";
char buffer[160];

set_raw();
/* textcolor(CYAN); */

clrscr();

len = strlen(copyright);
gotoxy(1,1);
printf("%s",copyright);
strcpy(buffer,copyright);

while (  (strcmp(copyright,buffer) == STR_SAME)
      && (rows < 200)
      )
  {
  printf("\n");
  rows += 1;
  gettext(1,1,80,1,buffer);

  i = 2; j = 1;
  while (i < (len * 2))
    {
    buffer[j] = buffer[i];
    i += 2;
    j += 1;
    }
  buffer[j] = '\0';

  }
#endif
}

/**************************/
void non_block_kb(int delay)
{
#ifndef MSDOS

if (kb_blocking)
  {

#ifdef CYGWIN

  stdin_fcntl_flags |= O_NONBLOCK;
  if (fcntl(stdin_descriptor,F_SETFL,stdin_fcntl_flags) == -1)
    fprintf(stderr,"Unable to setup non-blocking kb input: fcntl() failed.");
  else
    kb_blocking = FALSE;

#else

  new_term.c_cc[VMIN] = 0;
  new_term.c_cc[VTIME] = delay;

  if (tcsetattr(stdin_descriptor,TCSANOW,&new_term))
    fprintf(stderr,"Unable to setup non-blocking kb input: tcsetattr() failed.");
  else
    kb_blocking = FALSE;

#endif

  }

#else
kb_blocking = FALSE;
kb_delay = (delay+1)*10;
#endif
}

/*************************/
void block_kb()
{
#ifndef MSDOS

if (!kb_blocking)
  {

#ifdef CYGWIN

  stdin_fcntl_flags &= ~O_NONBLOCK;
  if (fcntl(stdin_descriptor,F_SETFL,stdin_fcntl_flags) == -1)
    fprintf(stderr,"Unable to setup blocking kb input: fcntl() failed.");
  else
    kb_blocking = TRUE;

#else

  new_term.c_cc[VMIN] = 1;
  new_term.c_cc[VTIME] = 0;

  if (tcsetattr(stdin_descriptor,TCSANOW,&new_term))
    fprintf(stderr,"Unable to setup blocking kb input: tcsetattr() failed.");
  else
    kb_blocking = TRUE;

#endif

  }

#else
kb_blocking = TRUE;
#endif
}

/*********************************/
int getCOLS()
{
#ifndef MSDOS
int i;
i = tigetnum("cols");
return i;
#else
return 80;
#endif
}

/*********************************/
int getLINES()
{
#ifndef MSDOS
int i;
i = tigetnum("lines");
return i;
#else
return rows;
#endif
}

/*********************************/
void enter_ca()
{
#ifndef MSDOS

  #ifdef SUNOS
    tputs(enter_ca_mode,1,(int (*)(char))writechar);
  #else
    tputs(enter_ca_mode,1,writechar);
  #endif

#endif
;
}

/*********************************/
void exit_ca()
{
#ifndef MSDOS
  #ifdef SUNOS
    tputs(exit_ca_mode,1,(int (*)(char))writechar);
  #else
    tputs(exit_ca_mode,1,writechar);
  #endif
#endif
;
}

/*********************************/
void scroll_up()
{
#ifndef MSDOS
  #ifdef SUNOS
    tputs(scroll_forward,1,(int (*)(char))writechar);
  #else
    tputs(scroll_forward,1,writechar);
  #endif
#else
;
#endif
}

/*********************************/
void scroll_down()
{
#ifndef MSDOS
  #ifdef SUNOS
    tputs(scroll_reverse,1,(int (*)(char))writechar);
  #else
    tputs(scroll_reverse,1,writechar);
  #endif
#else                
;
#endif
}

/*********************************/
void ins_line()
{
#ifndef MSDOS
  #ifdef SUNOS
    tputs(insert_line,1,(int (*)(char))writechar);
  #else
    tputs(insert_line,1,writechar);
  #endif
#else
insline();
#endif
}

/*********************************/
void deline()
{
#ifndef MSDOS

  #ifdef SUNOS
    tputs(delete_line,1,(int (*)(char))writechar);
  #else  
    tputs(delete_line,1,writechar);
  #endif

#else
    delline();
#endif
}


#ifndef MSDOS
/*********************************/
void clreol()
{
  #ifdef SUNOS
    tputs(clr_eol,1,(int (*)(char))writechar);
  #else
    tputs(clr_eol,1,writechar);
  #endif
}                     
#endif

#ifndef MSDOS
/*********************************/
void clrscr()
{
  #ifdef SUNOS
    tputs(clear_screen,1,(int (*)(char))writechar);
  #else
    tputs(clear_screen,1,writechar);
  #endif
}                
#endif

/*********************************/
void clrbot()
{
#ifndef MSDOS
  #ifdef SUNOS
    tputs(clr_eos,1,(int (*)(char))writechar);
  #else
    tputs(clr_eos,1,writechar);
  #endif
#endif
;
}

/*********************************/
void cmove(int y, int x)
{
#ifndef MSDOS
  char * str;

  if (x > getCOLS()) x = getCOLS() - 1;
  if (x < 0) x = 0;

#ifdef SUNOS
	tputs(tparm(cursor_address,y,x),1,(int (*)(char))writechar);
#else  
	tputs(tparm(cursor_address,y,x),1,writechar);
#endif

#else
  if (!macexec)
    {
    if (x > getCOLS()) x = getCOLS() - 1;
    if (x < 0) x = 0;
    gotoxy(x+1,y+1);
    }
#endif
}

/*********************************/
void ins_mode()
{
#ifndef MSDOS
  #ifdef SUNOS
    tputs(enter_insert_mode,1,(int (*)(char))writechar);
  #else
    tputs(enter_insert_mode,1,writechar);
  #endif
#endif
;
}

/*********************************/
void ovr_mode()
{
#ifndef MSDOS
  #ifdef SUNOS
    tputs(exit_insert_mode,1,(int (*)(char))writechar);
  #else
    tputs(exit_insert_mode,1,writechar);
  #endif
#endif
;
}

/*********************************/
void enter_bold()
{
#ifdef CYGWIN
  tputs(tparm(set_a_foreground,GREEN),1,writechar);
  tputs(tparm(set_a_background,BLACK),1,writechar);
#else
#ifndef MSDOS
  #ifdef SUNOS
    tputs(enter_bold_mode,1,(int (*)(char))writechar);
  #else 
    tputs(enter_bold_mode,1,writechar);
  #endif
#else
    textcolor(LIGHTCYAN);
    textbackground(BLACK);        
#endif
#endif
}

/*********************************/
void enter_inv()
{
#ifdef CYGWIN
  tputs(tparm(set_a_foreground,BLACK),1,writechar);
  tputs(tparm(set_a_background,WHITE),1,writechar);
#else
#ifndef MSDOS
  #ifdef SUNOS
    tputs(enter_reverse_mode,1,(int (*)(char))writechar);
  #else
    tputs(enter_reverse_mode,1,writechar);
  #endif
#else
    textcolor(BLACK);
    textbackground(LIGHTGRAY);
#endif
#endif
;
}

/*********************************/
void enter_under()
{
#ifdef CYGWIN
  tputs(tparm(set_a_foreground,RED),1,writechar);
  tputs(tparm(set_a_background,BLACK),1,writechar);
#else
#ifndef MSDOS
  #ifdef SUNOS
    tputs(enter_underline_mode,1,(int (*)(char))writechar);
  #else  
    tputs(enter_underline_mode,1,writechar);
  #endif
#else
    textcolor(BLACK);
    textbackground(LIGHTRED);
#endif
#endif
}

#ifndef MSDOS
/*********************************/
void exit_under()
{
#ifdef SUNOS
  tputs(exit_underline_mode,1,(int (*)(char))writechar);
#else
  tputs(exit_underline_mode,1,writechar);
#endif
;
}
#endif

/*********************************/
void enter_blink()
{
#ifdef CYGWIN
  tputs(tparm(set_a_foreground,YELLOW),1,writechar);
  tputs(tparm(set_a_background,BLACK),1,writechar);
#else
#ifndef  MSDOS
  #ifdef SUNOS
    tputs(enter_blink_mode,1,(int (*)(char))writechar);
  #else
    tputs(enter_blink_mode,1,writechar);
  #endif
#else
    textcolor(YELLOW);
    textbackground(BLACK);
#endif
#endif
;
}

/*********************************/
void normal()
{
#ifdef CYGWIN
  tputs(tparm(set_a_foreground,WHITE),1,writechar);
  tputs(tparm(set_a_background,BLACK),1,writechar);
#else
#ifndef MSDOS
  #ifdef SUNOS
    tputs(exit_attribute_mode,1,(int (*)(char))writechar);
  #else
    tputs(exit_attribute_mode,1,writechar);
  #endif
#else
    textcolor(LIGHTGREEN);
    textbackground(BLACK);
#endif
#endif
;
}

/*********************************/
void delchar()
{
#ifndef MSDOS
  #ifdef SUNOS
    tputs(delete_character,1,(int (*)(char))writechar);
  #else  
    tputs(delete_character,1,writechar);
  #endif
#endif
;
}

