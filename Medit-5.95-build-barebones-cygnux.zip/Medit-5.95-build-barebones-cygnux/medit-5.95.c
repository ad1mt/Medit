/*****************************
Medit Unix text screen editor
------------------------------

Amendment History:

         5.1  1. Changed to SCCS management of source files.
              2. Bug fix: find string warning message "string not found" does
                 not occur on backwards find.
 
         5.2  Ditto.
         5.3  Ditto.
 
         5.4  Temp file location now /tmp instead of /var/tmp, so that /var 
              filling up does not cause problems.
 
         5.5  ~ character is substituted with $HOME on command line.
         5.6  1. Remove debugging display.
              2. Fixed null tempfile bug.
 
         5.7  ~ in filename is not substituted on status line.
 
         5.10 Bug fix - undid fix 4.60/4 which caused the last line of a file
              to be ignored when no NL at eof.
 
         5.11 Bug fix - another RE bug - more than 2 occurances of RE on same
              line not found.
 
         5.12 Correct misleading error message when replacement string not
              specified. Trailing quotes most now be specified for string replace,
              and replace without qualifier no longer allowed, except internally.
 
         5.13 1. Linux compatibility - no REs.
              2. Bug fix - when pasting a file with lines too long, existing
                 unsaved text was lost.
 
         5.15a Retrospective bug fix: macros executed with mx did not stop at
               end of block.
 
         5.17 1. Char toggle case command.
              2. Bring version no of medit.c into line with other files.
 
         5.18 1. Move to word & back to word commands.
              2. Char position on status line.
 
         5.19 Unfinished version skipped.
         5.20 Unfinished version skipped.
 
         5.21 Bug fix: spurious <NL><SPACE> inserted after <FF>.
 
         5.22 New RE library.
 
         5.23 1. Linux bug fixes.
              2. Bug fix: RE search should start after end of previous match
                 but didn't.
              3. Move to word now treats only alpha as a word.
 
         5.23a Bug fix - but I can't remember what the bug was.
 
         5.24 Version skipped
 
Feb 2000 5.25 32-bit DJGPP compiled version for win 9x & NT.

         5.25a Bug fix: MSDOS version ignored '\' & '|' characters.

         5.26 Whole word option on find string.

         5.27 1. Bug fix: Staus line message length 1 too big.
              2. Bug fix: help did not entirely clear screen.
              3. count_lines() only called when needed.

         5.28 Bug fix: gotoline() did not update new_count.

         5.29 Bug fix: ! os command was misinterpreted as a the last
              command typed.

         5.30 Bug fix: lines not counted at various points.

spring00 5.31 1. Bug fix: replace was clobbered by not resetting
                 word_search flag.
              2. Word option to replace command.
              3. Case option to replace command.
              4. Bug fix: nasty bug where deleting a char at end of line
                 (to join next line to current), sometimes caused a crash.

         5.32 Bug fix: replace trailing options not parsed properly.

         5.33 Bug fix: default replace was still case sensitive.

         5.34 1. Bug fix: lines not counted at various points.
              2. Bug fix: more command parsing bugs.

         5.35 Bug fix: spruious chars appended to last line if it has no NL
              char at end.

         5.36 Bug fix: doing open <filename> gave a spurious errror message
              "filename must specified" even though a filename had been
              specified.

         5.37 Bug fix: insufficiently endowed terminal type caused
              empty_memory() to crash, called by finish(), called by
              initialise().  Caused by uninitialised line_table_start, cured by
              moving initialisation (of this & other vars) forward to start of
              initialise().

summer00 5.38 Append option to write comand.

         5.39 Add Ctrl-X and Ctrl-E to default keymap to get to command line.

autumn00 5.40 Tabstop setting configurable with the -S parameter.

         5.41 Tabstop setting configurable with Tab command.

         5.42 1. Bug fix: its possible to construct a runaway RE replace, so
                 allow a key press to interrupt replace (like macexec).
              2. An intermittent crashing has been spotted but NOT fixed - it
                 seems related to a long editing session.

         5.43 1. F8 on command line goes to end of command history.
              2. Commands not entered into history when executing or defining
                  a macro.

4.1.2002 5.44 Bug fix: paste_block ignored any marked block. Now it unmarks any
              marked block.  Its a bit kludgy & should really handle it
              properly.  It is hoped that this is the fix for 5.42-2.

5.1.2001 5.45 Cygwin version - to allow development at home.

7.1.2001 5.46 Combined v5.44 & v5.45

19.2.2002 5.48 Always map Ctrl-X/E/C to COMMAND-LINE function.

10.7.2003 5.49 1. Changed default keymap message.
               2. Improved default keymapping.
               3. Fixed unavailable ^S ^Q ^O ^V.
               4. Made setup_term more posix portable.

18.9.2003 5.50 1. Scroll sideways by 1 char instead of 10-15

27.11.2003 5.51 1. If command-line function not mapped, then attempt to map
                   to Ctrl-X, otherwise exit.

5.12.2003  5.52 1. Update the usage text string.

8.2.2005   5.53 Bug fix: Linux only - file permissions not preserved on save.

9.5.2005   5.54 Bug: edited file has same mtime as original.  This screws 
                up crontab on Linux platform.  Fix: create temp file 
                immediately prior to write, instead of on entry to program.

5.12.2005  5.55 1. Bug: A not accepted a ALL after Q command.
                2. New envar MEDIT_KEYMAP_FILE which is used to specify a
                   keymap file explicitly.  If this envar does not exist then
                   use MEDITKEYPATH & TERM envars as before.

5.12.2005  5.56 1. New SCROLL_RIGHT & SCROLL_LEFT functions.
6.12.2005  5.57 1. Buf gix: in 5.56.1
9.12.2005  5.58 1. Fug bix: in 5.55.1
                2. Big fux: in save() when saving file & permission denied
                   on Linux: attempt to close a NULL file pointer.

12.12.2005 5.59 1. Remember last line deleted, so that it can be undeleted.
                2. New function: undelete line.
                3. New function: goto marked block.

13.12.2005 5.60 1. Undelete line restores to correct context if possible, 
                   otherwise asks to restore above current line.

14.12.2005 5.61 1. Do not reset vx unless necessary.

14.12.2005 5.62 1. -r option or mread executable name invokes read-only mode.

14.12.2005 5.63 1. Linked with PCRE v6.4
                2. The age-old RE bug that caused '^$' not to match an empty
                   line has been fixed.

15.12.2005 5.64 1. RE's now caseless by default, and use the Case option.

19.1.2005  5.65 1. Bug fix: in read-only mode only first file loaded of
                   wildcard filenames.
                2. Bug fix: in read-only mode a filename must be specified.

25.4.2006  5.66 1. Bug fix: tempnam was causing segfault on zeus (solaris 9).
                   call tmpfile instead.

25.4.2006  5.67 1. Bug fixes: in undelete_line related code.

8.3.2007   5.68 1. Always map Ctrl-X to command line.
                2. On Cygwin default ccflag_vdisable to zero if not available.

20.3.2007  5.69 1. started fixing broken back_to_word() - not finished.
                2. minor fixes in read-only mode.

  10.2007  5.70x - 5.73x abandoned

17.1.2008  5.74 1. bug fix: line count not reset after first file with
                   multiple files.

12.6.2008  5.75 1. bug fix: action HUP signal by taking panic action.

Apr.2009   5.76 1. bug fix: hangs on MX with no macro defined.
                2. added extra comments.

1.5.2009   5.77 1. change attributes of replace string within marked block
                   to make more visible.

7.5.2009   5.78 1. move-to-word & back-to-word no longer shift text upscreen.

25.3.2010  5.79 1. line-number update fixed when inserting text into empty file.
                   this will also hopefully fix outstanding known bug #3 below.

8.4.2010   5.80 1. fix compiler errors under cygwin.

9.4.2010   5.81 1. fix back_to_word().

13.5.2010  5.82 1. renamed getline() to getline2().

10.9.2010  5.83 1. bug fix: block paste at the start of the file or in an
                   empty file sometimes goes scarily wrong.  rewrote the
                   pasteblock() function.  maybe the same needs to happen
                   for the other xxxblock() functions, as the code really
                   is a mess.

5.11.2010  5.84 1. bug fix: single mark block;quit followed by single
                   mark block;quit caused crash.

5.7.2012   5.85 1. attempted bug fix: clear line in a 1-line file did not detect
                   possible resulting empty file.
                   NOT YET WORKING.

2012.11.20 5.86 1. change warning "do you want to cancel the QUIT?" to
                   "do you want to save the file?".

2016.05.19 5.87 1. attempt to fix crashing bug, possibly related to not counting
                   lines after MX.

2018.02.15 5.88	1.	Allow invalid command key map entries to have a description.
				2.	In default keymap: Ctrl-C to get command line, Ctrl-X to
					cut block to buffer.

2018.06.27 5.89 1.	In default keymap: Ctrl-Q mapped to command line, but message
					said mapped to Ctrl-X.

2021.06.01 5.90 1.	Changes required for new PCRE2 library. ABANDONED!

2023.01.12 5.91 1.	Make save() a function that can be keymapped.
				2.	Buffer overflow bug fixes in void command -> token
				3.	Attempt to fix warnings.

2023-03-15 5.92 1.	Fix warnings.

2023-03-18 5.93	1.	Remove vestigial WINDOW refs.

2023-03-21 5.94	1.	Detect 64bit vs 32bit CC.

Outstanding known bugs:

1.	A file with a single newline char in it, will be converted to an empty file.
	Note that this also occurs in vi.

2.	All null characters (ASCII 0) are stripped from the text. Note that this
	lso happens with vi.

3.	Line numbers intermittently get screwed up. Cause as yet unknown. Currently
	not reproducible.  This bug has not appeared for some time now - it might
	be fixed.  This might have been fixed with the new rewritten pasteblock().

4.	There are still one (or more) bug(s) that cause intermittent crashes.

******************************/
/*---------------
MEDIT VERSION NO
----------------*/

char medit_version[16] = "Medit V5.95    ";
/* NB an "s" suffix is added here ---^ 
   i.e. at position 11 in medit_version
   during init() if CYGWIN && STATIC are defined.
*/

char usage[] = "Usage:\nmedit [-s <tabstop setting>] [-r] [-t] [-k <keymapfile>] {<textfile>...}\nwhere -s <tabstop setting> sets tab stops\n  and -r means read-only\n  and -t highlights tabs in the text\n  and -k <keymapfile> specifies an alternative keymapping file\n  and -? or -h shows this help message\nNB options are not case sensitive";

#ifndef MSDOS
#include <curses.h>
#endif

#include "medit-5.xx.h"
#include "pcre.h"
#include <unistd.h>
#include <ctype.h>

struct line_rec
  {
  struct line_rec *next_line;
  struct line_rec *prev_line;
  int in_block;
  char text[2]; /* N.B. The item called 'text' is actually VARIABLE LENGTH. */
  };            /* Therefore                                                */
                /* an instance of a line_rec CANNOT be copied as a whole -  */
                /* the new instance must be created with the malloc() call  */
                /* specifying how big the new instance must be (including   */
                /* the REAL size of the variable length text item); then    */
                /* each of the individual items must be copied seperately.  */
		/*                                                          */
		/* Isn't the C programming language just full of wonder and */
		/* amusement!  I could think of no better way of            */
		/* implementing a linked list...                            */

struct line_rec *line_table_start;
struct line_rec *line_table_top;
struct line_rec *line_table_end;
struct line_rec *line_table_bot;
struct line_rec *line_table_cur;
struct line_rec *line_table_block_start;
struct line_rec *line_table_block_end;

struct line_rec *buff_table_start;
struct line_rec *buff_table_end;

struct line_rec *last_line_deleted;

/* This is a multi-dimensional table for storing key escape sequences */

struct esc_node
  {
  unsigned int esc_char;
  struct esc_node * next_node;
  struct esc_node * next_level;
  int func_code;
  };

/* This points to the start of the key escape sequence table */

struct esc_node * esc_table = NULL;

/* This is the current position in the key escape sequence table */

struct esc_node * esc_current = NULL;


/* This is the table that matches key descriptions to Medit function
   descriptions. The key descriptions will have been typed in by the user
   doing the key mapping.
*/

#define KEY_DESC_LEN 14
#define FUNC_DESC_LEN 21
struct key_desc_node
  {
  char key_desc[KEY_DESC_LEN+1];
  char func_desc[FUNC_DESC_LEN+1];
  int func_code;
  struct key_desc_node * next_node;
  };

/* Pointer to the first entry in the table */
struct key_desc_node * key_desc_table = NULL;
struct key_desc_node * key_desc_last  = NULL;
struct key_desc_node * key_desc_ptr   = NULL;
struct key_desc_node * prev_key_desc_table = NULL;

char func_desc[][21] =
  {
  "Backwards Del. Char.", /*    8 */
  "Tab                 ", /*    9 */
  "New Line.           ", /*   10 */
  "Help.               ", /* 1007 */
  "Command Line.       ", /* 1001 */
  "Clear Line.         ", /* 1002 */
  "Delete Line.        ", /* 1011 */
  "Find Forwards.      ", /* 1012 */
  "Find Backwards.     ", /* 1013 */
  "Mark Block.         ", /* 1008 */
  "Copy Block.         ", /* 1009 */
  "Move Block.         ", /* 1010 */
  "Cut Block to Buffer.", /* 1017 */
  "Clear Block Markers.", /* 1016 */
  "Paste from Buffer.  ", /* 1018 */
  "Start of File.      ", /* 1014 */
  "End of File.        ", /* 1015 */
  "Insert Control Char.", /* 1019 */
  "Toggle Insert Mode. ", /* 1020 */
  "Forwards Del. Char. ", /* 1021 */
  "Start of Line.      ", /* 1005 */
  "End of Line.        ", /* 1006 */
  "Pageup.             ", /* 1003 */
  "Pagedown.           ", /* 1004 */
  "Cursor Up.          ", /* 1022 */
  "Cursor Down.        ", /* 1023 */
  "Cursor Left.        ", /* 1024 */
  "Cursor Right.       ", /* 1025 */
  "Define Macro.       ", /* 1026 */
  "Replay Macro.       ", /* 1027 */
  "Char Toggle Case.   ", /* 1028 */
  "Word Toggle Case.   ", /* 1029 */
  "Move to word.       ", /* 1030 */
  "Back to word.       ", /* 1031 */
  "Scroll Right.       ", /* 1032 */
  "Scroll Left.        ", /* 1033 */
  "Undelete line.      ", /* 1034 */
  "Goto Marked Block.  ", /* 1035 */
  "Save file.          ", /* 1036 */
  "Invalid Command.    "  /* 0    */
  };

int func_code[] =
  {
  BACKSPACE,
  TAB,
  NEW_LINE,
  HELP,
  COMMAND_LINE,
  CLEAR_LINE,
  DEL_LINE,
  FIND_FOR,
  FIND_BACK,
  MARK_BLOCK,
  COPY_BLOCK,
  MOVE_BLOCK,
  DEL_BLOCK,
  CLEAR_MARK,
  PASTE_BLOCK,
  START_FILE,
  END_FILE,
  CONTROL_CHAR,
  TOGGLE_INS,
  DEL_CHAR,
  START_LINE,
  END_LINE,
  PAGEUP,
  PAGEDOWN,
  CURSOR_UP,
  CURSOR_DOWN,
  CURSOR_LEFT,
  CURSOR_RIGHT,
  DEFINE_MACRO,
  REPLAY_MACRO,
  TOGGLE_CASE,
  W_TOGGLE_CASE,
  MOVE_TO_WORD,
  BACK_TO_WORD,
  SCROLL_RIGHT,
  SCROLL_LEFT,
  UNDELETE_LINE,
  GOTO_MARKED_BLOCK,
  SAVE_FILE_FUNCTION,
  NO_COMMAND
  };


/* Macro definition stuff */

struct macro_def_node
  {
  int func_code;
  struct macro_def_node * next_node;
  };

extern struct macro_def_node * macro_def_prev;
extern struct macro_def_node * macro_def_ptr;
extern struct macro_def_node * macro_def_table;

struct macro_def_node * macro_def_prev = NULL;
struct macro_def_node * macro_def_ptr = NULL;
struct macro_def_node * macro_def_table = NULL;

/* vestigial WINDOW variables from when curses was used
Curses is no longer used, but some routines still expect WINDOW parameters
and I havn't got round to removing them from the code.
*/

int winptr = 0;
int statusptr = 1;
int helpptr = 2;

/* General purpose file variable */
FILE *fptr;

/* a buffer for longjmp */
jmp_buf jmpbuf;

/* Global argument pointers so that routines other than main() can access
the command-line parameters.
*/
char **g_argv;
int g_argc;
char argv0[STRINGMAX];

/* this was BOTH the current X position in the text AND
   the current position of the cursor on the screen,
   but now it is ONLY the X position in the text.
*/
int cx = 0;
int prev_cx = 0;

/*
   these are the current X position of the cursor on the screen,
*/
int sx = 0;
int cur_sx = 0;

/* this is the current Y position of the cursor on the screen. */
int cy = 0;

/* This is the new cursor Y position on the screen. It is used to indicate
that the cursor has moved to a new line but the new line is on screen & a
screen repaint is not necessary - only a cursor positioning call.
The use_new_cy flag is used so that new_cy can be set & later disregarded.
*/
int new_cy;
int use_new_cy = FALSE;

/*
  this is the horizontal offset of the virtual screen,
  e.g. if VX = 10 then the left edge of the screen starts 10 chars into
  each line of text.
*/
int vx = 0;

int command_max;
int COMMAND_MAX;
int file_empty = TRUE;
int message_pending = 0;
int line_no_pending = FALSE;
int text_had_nulls;
int block_marked = FALSE;
int read_failed;
int save_failed;
int save_abandoned;
int case_sens = FALSE;
int word_search = FALSE;
int insert_mode = TRUE;
int line_needs_updating = FALSE;
long total_lines = 0;
long no_of_chars = 0;
long total_chars = 0;
int file_needs_saving = FALSE;
int highlight_tabs = FALSE;
int keymap = FALSE;
int scrolling = FALSE;
int scrollingup = FALSE;
int scrollingdown = FALSE;
int macro_cmd_mapped = FALSE;
int macro_define_mapped = FALSE;
int macro_replay_mapped = FALSE;
int blk_cmd_mapped = FALSE;
int copyblk_mapped = FALSE;
int deleteblk_mapped = FALSE;
int pasteblk_mapped = FALSE;
int moveblk_mapped = FALSE;
int markblk_mapped = FALSE;
int scr_buffer_i = 0;
int no_scroll = FALSE;
int panic_signal;
int power_failure = FALSE;
int macro_state = MAC_NULL;
int macexec = FALSE;
int macro_block_range = FALSE;
int macro_range_error = FALSE;
int macro_exec_error = FALSE;
int macro_kb_count;
int last_op_failed;
int last_op_interrupt;
int macro_func_count;
int next_char_raw = FALSE;
int debug_kb_max=0;
int arg_no;
int brkflag;
int findstr_is_re = (FALSE);
int findlen = 0;
int command_index = 0;
int command_end = 0;
int command_start = 0;
int status_fname_x;
int status_mess_len;
int no_tilde = (FALSE);
int re_cx = -1;
int lines_paged;
#define OVERWRITE 0
#define APPEND 1
int open_mode=OVERWRITE;
int debug = FALSE;
int read_only_mode = FALSE;

#define COMMAND_IMAX 51
#define HIGH_CTRL (TRUE)

long win_standout = 0;
long win_reverse = 0;
long win_bold = 0;
long win_blink = 0;
long win_underline = 0;

long status_standout = 0;
long status_reverse = 0;
long status_bold = A_BOLD;
long status_blink = 0;
long status_underline = 0;

long help_standout = 0;
long help_reverse = 0;
long help_bold = 0;
long help_blink = 0;
long help_underline = 0;

long cur_line_no=0;
long new_count=1;
long cur_page_no=0;
int  lines_counted = FALSE;

char errortext[ERRORTEXT_MAX];
char mess_text[MESS_TEXT_MAX];
char findstr[FINDSTR_MAX];
char find_text[FIND_TEXT_MAX];
char filename[FILENAMEMAX];
char backup[FILENAMEMAX];
int no_backup = FALSE;
char keymapname[KEYMAPNAME_MAX];
char pathname[PATHNAME_MAX];
char termtype[TERMTYPE_MAX];
char file_text[LINEMAXLEN];
char command_hist[COMMAND_IMAX][PREV_COMMAND_MAX];
char line_buffer[LINE_BUFFER_MAX];
char temp_str[TEMP_STR_MAX];
char scr_buffer[SCR_BUFFER_LEN];
char tempfilename[FILENAMEMAX];
char command_prompt[10] = "Command: ";
char home[PATHNAME_MAX];
int temp_error;

pcre *expr_ptr;

int  tabstop[SCREENMAX];

int SCREENCOLS;
int SCREENLINES;

#ifndef CYGWIN
extern int COLS;
extern int LINES;
#endif

int main(int argc, char **argv);
void initialise();
void finish(int errcode);
int getline2(FILE *stream,char s[],int line_max);
void showscreen();
void showscreen_cur();
void pagedown(int y);
void pageup(int y);
void up();
void down();
void left();
void right();
void scroll_left();
void scroll_right();
void updateline(int leave_trailing_spaces);
void save_file();
void save(int save_block, int open_mode);
void insert_line();
void insert_line_end();
void delete_line();
void split_line();
void command_line();
int gotoline(int line);
int find(char str[],int direction,int case_sens);
void markblock();
void copyblock(int from_deleteblock);
void pasteblock(int from_moveblock);
void deleteblock(int from_moveblock);
void empty_buffer();
void highlight_block(int on_off);
void showscreency(int y);
void next_mess(char message[]);
void remove_tabs();
struct line_rec * replace_line(struct line_rec *line_table_ptr,char line_buffer[]);
void insert_line_text(struct line_rec *line_table_ptr,char line_buffer[]);
struct line_rec * join_ptr(struct line_rec *line_table_ptr);
void replace(char find_str[],char replace_str[],char suffix_str[]);
char * repl_string(int *len,char *line,char *search,char *replace,int *cx);
char * repl_expr(int *len,char *line,char *replace,int *cx,int search_len);
void help();
void readfile(char readfname[],int load_or_paste);
char * upper_case(char *source);
void restore_status(int update_what,int y,int force);
int disp_mess();
void insert_char(int c);
void backspace();
void delete_char();
void new_line();
void zap_spaces(char *source);
int in_str(char line[],char *pattern,int *cx,int direction);
char * str_str(char *string,char *pattern);
int rename_file(FILE *tempf, FILE *origf);
void shift_left_str(char * string, int position, int max_len);
void shift_right_str(char * string, int position, int max_len);
void ins_char_str(char string[], int position, char c, int max_len);
void x_waddch(int winptr,int c,int no_vx_check,int high_ctrl);
void x_waddstr(char * string,int no_vx_check,int init_sx,int high_ctrl);
void n_waddch(int winptr,int c,int no_vx_check,int init_cx,int cx,int high_ctrl);
void n_waddstr(char * string,int no_vx_check,int init_cx);
void ni_waddstr(char * string,int no_vx_check,int init_cx,int count,int high_ctrl);
void c_waddch(WINDOW * winptr,int c,int no_vx_check);
void c_waddstr(char * string,int no_vx_check,int init_sx);
void s_waddch(int c,int no_vx_check,int cx,int vx,int left_sx,int right_sx,int high_ctrl);
void s_waddstr(char * string,int no_vx_check,int vx,int left_sx,int right_sx,int high_ctrl);
int control_char();
void ctrl_char_help();
void winattr(int window);
void moveblock();
void dup_block();
void display(char * mess, int pause);
void showline_mv(struct line_rec * line_table_ptr, char * text, int ly, int cx, int hilite_block);
void showline_right(struct line_rec * line_table_ptr, char * text, int ly, int cx, int hilite_block);
void load_buffer();
unsigned int decode_key();
void insert_esc(unsigned int c, int same_level, int f);
int find_esc_char(unsigned int c);
void insert_seq(unsigned int sequence[],int f);
void insert_key_desc(char kdesc[], int func);
void default_key_map();
int map_func(int func);
void map_functions();
void load_key_map();
int get_string( char command_str[],
                int command_max,
                int funkeys_allowed,
                int screeny,
                int screenx,
                int save_command,
                int ctrl_allowed,
                int tab_ends_input,
                char prompt[]);
void calc_sx_ch(int c);
int calc_sx_str(char * string, int cx);
/* int calc_status_sx(char * string,int vx,int cx,int left_sx); */
void calc_status_ch(
              int c,
              int no_vx_check,
              int cx,
              int vx,
              int left_sx,
              int right_sx,
              int high_ctrl);
int calc_status_sx(char * string,
                     int no_vx_check,
                     int vx,
                     int cx,
                     int left_sx,
                     int right_sx,
                     int high_ctrl);
void down_no_upd();
void up_no_upd();
void show_bot_line();
void showblock(int hilite);
void recalc_screen_cur();
void recalc_screen_cy(int y);
void catchsigs();
void panic_stations(int panic_signal);
void panic(int sig);
static void setsig(int sig, void (*fcn)());
char * parse(char * target,
             char * source,
             char * delimiter,
             int quoted,
             int target_max);
int rand();
int get_macro_func();
void insert_macro_func(int f);
void define_macro();
void end_macro();
void empty_memory();
void replay_macro();
void next_file();
void count_lines();
/* int expr(char str[],int direction,int case_sens); */
int expr(pcre * str,int direction,int case_sens);
/* int in_expr(char line[],char *pattern,int *cx,int direction); */
int in_expr(char line[],pcre *pattern,int *cx,int direction);
void replace_expr(char replace_str[],char suffix_str[]);
int find_str_re(int direction,int case_sens);
char query(char mess[]);
char query_with_prompt(char mess[],char prompt[]);
void toggle_case();
int w_toggle_case();
int move_to_word();
int back_to_word();
void undelete_line();
void goto_marked_block();

extern int kb_blocking;
extern void setup_term();
extern void unset_term();
extern void set_raw();
extern int non_block_kb(int delay);
extern int block_kb();
extern void clreol();
extern void clrscr();
extern void clrbot();
extern void cmove(int y, int x);
extern void ins_mode();
extern void ovr_mode();
extern void enter_bold();
extern void enter_inv();
extern void enter_under();
extern void exit_under();
extern void enter_blink();
extern void normal();
extern void delchar();
extern void enter_ca();
extern void exit_ca();
extern int get_key_str(unsigned char * p,char k[]);
extern int key_backspace_str(unsigned char * p);
extern int key_help_str(unsigned char * p);
extern int key_home_str(unsigned char * p);
extern int key_end_str(unsigned char * p);
extern int key_nextpage_str(unsigned char * p);
extern int key_prevpage_str(unsigned char * p);
extern int key_left_str(unsigned char * p);
extern int key_right_str(unsigned char * p);
extern int key_up_str(unsigned char * p);
extern int key_down_str(unsigned char * p);
extern int getCOLS();
extern int getLINES();
extern void deline();
extern void ins_line();
extern int x_getch();
extern int kb_buffer_i;
extern int kb_buffer_end;
extern unsigned char kb_buffer[SCR_BUFFER_LEN];
extern void flush_scr_buffer();
extern void x_buffch(unsigned int c);
extern void scroll_up();
extern void scroll_down();

/*************************/
int main(int argc, char **argv)
{
unsigned int c;
int count,i;

if ((panic_signal = setjmp(jmpbuf)) != 0)
  /* A longjmp has just been executed ( from panic() ), so ... */
  panic_stations(panic_signal);
else
  /* Setjmp is returning from initialising the jmp point,
     so no need to panic, just catch the signals.
  */
  catchsigs();

g_argv = argv;
g_argc = argc;

strncpy(argv0,g_argv[0],STRINGMAX);

initialise();

/*
-------------------------
The main edit mode loop
--------------------------
*/

load_buffer();

c = decode_key();

while (FOREVER)
  {
  if (c != FIND_FOR)
    re_cx = -1;
  switch (c)
    {
    case COMMAND_LINE:
        if (line_needs_updating)
          updateline(LEAVE_TRAILING_SPACES);
        command_line();
        load_buffer();
        break;

    case DEFINE_MACRO:
        define_macro();
        break;

    case REPLAY_MACRO:
        replay_macro();
        break;

    case CONTROL_CHAR:
        count = control_char(temp_str);
        restore_status(ALL_STATUS,SCREENLINES-1,FALSE);
        i = 0;
        while (i < count)
          {
          insert_char(temp_str[i]);
          i++;
          }
        break;

    case TOGGLE_INS:
        if (insert_mode)
          insert_mode = FALSE;
        else
          insert_mode = TRUE;
        restore_status(INS_OVR_ONLY,SCREENLINES-1,FALSE);
        break;

    case FIND_FOR:
        if (line_needs_updating)
          updateline(LEAVE_TRAILING_SPACES);

        if (find_str_re(FORWARDS,case_sens))
          {
          cur_sx = calc_sx_str(line_table_cur->text,cx);

          if (  (cur_sx > (vx + SCREENCOLS - 2 - (int)strlen(findstr)))
             || (cur_sx < vx)
             || (  (cur_sx < (SCREENCOLS - 2 - (int)strlen(findstr)))
                && (vx > 0)
                )
             )
            {
            vx = cur_sx - SCREENCOLS + 2 + (int)strlen(findstr);
            if (vx < 0) vx = 0;
            use_new_cy = FALSE;
            }

          showscreency(SCREENLINES/4);

          lines_counted = FALSE;

          next_mess(find_text);
          }
        else
          if (findstr_is_re)
            {
            if (  macexec
               && macro_block_range
               )
              {
              macro_range_error = TRUE;
              next_mess("Macro reached end of block.");
              }
            else
              next_mess("Regular expression not found.");
            }
          else
            {
            if (  macexec
               && macro_block_range
               )
              {
              macro_range_error = TRUE;
              next_mess("Macro reached end of block.");
              }
            else
              if (strcmp(findstr,"") == STR_SAME)
                next_mess("No string to find.");
              else
                next_mess("String not found.");
            }
        load_buffer();
        break;

    case FIND_BACK:
        if (line_needs_updating)
          updateline(LEAVE_TRAILING_SPACES);
        if (findstr_is_re)
          {
          last_op_failed = TRUE;
          next_mess("Cannot do backwards expression search, sorry.");
          }
        else if (find(findstr,BACKWARDS,case_sens))
          {
          cur_sx = calc_sx_str(line_table_cur->text,cx);

          if (  (cur_sx > (vx + SCREENCOLS - 2 - (int)strlen(findstr)))
             || (cur_sx < vx)
             || (  (cur_sx < (SCREENCOLS - 2 - (int)strlen(findstr)))
                && (vx > 0)
                )
             )
            {
            vx = cur_sx - SCREENCOLS + 2 + (int)strlen(findstr);
            if (vx < 0) vx = 0;
            use_new_cy = FALSE;
            }

          showscreency(SCREENLINES/4*3);

          lines_counted = FALSE;

          next_mess(find_text);
          }
        else
          if (  macexec
             && macro_block_range
             )
            {
            macro_range_error = TRUE;
            next_mess("Macro reached end of block.");
            }
          else
            next_mess("String not found.");
        load_buffer();
        break;

    case HELP:
        if (line_needs_updating)
          updateline(LEAVE_TRAILING_SPACES);
        help();
        load_buffer();
        break;

    case DEL_LINE:
        if (line_needs_updating)
          updateline(LEAVE_TRAILING_SPACES);
        delete_line();
        load_buffer();
        break;

    case UNDELETE_LINE:
        if (line_needs_updating)
          updateline(LEAVE_TRAILING_SPACES);
        undelete_line();
        lines_counted = FALSE;
        load_buffer();
        break;

    case TOGGLE_CASE:
        toggle_case();
        break;

    case CLEAR_LINE:
        if (line_needs_updating)
          updateline(LEAVE_TRAILING_SPACES);
        line_buffer[cx] = '\0';
        updateline(LEAVE_TRAILING_SPACES);
        cmove(cy,cur_sx-vx);
        showline_right(line_table_cur,line_buffer,cy,cx,HILITE);
        cmove(cy,cur_sx-vx);
        file_needs_saving = TRUE;
        if (  (line_table_cur->prev_line == NULL)
           && (line_table_cur->next_line == NULL)
           && ((int)strlen(line_buffer) == 0)
           && (! file_empty)
           )
          {
          file_empty = TRUE;
          restore_status(ALL_STATUS,SCREENLINES-1,FALSE);
          lines_counted = FALSE;
          count_lines();
          cur_line_no = 0;
          new_count = 1;
          restore_status(LINE_NO_ONLY,SCREENLINES-1,NO_FORCE);
          }
        break;

    case BACKSPACE:
        backspace();
        break;

    case DEL_CHAR:
        delete_char();
        break;

    case NEW_LINE:
        if (line_needs_updating)
          updateline(LEAVE_TRAILING_SPACES);
        new_line();
        load_buffer();
        break;

    case START_LINE:
        if (line_needs_updating)
          updateline(LEAVE_TRAILING_SPACES);
        cx = 0;
        cur_sx = calc_sx_str(line_table_cur->text,cx);

        if (cur_sx < vx)
          {
          vx = cur_sx;
          showscreen();
          }
        else
          cmove(cy,cur_sx-vx);

        load_buffer();
        break;

    case END_LINE:
        if (line_needs_updating)
          updateline(LEAVE_TRAILING_SPACES);
        cx = strlen(line_table_cur->text);
        cur_sx = calc_sx_str(line_table_cur->text,cx);

        if (cur_sx > (vx + SCREENCOLS - 1))
          {
          vx = cur_sx - SCREENCOLS + 1;
          showscreen();
          }
        else
          cmove(cy,cur_sx-vx);

        load_buffer();
        break;

    case START_FILE:
        if (line_needs_updating)
          updateline(LEAVE_TRAILING_SPACES);
        if (line_table_cur->prev_line != NULL)
          {
          /* cx = cy = vx = 0; */
          cy = 0;
          line_table_top = line_table_start;
          message_pending = 1;
          showscreen();
          }
        load_buffer();
        new_count = 1;
        break;

    case END_FILE:
        if (line_needs_updating)
          updateline(LEAVE_TRAILING_SPACES);
        if (line_table_cur->next_line != NULL)
          {
          line_table_cur = line_table_end;
          line_table_top = line_table_end;
          /* cx = vx = 0; */
          cy = SCREENLINES-2;
          lines_counted = FALSE;
          message_pending = 1;
          showscreency(SCREENLINES-2);
          }
        load_buffer();
        break;

    case PAGEDOWN:
        if (line_needs_updating)
          updateline(LEAVE_TRAILING_SPACES);
        if (line_table_bot->next_line != NULL)
          {
          pagedown(SCREENLINES);
          use_new_cy = FALSE;
          showscreency(0);
          new_count = (cur_line_no + lines_paged);
          }
        else
          {
          last_op_failed = TRUE;
          next_mess("At end of file.");
          }
        load_buffer();
        break;

    case PAGEUP:
        if (line_needs_updating)
          updateline(LEAVE_TRAILING_SPACES);
        if (line_table_top->prev_line != NULL)
          {
          pageup(SCREENLINES-1);
          use_new_cy = FALSE;
          showscreency(0);
          new_count = (cur_line_no - lines_paged);
          }
        else
          {
          last_op_failed = TRUE;
          next_mess("At start of file.");
          }
        load_buffer();
        break;

    case CURSOR_UP:
        if (line_needs_updating)
          updateline(LEAVE_TRAILING_SPACES);
        up();
        
        if (debug) lines_counted = FALSE;
        load_buffer();
        break;

    case CURSOR_DOWN:
        if (line_needs_updating)
          updateline(LEAVE_TRAILING_SPACES);
        down();

        if (debug) lines_counted = FALSE;
        load_buffer();
        break;

    case CURSOR_LEFT:
        left();
        break;

    case CURSOR_RIGHT:
        right();
        break;

    case SCROLL_RIGHT:
        scroll_right();
        break;

    case SCROLL_LEFT:
        scroll_left();
        break;

    case MOVE_TO_WORD:
        if (line_needs_updating)
          updateline(LEAVE_TRAILING_SPACES);

        if (move_to_word())
          {
          cur_sx = calc_sx_str(line_table_cur->text,cx);

          if (  (cur_sx > (vx + SCREENCOLS - 2 - (int)strlen(findstr)))
             || (cur_sx < vx)
             || (  (cur_sx < (SCREENCOLS - 2 - (int)strlen(findstr)))
                && (vx > 0)
                )
             )
            {
            vx = cur_sx - SCREENCOLS + 2 + (int)strlen(findstr);
            if (vx < 0) vx = 0;
            use_new_cy = FALSE;
            }

          /* showscreency(SCREENLINES/4); */
          showscreency(cy);
          }
        else
          {
          if (  macexec
             && macro_block_range
             )
            {
            macro_range_error = TRUE;
            next_mess("Macro reached end of block.");
            }
          }
        load_buffer();
        break;

    case BACK_TO_WORD:
        if (line_needs_updating)
          updateline(LEAVE_TRAILING_SPACES);

        if (back_to_word())
          {
          cur_sx = calc_sx_str(line_table_cur->text,cx);

          if (  (cur_sx > (vx + SCREENCOLS - 2 - (int)strlen(findstr)))
             || (cur_sx < vx)
             || (  (cur_sx < (SCREENCOLS - 2 - (int)strlen(findstr)))
                && (vx > 0)
                )
             )
            {
            vx = cur_sx - SCREENCOLS + 2 + (int)strlen(findstr);
            if (vx < 0) vx = 0;
            use_new_cy = FALSE;
            }

          /* showscreency(SCREENLINES/4); */
          showscreency(cy);
          }
        else
          {
          if (  macexec
             && macro_block_range
             )
            {
            macro_range_error = TRUE;
            next_mess("Macro reached end of block.");
            }
          }
        load_buffer();
        break;

    case GOTO_MARKED_BLOCK:
        if (line_needs_updating)
          updateline(LEAVE_TRAILING_SPACES);
        goto_marked_block();

        lines_counted = FALSE;
        load_buffer();
        break;

    case MARK_BLOCK:
        if (line_needs_updating)
          updateline(LEAVE_TRAILING_SPACES);
        markblock();
        load_buffer();
        break;

    case PASTE_BLOCK:
        if (line_needs_updating)
          updateline(LEAVE_TRAILING_SPACES);
        pasteblock(NOT_FROM_MOVEBLOCK);
        lines_counted = FALSE;
        load_buffer();
        break;

    case MOVE_BLOCK:
        if (line_needs_updating)
          updateline(LEAVE_TRAILING_SPACES);
        moveblock();
        lines_counted = FALSE;
        load_buffer();
        break;

    case COPY_BLOCK:
        if (line_needs_updating)
          updateline(LEAVE_TRAILING_SPACES);
        dup_block();
        lines_counted = FALSE;
        load_buffer();
        break;

    case DEL_BLOCK:
        if (line_needs_updating)
          updateline(LEAVE_TRAILING_SPACES);
        deleteblock(NOT_FROM_MOVEBLOCK);
        lines_counted = FALSE;
        load_buffer();
        break;

    case CLEAR_MARK:
        if (line_needs_updating)
          updateline(LEAVE_TRAILING_SPACES);
        showblock(NO_HILITE);
        highlight_block(FALSE);
        block_marked = FALSE;
        line_table_block_start = line_table_block_end = NULL;
        next_mess("Block markers cleared.");
        load_buffer();
        break;

	case SAVE_FILE_FUNCTION:
        if (line_needs_updating)
          updateline(LEAVE_TRAILING_SPACES);
		save_file();
		break;

    case NO_COMMAND:
        next_mess("Keystroke ignored.");
        break;

    default:
        if (  (  (c >= CHAR_SPACE)
              && (c < CHAR_DEL)
              )
           || (c == TAB)
           || (c == '|')
           || (c == '\\')
           )
           insert_char(c);
        break;
    }

  if (scrolling)
    {
    /* then suppress updating of status line - it speeds up scrolling enormously */
    if (  (  (c != CURSOR_UP)
          && (scrollingup)
          )
       || (  (c != CURSOR_DOWN)
          && (scrollingdown)
          )
       )
      {
      /* then no longer scrolling */
      scrolling = FALSE;
      scrollingup = FALSE;
      scrollingdown = FALSE;
      if (!macexec) block_kb();

      if (!lines_counted)
        count_lines();
      message_pending = disp_mess();
      }
    }
  else
    {
    /* not scrolling - standard end-of-command processing */
    if (!lines_counted)
      {
      count_lines();
      }
    if (message_pending > 0)
      {
      message_pending = disp_mess();
      }
    else
      if (  (new_count != cur_line_no)
         || (cx != prev_cx)
         )
        {
        cur_line_no = new_count;
        prev_cx = cx;
        restore_status(LINE_NO_ONLY,SCREENLINES-1,NO_FORCE);
        }
    }

  c = decode_key();

  }
}

/* #ifndef MSDOS */
/*************************/
static void setsig(int sig, void (*fcn)())
{
int s;

#ifdef BITS64
	s = (int64_t) signal(sig,SIG_IGN);
	
	if (s == badsig)
	  next_mess("Signal trapping error!");
	else if (s == (int64_t)SIG_IGN)
	  return;
	else if (s != (int64_t)SIG_DFL)
	  next_mess("Signal already caught!");
	
	if ((int64_t)signal(sig,fcn) == badsig)
	  next_mess("Signal trapping error!");
#endif

#ifndef BITS64
	s = (int32_t) signal(sig,SIG_IGN);
	
	if (s == badsig)
	  next_mess("Signal trapping error!");
	else if (s == (int32_t)SIG_IGN)
	  return;
	else if (s != (int32_t)SIG_DFL)
	  next_mess("Signal already caught!");
	
	if ((int32_t)signal(sig,fcn) == badsig)
	  next_mess("Signal trapping error!");
#endif

}

/*************************/
void catchsigs()
{
#ifndef MSDOS
setsig(sigHUP,panic);
setsig(sigINT,SIG_IGN);
setsig(sigQUIT,SIG_IGN);
setsig(sigILL,panic);
setsig(sigIOT,SIG_IGN);
setsig(sigEMT,SIG_IGN);
setsig(sigFPE,SIG_IGN);
setsig(sigBUS,panic);
setsig(sigSEGV,panic);
setsig(sigSYS,SIG_IGN);
setsig(sigTRAP,SIG_IGN);
setsig(sigPIPE,SIG_IGN);
setsig(sigALRM,SIG_IGN);
setsig(sigTERM,panic);
setsig(sigCLD,SIG_IGN);
setsig(sigPWR,SIG_IGN);
#else
setsig(SIGABRT,SIG_IGN);
setsig(SIGALRM,SIG_IGN);
setsig(SIGFPE,panic);
setsig(SIGHUP,SIG_IGN);
setsig(SIGILL,panic);
setsig(SIGINT,panic);
setsig(SIGKILL,SIG_IGN);
setsig(SIGNOFP,SIG_IGN);
setsig(SIGPIPE,SIG_IGN);
setsig(SIGQUIT,SIG_IGN);
setsig(SIGSEGV,panic);
setsig(SIGTERM,SIG_IGN);
setsig(SIGTIMR,SIG_IGN);
setsig(SIGUSR1,SIG_IGN);
setsig(SIGUSR2,SIG_IGN);
#endif
}

/*************************/
void panic(int sig)
{
  clrscr();
  flush_scr_buffer();
  longjmp(jmpbuf,sig);
  fprintf(stderr,"\n\nMedit internal error: signal received, but longjmp did not work.\n\n");
  panic_stations(sig);
}

/*************************/
void panic_stations(int panic_signal)
{
struct line_rec *line_table_ptr;
struct line_rec *line_table_next;
int read_only = FALSE;
char * p;
int fdesc;
int bytes_written;
int byte_count;
char nl = '\n';
char * nlp = &nl;

struct stat fstat_buffer;

#ifdef BITS64
if ((int64_t)signal(panic_signal,SIG_IGN) == badsig)
  fprintf(stderr,"\n\nMedit internal error: signal trapping error in signal trapping function.\n\n");
#endif

#ifndef BITS64
if ((int32_t)signal(panic_signal,SIG_IGN) == badsig)
  fprintf(stderr,"\n\nMedit internal error: signal trapping error in signal trapping function.\n\n");
#endif

save_abandoned = FALSE;
save_failed = FALSE;
message_pending = 0;

/* p = tempnam("/tmp",NULL); */

strcpy(tempfilename,"/tmp/MEDIT_TEMP_FILE_XXXXXX");

p = (char *) &tempfilename;
fdesc = mkstemp(p);

if (strcmp(tempfilename,"") != STR_SAME)
  {
  /* fptr = fopen(tempfilename,"w"); */
  if (fdesc == -1)
    sprintf(errortext,"Error %s on file '%s'",strerror(errno),tempfilename);
  else
    {
    line_table_ptr = line_table_start;
    while (  (line_table_ptr != NULL)
          && (! save_failed)
          )
      {
      byte_count = strlen(line_table_cur->text);
      bytes_written = write(fdesc,line_table_ptr->text,byte_count);
      if (bytes_written != byte_count)
        {
        sprintf(errortext,"Error %s writing temp file '%s'",strerror(errno),tempfilename);
        next_mess(errortext);
        save_failed = TRUE;
        break;
        }
      else
        {
        if (1 != write(fdesc,nlp,1))
          {
          sprintf(errortext,"Error %s writing temp file '%s'",strerror(errno),tempfilename);
          next_mess(errortext);
          save_failed = TRUE;
          break;
          }
        line_table_next = line_table_ptr->next_line;
        line_table_ptr = line_table_next;
        }
      }
    }
  close(fdesc);
  fdesc = -1;
  }
else
  {
  strcpy(errortext,"Could not create temp file name - tempnam() failed\n");
  next_mess(errortext);
  save_failed = TRUE;
  }

#ifndef MSDOS
switch(panic_signal)
  {
  case sigHUP:
    sprintf(temp_str,"\n\nMedit has been aborted with SIGHUP signal.\n");
    break;
  case sigINT:
    sprintf(temp_str,"\n\nMedit has been aborted with SIGINT signal.\n");
    break;
  case sigQUIT:
    sprintf(temp_str,"\n\nMedit has been aborted with SIGQUIT signal.\n");
    break;
  case sigILL:
    sprintf(temp_str,"\n\nMedit has crashed with an illegal instruction (SIGILL signal).\n");
    break;
  case sigTRAP:
    sprintf(temp_str,"\n\nMedit has been aborted with SIGTRAP signal.\n");
    break;
  case sigIOT:
    sprintf(temp_str,"\n\nMedit has been aborted with SIGIOT signal.\n");
    break;
  case sigEMT:
    sprintf(temp_str,"\n\nMedit has been aborted with SIGEMT signal.\n");
    break;
  case sigFPE:
    sprintf(temp_str,"\n\nMedit has been aborted with a floating point error (SIGFPE signal).\n");
    break;
  case sigKILL:
    sprintf(temp_str,"\n\nMedit has been aborted with SIGKILL signal.\n");
    break;
  case sigBUS:
    sprintf(temp_str,"\n\nMedit has crashed with a bus error (SIGBUS signal).\n");
    break;
  case sigSEGV:
    sprintf(temp_str,"\n\nMedit has crashed with a segmentation error (SIGSEGV signal).\n");
    break;
  case sigSYS:
    sprintf(temp_str,"\n\nMedit has been aborted with SIGSYS signal.\n");
    break;
  case sigPIPE:
    sprintf(temp_str,"\n\nMedit has been aborted with SIGPIPE signal.\n");
    break;
  case sigALRM:
    sprintf(temp_str,"\n\nMedit has been aborted with SIGALRM signal.\n");
    break;
  case sigTERM:
    sprintf(temp_str,"\n\nMedit has been aborted with SIGTERM signal.\n");
    break;
  case sigUSR1:
    sprintf(temp_str,"\n\nMedit has been aborted with SIGUSR1 signal.\n");
    break;
  case sigUSR2:
    sprintf(temp_str,"\n\nMedit has been aborted with SIGUSR2 signal.\n");
    break;
  case sigCLD:
    sprintf(temp_str,"\n\nMedit has been aborted with SIGCLD signal.\n");
    break;
  case sigPWR:
    sprintf(temp_str,"\n\nMedit has been aborted with SIGPWR signal.\n");
    break;
  }
#else
setsig(SIGABRT,panic);
setsig(SIGALRM,SIG_IGN);
setsig(SIGHUP,SIG_IGN);
setsig(SIGKILL,SIG_IGN);
setsig(SIGPIPE,SIG_IGN);
setsig(SIGQUIT,SIG_IGN);
setsig(SIGUSR1,SIG_IGN);
setsig(SIGUSR2,SIG_IGN);
setsig(SIGINT,SIG_IGN);
setsig(SIGTERM,SIG_IGN);
setsig(SIGFPE,panic);
setsig(SIGILL,panic);
setsig(SIGSEGV,panic);

switch(panic_signal)
  {
  case SIGHUP:
    sprintf(temp_str,"\n\nMedit has been aborted with SIGHUP signal.\n");
    break;
  case SIGINT:
    sprintf(temp_str,"\n\nMedit has been aborted with SIGINT signal.\n");
    break;
  case SIGQUIT:
    sprintf(temp_str,"\n\nMedit has been aborted with SIGQUIT signal.\n");
    break;
  case SIGILL:
    sprintf(temp_str,"\n\nMedit has crashed with an illegal instruction (SIGILL signal).\n");
    break;
  case SIGFPE:
    sprintf(temp_str,"\n\nMedit has crashed with a floating point error (SIGFPE signal).\n");
    break;
  case SIGKILL:
    sprintf(temp_str,"\n\nMedit has been aborted with SIGKILL signal.\n");
    break;
  case SIGSEGV:
    sprintf(temp_str,"\n\nMedit has crashed with a memory addressing error (SIGSEGV signal).\n");
    break;
  case SIGPIPE:
    sprintf(temp_str,"\n\nMedit has crashed with a pipe error (SIGPIPE signal).\n");
    break;
  case SIGALRM:
    sprintf(temp_str,"\n\nMedit has been aborted with SIGALRM signal.\n");
    break;
  case SIGABRT:
    sprintf(temp_str,"\n\nMedit has been aborted with SIGABRT signal.\n");
    break;
  case SIGTERM:
    sprintf(temp_str,"\n\nMedit has been aborted with SIGTERM signal.\n");
    break;
  case SIGUSR1:
    sprintf(temp_str,"\n\nMedit has been aborted with SIGUSR1 signal.\n");
    break;
  case SIGUSR2:
    sprintf(temp_str,"\n\nMedit has been aborted with SIGUSR2 signal.\n");
    break;
  }
#endif

cmove(0,0);
clrscr();
fprintf(stderr,"%s",temp_str);
if (!save_failed)
  {
  fprintf(stderr,"Medit has attempted to write your edited text to a temporary file.\n\n");
  fprintf(stderr,"If this was successful then you should be able to recover your edited\n");
  fprintf(stderr,"text from the file: %s\n\n",tempfilename);
  }
exit_ca();

unset_term();

exit(1);
}

/******************************************************************************
THE KEYBOARD ESCAPE SEQUENCE TABLE & ASSOCIATED CODE.
-----------------------------------------------------
This is one of the most tricky bits of the program.

The escape sequence table is a mutli-dimensionsal table implemented as a
linked-list.

Each entry has two pointers -
    1. one to the "next level" (next char in escape sequence).
    2. one to the "next node" (next alternative to the current escape char).

For example, take the following example escape sequences, entered into the
table in sequence.
    1.  Esc H p  - mapped to function 1.
    2.  Esc H x  - mapped to function 2.
    3.  127      - mapped to function 3.

These would look like this in the escape char table:

--------------------      --------------------
| Next Node:  -----+----->| Next Node:  NULL |
| Next Level: -----+----  | Next Level: NULL |
| Char:       Esc  |   |  | Char:       127  |
| Function:        |   |  | Function:   3    |
--------------------   |  --------------------
                       |
-------------------- <--
| Next Node:  NULL |
| Next Level: -----+----
| Char:       H    |   |
| Function:        |   |
--------------------   |
                       |
-------------------- <--  --------------------
| Next Node:  -----+----->| Next Node:  NULL |
| Next Level: NULL |      | Next Level: NULL |
| Char:       p    |      | Char:       x    |
| Function:   1    |      | Function:   2    |
--------------------      --------------------

An entry contains a terminating character for a sequence if the "Next Level"
pointer is NULL. The Function field will then contain the Medit function that
the sequence is mapped to.

An escape sequence cannot consist of a subset of another sequence.

Variables:
----------
  esc_current    is the current position in the escape table (while
                 waiting for the next escape char in the sequence).

  esc_table      is the start of the escape table.

Subroutines:
------------
  find_esc_char  sees if the specified char is valid given the current point
                 in the escape table, and if it is, then it advances the
                 esc_current pointer.

  insert_esc     inserts a single char into the table at the current point.

  insert_seq     calls insert_esc to insert a complete escape sequence into the
                 escape table.

Inserting escape characters into the table.
-------------------------------------------
Inserting a new escape sequence into the table is not trivial, because:

a) some of the escape chars will probably already be in the table, but these
   chars must not be entered again, only the completely "new" chars must be
   entered into the table. To use the example above, when inserting the 2nd
   escape sequence, only the "p" gets entered into the table.

b) it has to be figured out whether to attach the new escape chars to the "Next
   Node" pointer, or to the "Next Level" pointer. Maybe I could make this
   easier on myself, by having the find_esc_char routine be more consistent in
   how it leaves the esc_current pointer.

Notes.
------
No routines exist to delete escape sequences from the table, this is mainly
because it was not needed for the current version. However, note that I think
it would be a difficult task, and that any changes made to this effect should
be done with care.

*****************************************************************************/
void insert_seq(unsigned int sequence[],int f)
{
int i,j;
char temp_chr[82];
char temp_hex[82];
struct esc_node * esc_prev;

if (sequence[0] == 0)
  {
  next_mess("Empty key escape sequence in keymap file.");
  return;
  }

esc_current = NULL;
i = -1;
do{
  esc_prev = esc_current;
  i++;
  } while (find_esc_char(sequence[i]));

if (sequence[i] == 0)
  {
  strcpy(temp_chr,"Key esc ");
  j = 0;
  while (j < i)
    {
    sprintf(temp_hex,"%X ",sequence[j]);
    strcat(temp_chr,temp_hex);
    j++;
    }
  strcat(temp_chr,"more than once in keymap file.");
  next_mess(temp_chr);
  }
else
  {
  if (esc_current != esc_prev)
    {
    if (sequence[i+1] == 0)
      insert_esc(sequence[i],SAME_LEVEL,f);
    else
      insert_esc(sequence[i],SAME_LEVEL,0);
    i++;
    }

  while (sequence[i] != 0)
    {
    if (sequence[i+1] == 0)
      insert_esc(sequence[i],NEXT_LEVEL,f);
    else
      insert_esc(sequence[i],NEXT_LEVEL,0);
    i++;
    }
  }
}

/*****************************************************************************/
int find_esc_char(unsigned int c)
{
struct esc_node * esc_ptr;
struct esc_node * esc_prev;

esc_prev = esc_current;

if (esc_current == NULL)
  esc_prev = esc_ptr = esc_table;
else
  esc_ptr = esc_current->next_level;

while (esc_ptr != NULL)
  {
  if (esc_ptr->esc_char == c)
    {
    esc_current = esc_ptr;
    return TRUE;
    }
  esc_prev = esc_ptr;
  esc_ptr = esc_ptr->next_node;
  }

esc_current = esc_prev;
return FALSE;
}

/*****************************************************************************/
void insert_esc(unsigned int c, int same_level, int f)
{
struct esc_node * esc_ptr;
struct esc_node * esc_next;

esc_ptr = (struct esc_node *) malloc(sizeof (struct esc_node));
if (esc_ptr == NULL)
  next_mess("Not enough memory to add escape sequence to table.");
else
  {
  if (esc_table == NULL)
    esc_table = esc_ptr;

  esc_ptr->esc_char = c;
  esc_ptr->func_code = f;

  esc_ptr->next_node = NULL;
  esc_ptr->next_level = NULL;

  if (esc_current == NULL)
    esc_current = esc_table;
  else
    {
    if (same_level)
      esc_current->next_node = esc_ptr;
    else
      esc_current->next_level = esc_ptr;
    esc_current = esc_ptr;
    }
  }
}

/*****************************************************************************/
void insert_key_desc(char kdesc[], int func)
{
int i;
struct key_desc_node * key_desc_ptr = NULL;

i = 0;
while ((func_code[i] != func) && (func_code[i] != NO_COMMAND)) i+=1;

/*
if (func_code[i] != NO_COMMAND)
  {
*/
  key_desc_ptr = (struct key_desc_node *) malloc(sizeof (struct key_desc_node));
  if (key_desc_ptr == NULL)
    next_mess("Not enough memory to add keymap entry to table.");
  else
    {
    strncpy(key_desc_ptr->key_desc,kdesc,KEY_DESC_LEN);
    strncpy(key_desc_ptr->func_desc,func_desc[i],FUNC_DESC_LEN);
    key_desc_ptr->func_code = func_code[i];
    key_desc_ptr->next_node = NULL;

    if (key_desc_table == NULL)
      key_desc_table = key_desc_last = key_desc_ptr;
    else
      {
      key_desc_last->next_node = key_desc_ptr;
      key_desc_last = key_desc_ptr;
      }
    }
/*
  }
else
  next_mess("Invalid function code in key map file.");
*/
}

/*****************************************************************************/
void insert_macro_func(int f)
{
struct macro_def_node * macro_prev = macro_def_ptr;

  macro_def_ptr = (struct macro_def_node *) malloc(sizeof (struct macro_def_node));
  if (macro_def_ptr == NULL)
    next_mess("Not enough memory to record macro.");
  else
    {
    if (macro_def_table == NULL)
      macro_def_table = macro_def_ptr;

    macro_def_ptr->func_code = f;
    macro_def_ptr->next_node = NULL;

    if (macro_prev != NULL)
       macro_prev->next_node = macro_def_ptr;

    if (f != DEFINE_MACRO)
      macro_func_count++;
    }
}

/*****************************************************************************/
int get_macro_func()
{
int f;
struct macro_def_node * macro_def_next;

if (macro_def_ptr != NULL)
  {
  f = macro_def_ptr->func_code;
  macro_def_ptr = macro_def_ptr->next_node;
  }
else
  {
  f = DEFINE_MACRO;
  macro_def_ptr = macro_def_table;
  }
return f;
}

/**************************/
void define_macro()
{
int c;
struct macro_def_node * macro_ptr;
struct macro_def_node * macro_next;

if (macro_state == MAC_NULL)
  {
  macro_ptr = macro_def_prev;
  while (macro_ptr != NULL)
    {
    macro_next = macro_ptr->next_node;
    free(macro_ptr);
    macro_ptr = macro_next;
    }
  macro_def_prev = macro_def_table;
  macro_def_table = macro_def_ptr = NULL;
  macro_state = DEFINE;
  macro_func_count = 0;
  next_mess("Starting macro definition.");
  }
else if (macro_state == DEFINE)
  {
  if (macro_func_count == 0)
    {
    macro_state = MAC_NULL;
    macro_def_table = macro_def_ptr = macro_def_prev;
    next_mess("Macro not replaced.");
    }
  else
    {    
    macro_state = MAC_NULL;
    macro_def_ptr = macro_def_table;
    next_mess("Ended macro definition.");
    }
  }
else if (macro_state == REPLAY)
  {
  macro_def_ptr = macro_def_table;

  if (  last_op_failed
     && macro_range_error
     )
    {
    macro_range_error = FALSE;
    macro_state = MAC_NULL;
    if (macexec)
      /* end macro replay */
      {
      c = (~KB_ERR);
      while (c != KB_ERR) c = x_getch();
      block_kb();
      macexec = FALSE;
      showscreency((SCREENLINES-1)/2);
      lines_counted = FALSE;
      }
    }
  else if (macro_exec_error)
    {
    macro_exec_error = FALSE;
    macro_state = MAC_NULL;
    if (macexec)
      /* end macro replay */
      {
      c = (~KB_ERR);
      while (c != KB_ERR) c = x_getch();
      block_kb();
      macexec = FALSE;
      showscreency((SCREENLINES-1)/2);
      lines_counted = FALSE;
      }
    }
  else if (last_op_failed)
    {
    macro_state = MAC_NULL;
    next_mess("Macro finished.");
    if (macexec)
      /* end macro replay */
      {
      c = (~KB_ERR);
      while (c != KB_ERR) c = x_getch();
      block_kb();
      macexec = FALSE;
      showscreency((SCREENLINES-1)/2);
      lines_counted = FALSE;
      }
    }
  else if (last_op_interrupt)
    {
    last_op_interrupt = FALSE;
    macro_state = MAC_NULL;
    next_mess("Macro interrupted.");
    if (macexec)
      /* end macro replay */
      {
      c = (~KB_ERR);
      while (c != KB_ERR) c = x_getch();
      block_kb();
      macexec = FALSE;
      showscreency((SCREENLINES-1)/2);
      lines_counted = FALSE;
      }
    }
  else
    {
    lines_counted = FALSE;
    if (!macexec)
      {
      macro_state = MAC_NULL;
      next_mess("Macro finished.");
      }
    }
  }
else
  next_mess("Define Macro command ignored.");
}

/**************************/
void replay_macro()
{
if (macro_state == MAC_NULL)
  {
  if (macro_def_ptr != NULL)
    {
    last_op_interrupt = FALSE;
    macro_state = REPLAY;
    if (macexec)
      {
      non_block_kb(0);
      macro_kb_count = 0;
      if (block_marked)
        {
        line_table_top = (line_table_cur = line_table_block_start);
        recalc_screen_cy((SCREENLINES-1)/2);
        macro_block_range = TRUE;
        }
      }
    }
  else
    {
    next_mess("No macro defined");
    macro_block_range = FALSE;
    macexec = FALSE;
    }
  }
else
  {
  next_mess("Replay Macro command ignored.");
  macro_block_range = FALSE;
  macexec = FALSE;
  }
}

/**************************/
unsigned int decode_key()
{
int c,raw_c;
int finished = FALSE;

if (macro_state == REPLAY)
  {
  if (macexec)
    /* then replaying a macro repeatedly */
    {
    /* this implements the key-press macro interrupt */
    c = KB_ERR;
    macro_kb_count+=1;
    if (macro_kb_count > 50)
      {
      c = x_getch();
      macro_kb_count = 0;
      }
    if (c != KB_ERR)
      {
      last_op_interrupt = TRUE;
      while (c != KB_ERR) c = x_getch();
      }
    }
  if (last_op_failed)
    c = DEFINE_MACRO;
  else
    {
    if (  macexec
       && macro_block_range
       && (!line_table_cur->in_block)
       )
      {
      /* this interrupts macro replay if macro was working within a block
         and end of block has been reached */
      next_mess("Macro reached end of block.");
      macro_range_error = TRUE;
      last_op_failed = TRUE;
      c = DEFINE_MACRO;
      }
    else
      /* this gets the next fake "key-press" from the macro definition */
      c = get_macro_func();
    }
  return c;
  }

c = x_getch();
raw_c = c;

if (!next_char_raw)
  {
  /* this gets the next (real) key-press  */
  while (  (c != KB_ERR)
        && (!finished)
        )
    {
    /* this goes into a loop & gets as many characters as needed 
       to construct a logical key-press.  for printable chars this is one,
       but for escape sequences generated by function or cursor keys
       this can be many */
    if (!find_esc_char(c))
      {
      esc_current = NULL;
      if (!find_esc_char(c))
        {
        esc_current = NULL;
        finished = TRUE;
        }
      }
    else
      {
      /* when finished then a logical key press has been received.
         a logical key press is a sequence from the key-mapping table
         and also equates to a medit function */
      if (esc_current->next_level == NULL)
        {
        c = esc_current->func_code;
        esc_current = NULL;
        finished = TRUE;
        }
      }

    if (!finished)
      {
      /* get the next char, if error then reset the escape-sequence table pointer
         back to zero, so that the next valid char starts a fresh escape sequence */
      c = x_getch();
      if (c == KB_ERR)
        if (esc_current == NULL)
          c = KB_ERR;
      }
    }
  }

if (  (macro_state == DEFINE)
   && (c != KB_ERR)
   )
  /* then defining a macro but do not insert the char if error */
  insert_macro_func(c);

last_op_failed = FALSE;

return c;
}

/*************************/
int map_func(int func)
{
int i,di,ki,ic,f,c,field,error;
char temp_str[LINEMAXLEN];
char temp_str2[LINEMAXLEN];
unsigned int kcode[81];
char temp_kdesc[14];
char kdesc[14];

i = 0;
f = 0;

while(i < SCREENLINES-1)
  {
  cmove(i,0);
  clreol();
  i += 1;
  }
i = 0;

while ((func_code[f] != func) && (func_code[f] != NO_COMMAND)) f+=1;
strcpy(kdesc,"");

enter_bold();
enter_inv();
i += 1;
cmove(i,0);
clreol();
sprintf(temp_str,"           Map Medit '%s' function to a key            ",func_desc[f]);
x_waddstr(temp_str,NO_VX_CHECK,0,FALSE);

normal();
enter_bold();
i += 2;
cmove(i,0);
clreol();
sprintf(temp_str,"Press TAB to move between items, press RETURN when finished:");
x_waddstr(temp_str,NO_VX_CHECK,0,FALSE);

i += 2;
di = i;
cmove(i,0);
clreol();
sprintf(temp_str,"Description of key ");
x_waddstr(temp_str,NO_VX_CHECK,0,FALSE);

cmove(i,20);

i += 2;
ki = i;
cmove(i,0);
clreol();
sprintf(temp_str,"Press the key on the terminal ");
x_waddstr(temp_str,NO_VX_CHECK,0,FALSE);

cmove(i,31);

normal();

strcpy(kdesc,"");

error = FALSE;
COMMAND_MAX = 13;
cmove(di,20);
field = 1;
ic = 0;
c = '\0';

/* flush terminal input buffer & wait until no key is being pressed */
non_block_kb(0);

while ((c = x_getch()) != KB_ERR);

block_kb();

while (c != NEW_LINE)
  {
  if (field == 1)
    {
    strcpy(temp_kdesc,kdesc);
    c = get_string(temp_kdesc,14,NO_FUNKEYS,di,20,NO_SAVE,NO_CTRL,TAB_ENDS_INPUT,"");
    strcpy(kdesc,temp_kdesc);
    }
  else
    {
    /* flush terminal input buffer & wait until no key is being pressed */
    non_block_kb(0);
    while ((c = x_getch()) != KB_ERR);
    while ((c = x_getch()) == KB_ERR);
    ic = 0;
    while (  (c != KB_ERR)
          && (c != TAB)
          && (ic < 80)
          )
      {
      if (c != TAB)
        {
        cmove(ki,31);
        enter_inv();
#ifndef MSDOS
          enter_under();
          enter_bold();
#endif
        x_waddstr("Detected",NO_VX_CHECK,0,FALSE);
        normal();
        cmove(ki,31);
  
        kcode[ic] = (unsigned int) c;
  
        ic++;
        c = x_getch();
        }
      }
    kcode[ic] = 0;
    c = TAB;
    block_kb();
    }

  if (c == NEW_LINE)
    if (  (strcmp(kdesc,"") != STR_SAME)
       && (ic == 0)
       )
      {
      c = '\0';
      next_mess("Key has a description but no escape sequence.");
      error = TRUE;
      message_pending = disp_mess();
      if (field == 1)
        cmove(di,20);
      else if (field == 2)
        cmove(ki,31);
      }
    else if (error)
      {
      next_mess("");
      message_pending = disp_mess();
      error = FALSE;
      }

  if (c == TAB)
    if (field == 1)
      {
      field = 2;
      ic = 0;
      cmove(ki,31);
      clreol();
      cmove(ki,31);
      }
    else
      {
      field = 1;
      cmove(di,20);
      }
  }
normal();
help_reverse = 0;

COMMAND_MAX = command_max;

if (ic != 0)
  {
  sprintf(temp_str,"%X \"%s\" ",func,kdesc);
  i = 0;
  while(i < ic)
    {
    sprintf(temp_str2,"%X ",kcode[i]);
    strcat(temp_str,temp_str2);
    i+=1;
    }
  insert_line_text(line_table_cur,temp_str);
  }

if (ic == 0)
  return TRUE;
else
  return FALSE;
}

/*****************************************************************************/
char query(char mess[])
{
int mess_len;
int prompt_len;
char answer[16];

prompt_len = (int)strlen(command_prompt);
strcpy(answer,"");
mess_len = (int)strlen(mess) + prompt_len;
cmove(SCREENLINES-1,prompt_len);
clreol();
s_waddstr(mess,NO_VX_CHECK,0,prompt_len,SCREENCOLS-2,FALSE);
cmove(SCREENLINES-1,mess_len);
get_string(answer,16,NO_FUNKEYS,SCREENLINES-1,mess_len,NO_SAVE,NO_CTRL,NO_TAB_ENDS_INPUT,"");
upper_case(answer);
zap_spaces(answer);
cmove(SCREENLINES-1,9);
clreol();
if (  (strcmp(answer,"YES") == STR_SAME)
   || (strcmp(answer,"Y") == STR_SAME)
   )
  return 'Y';
else if (  (strcmp(answer,"NO") == STR_SAME)
        || (strcmp(answer,"N") == STR_SAME)
        )
  return 'N';
else
  return 'C';
}

/*****************************************************************************/
char query_with_prompt(char mess[],char prompt[])
{
int mess_len;
int prompt_len;
char answer[16];

prompt_len = (int)strlen(prompt);
strcpy(answer,"");
mess_len = (int)strlen(mess) + prompt_len;
cmove(SCREENLINES-1,0);
clreol();
normal();
enter_bold();
s_waddstr(prompt,NO_VX_CHECK,0,0,SCREENCOLS-2,FALSE);
normal();
s_waddstr(mess,NO_VX_CHECK,0,prompt_len,SCREENCOLS-2,FALSE);
cmove(SCREENLINES-1,mess_len);
get_string(answer,16,NO_FUNKEYS,SCREENLINES-1,mess_len,NO_SAVE,NO_CTRL,NO_TAB_ENDS_INPUT,"");
upper_case(answer);
zap_spaces(answer);
cmove(SCREENLINES-1,9);
clreol();
if (  (strcmp(answer,"YES") == STR_SAME)
   || (strcmp(answer,"Y") == STR_SAME)
   )
  return 'Y';
else if (  (strcmp(answer,"NO") == STR_SAME)
        || (strcmp(answer,"N") == STR_SAME)
        )
  return 'N';
else
  return 'C';
}

/*****************************************************************************/
void map_functions()
{
int i,finished;
char temp_str[82];

if (!file_empty)
  {
  if (query("File not empty. Do you want to continue (Y or N)? ") != 'Y')
    return;
  }

if (line_needs_updating)
  updateline(LEAVE_TRAILING_SPACES);

prev_key_desc_table = key_desc_table;

i = 0;
while (func_code[i] != NO_COMMAND)
  {
  finished = FALSE;
  while (!finished)
    finished = map_func(func_code[i]);
  i+=1;
  }
finished = FALSE;
while (!finished)
  finished = map_func(func_code[i]);

showscreen();
load_buffer();
}

/*****************************************************************************/
void load_key_map()
{
unsigned int esc_char[81];
char first_token[STRINGMAX];
char second_token[STRINGMAX];
int  quoted;
char next_token[STRINGMAX];
char *keymap_ptr;
char line_buffer[LINEMAXLEN];
char temp_str[LINEMAXLEN];
int * quoted_ptr;
char quote_str[2];
int fcode,err;
int * int_ptr;
int c,i;
int command_func_mapped = FALSE;
int ctrl_c_mapped = FALSE;
int ctrl_x_mapped = FALSE;
int ctrl_e_mapped = FALSE;

struct stat fstat_buffer;

quoted_ptr = (int *) &quoted;
quote_str[0] = '\0';
quote_str[1] = '\0';

fptr = fopen(keymapname,"r");

if (fptr == NULL)
  {
  strncpy(keymapname,pathname,KEYMAPNAME_MAX-1);
  strncat(keymapname,"medit.key",KEYMAPNAME_MAX-1);
  fptr = fopen(keymapname,"r");
  }

if (fptr == NULL)
  {
  strcpy(keymapname,"medit.key");
  fptr = fopen(keymapname,"r");
  }

if (fptr == NULL)
  {
  default_key_map();
  if (keymap)
    next_mess("Missing keymap file - press Ctrl-Q then enter 'help'.");
#ifndef MSDOS
  else
    next_mess("Default keymap - press Ctrl-Q then enter 'help'.");
#endif
  }
else
  {
  /* check that "keymapname" is an ordinary file */

  stat(keymapname,&fstat_buffer);
  if ((fstat_buffer.st_mode & S_IFDIR) == S_IFDIR)
    {
    sprintf(temp_str,"Keymap file %s is a directory.",keymapname);
    strcpy(errortext,temp_str);
    finish(1);
    }
  else if ((fstat_buffer.st_mode & S_IFREG) != S_IFREG)
    {
    sprintf(temp_str,"Keymap file %s is not an ordinary file.",keymapname);
    strcpy(errortext,temp_str);
    finish(1);
    }

  err = getline2(fptr,line_buffer,LINEMAXLEN);
  if (err != UNIX_OK)
    {
    default_key_map();
    next_mess("Key map file read error - press Ctrl-Q then enter 'help'.");
    }
  else if (feof(fptr))
    {
    default_key_map();
    next_mess("Key map file empty - press Ctrl-Q then enter 'help'.");
    }
  else
    while (  (! feof(fptr))
          && (err == UNIX_OK)
          )
      {
      keymap_ptr = (char *) &line_buffer;
  
      /* start parsing by skipping leading spaces */
      while (*keymap_ptr == ' ') keymap_ptr++;
  
      if (  (strcmp(line_buffer,"") != STR_SAME)
         && (*keymap_ptr != '\0')
         )
        {
        quote_str[0] = '\0';
        
        keymap_ptr = parse(first_token,keymap_ptr,quote_str,NOT_QUOTED,STRINGMAX-1);

        quoted = FALSE;
        quote_str[0] = '"';
        if (  (*keymap_ptr == '"')
           || (*keymap_ptr == '\'')
           || (*keymap_ptr == '`')
           )
          {
          quote_str[0] = *keymap_ptr;
          quoted = TRUE;
          keymap_ptr++;
          }
        keymap_ptr = parse(second_token,keymap_ptr,quote_str,*quoted_ptr,STRINGMAX-1);
        if (  (*keymap_ptr == quote_str[0])
           && (quoted)
           )
          {
          quoted = FALSE;
          quote_str[0] = '\0';
          keymap_ptr++;
          }

        int_ptr = (int *) &fcode;
 
        if (sscanf(first_token,"%X",int_ptr) != 1)
          {
          strcpy(errortext,"Invalid function code in key map file.");
          finish(1);
          }
        else
          if (strcmp(second_token,"") != STR_SAME)
            {
            while ((int)strlen(second_token) < 13)
              {
              strcpy(temp_str," ");
              strcat(temp_str,second_token);
              strcpy(second_token,temp_str);
              }

            insert_key_desc(second_token,fcode);
            }

        if (*keymap_ptr == '\0')
          {
          strcpy(errortext,"Key escape codes missing from key map file.");
          finish(1);
          }

        i = 0;
        while (  (*keymap_ptr != '\0')
              && (i < 80)
              )
          {
          keymap_ptr = parse(next_token,keymap_ptr,quote_str,NOT_QUOTED,STRINGMAX-1);
          int_ptr = (int *) &esc_char[i];
          if (sscanf(next_token,"%X",int_ptr) != 1)
            {
            sprintf(errortext,"Invalid key escape code in key map file: %d",next_token[0]);
            finish(1);
            }
          i += 1;
          }
        if (i > 79)
          {
          sprintf(errortext,"More than 80 key escape codes in '%s' mapping.",second_token);
          finish(1);
          }

        esc_char[i] = 0;
        insert_seq(esc_char,fcode);

        if (fcode == COMMAND_LINE)
          command_func_mapped = TRUE;

        if (fcode == DEFINE_MACRO)
          macro_define_mapped = TRUE;

        if (fcode == REPLAY_MACRO)
          macro_replay_mapped = TRUE;

        if (fcode == PASTE_BLOCK)
          pasteblk_mapped = TRUE;

        if (fcode == DEL_BLOCK)
          deleteblk_mapped = TRUE;

        if (fcode == MOVE_BLOCK)
          moveblk_mapped = TRUE;

        if (fcode == COPY_BLOCK)
          copyblk_mapped = TRUE;

        if (fcode == MARK_BLOCK)
          markblk_mapped = TRUE;

        if (esc_char[0] == KB_CTRL_C)
          ctrl_c_mapped = TRUE;

        if (esc_char[0] == KB_CTRL_E)
          ctrl_e_mapped = TRUE;

        if (esc_char[0] == KB_CTRL_X)
          ctrl_x_mapped = TRUE;
        }

      err = getline2(fptr,line_buffer,LINEMAXLEN);
      if (err != UNIX_OK)
        {
        default_key_map();
        next_mess("Key map file read error.");
        }
      }

/* do them a favour - always attempt to map COMMAND_LINE function to Ctrl-C, 
   providing those keys are not already in use.
*/


  if (!ctrl_c_mapped)
     {
     esc_char[0] = KB_CTRL_C;
     esc_char[1] = 0;
     insert_seq(esc_char,COMMAND_LINE);
     }
   else
     if (!command_func_mapped)
        {
        sprintf(temp_str,"Command line function not mapped to any key.");
        strcpy(errortext,temp_str);
        finish(1);
        }
  }

if (  (macro_define_mapped)
   && (macro_replay_mapped)
   )
  macro_cmd_mapped = TRUE;
else
  macro_cmd_mapped = FALSE;

if (  (copyblk_mapped)
   && (deleteblk_mapped)
   && (pasteblk_mapped)
   && (moveblk_mapped)
   && (markblk_mapped)
   )
  blk_cmd_mapped = TRUE;
else
  blk_cmd_mapped = FALSE;

esc_current = NULL;
}

/*****************************************************************************/
void default_key_map()
{
int i,j,k;
unsigned char * p;
const char * term;
unsigned int esc_char[STRINGMAX];
unsigned char temp_esc[STRINGMAX];

#ifdef MSDOS
esc_char[0] = KB_F8;
esc_char[1] = 0;
insert_seq(esc_char,COMMAND_LINE);
insert_key_desc("           F8",COMMAND_LINE);

esc_char[0] = KB_F9;
esc_char[1] = 0;
insert_seq(esc_char,HELP);
insert_key_desc("           F9",HELP);

esc_char[0] = KB_F1;
esc_char[1] = 0;
insert_seq(esc_char,DEL_LINE);
insert_key_desc("           F1",DEL_LINE);

esc_char[0] = KB_CTRL_DEL;
esc_char[1] = 0;
insert_seq(esc_char,CLEAR_LINE);
insert_key_desc("     Ctrl-Del",CLEAR_LINE);

esc_char[0] = KB_F4;
esc_char[1] = 0;
insert_seq(esc_char,FIND_FOR);
insert_key_desc("           F4",FIND_FOR);

esc_char[0] = KB_F3;
esc_char[1] = 0;
insert_seq(esc_char,FIND_BACK);
insert_key_desc("           F3",FIND_BACK);

esc_char[0] = KB_F5;
esc_char[1] = 0;
insert_seq(esc_char,START_FILE);
insert_key_desc("           F5",START_FILE);

esc_char[0] = KB_F6;
esc_char[1] = 0;
insert_seq(esc_char,END_FILE);
insert_key_desc("           F6",END_FILE);

esc_char[0] = KB_F7;
esc_char[1] = 0;
insert_seq(esc_char,MARK_BLOCK);
insert_key_desc("           F7",MARK_BLOCK);

esc_char[0] = KB_SHIFT_F7;
esc_char[1] = 0;
insert_seq(esc_char,CLEAR_MARK);
insert_key_desc("     Shift-F7",CLEAR_MARK);

esc_char[0] = KB_F2;
esc_char[1] = 0;
insert_seq(esc_char,DEL_BLOCK);
insert_key_desc("           F2",DEL_BLOCK);

esc_char[0] = KB_F10;
esc_char[1] = 0;
insert_seq(esc_char,PASTE_BLOCK);
insert_key_desc("          F10",PASTE_BLOCK);

esc_char[0] = KB_F11;
esc_char[1] = 0;
insert_seq(esc_char,COPY_BLOCK);
insert_key_desc("          F11",COPY_BLOCK);

esc_char[0] = KB_F12;
esc_char[1] = 0;
insert_seq(esc_char,MOVE_BLOCK);
insert_key_desc("          F12",MOVE_BLOCK);

esc_char[0] = KB_CTRL_HOME;
esc_char[1] = 0;
insert_seq(esc_char,START_FILE);
insert_key_desc("    Ctrl-Home",START_FILE);

esc_char[0] = KB_CTRL_END;
esc_char[1] = 0;
insert_seq(esc_char,END_FILE);
insert_key_desc("     Ctrl-End",END_FILE);

esc_char[0] = KB_CTRL_C;
esc_char[1] = 0;
insert_seq(esc_char,COPY_BLOCK);
insert_key_desc("       Ctrl-C",COPY_BLOCK);

esc_char[0] = KB_CTRL_V;
esc_char[1] = 0;
insert_seq(esc_char,PASTE_BLOCK);
insert_key_desc("       Ctrl-V",PASTE_BLOCK);

esc_char[0] = KB_CTRL_X;
esc_char[1] = 0;
insert_seq(esc_char,DEL_BLOCK);
insert_key_desc("       Ctrl-X",DEL_BLOCK);

esc_char[0] = KB_CTRL_Z;
esc_char[1] = 0;
insert_seq(esc_char,CONTROL_CHAR);
insert_key_desc("       Ctrl-Z",CONTROL_CHAR);

esc_char[0] = KB_CTRL_F8;
esc_char[1] = 0;
insert_seq(esc_char,DEFINE_MACRO);
insert_key_desc("      CTRL-F8",DEFINE_MACRO);

esc_char[0] = KB_SHIFT_F8;
esc_char[1] = 0;
insert_seq(esc_char,REPLAY_MACRO);
insert_key_desc("     SHIFT-F8",REPLAY_MACRO);

esc_char[0] = KB_DEL;
esc_char[1] = 0;
insert_seq(esc_char,DEL_CHAR);

esc_char[0] = KB_INS;
esc_char[1] = 0;
insert_seq(esc_char,TOGGLE_INS);

esc_char[0] = KB_PGDN;
esc_char[1] = 0;
insert_seq(esc_char,PAGEDOWN);

esc_char[0] = KB_PGUP;
esc_char[1] = 0;
insert_seq(esc_char,PAGEUP);

esc_char[0] = KB_UP;
esc_char[1] = 0;
insert_seq(esc_char,CURSOR_UP);

esc_char[0] = KB_DOWN;
esc_char[1] = 0;
insert_seq(esc_char,CURSOR_DOWN);

esc_char[0] = KB_LEFT;
esc_char[1] = 0;
insert_seq(esc_char,CURSOR_LEFT);

esc_char[0] = KB_RIGHT;
esc_char[1] = 0;
insert_seq(esc_char,CURSOR_RIGHT);

esc_char[0] = KB_HOME;
esc_char[1] = 0;
insert_seq(esc_char,START_LINE);

esc_char[0] = KB_END;
esc_char[1] = 0;
insert_seq(esc_char,END_LINE);

macro_define_mapped = TRUE;
macro_replay_mapped = TRUE;

copyblk_mapped = TRUE;
deleteblk_mapped = TRUE;
pasteblk_mapped = TRUE;
moveblk_mapped = TRUE;
markblk_mapped = TRUE;

esc_current = NULL;

#else	/* not MSDOS */

char key[][7] = 
  {"kbs","khlp","khome","kend","knp","kpp","kcub1","kcuf1","kcuu1","kcud1",""};
int func_code[] =
  {
  BACKSPACE,
  HELP,
  START_LINE,
  END_LINE,
  PAGEDOWN,
  PAGEUP,
  CURSOR_LEFT,
  CURSOR_RIGHT,
  CURSOR_UP,
  CURSOR_DOWN,
  };

/* attempt to automatically use real cursor keys in default key map */
k = 0;
while (key[k][0] != '\0')
  {
  i = 0;
  j = 0;

  if (get_key_str((unsigned char *) &temp_esc,key[k]))
    {
    while ((temp_esc[j] != '\0') && (i < STRINGMAX))
      {
      esc_char[i] = (unsigned int) temp_esc[j];
      j += 1;
      i += 1;
      }
    if (i <= STRINGMAX)
      {
      esc_char[i] = (unsigned int) temp_esc[j];
      insert_seq(esc_char,func_code[k]);
      }
    }
  k += 1;
  }

term = getenv("TERM");

if (strcmp(term,"xterm") == STR_SAME)
	{
	esc_char[0] = 27;  /* Escape */
	esc_char[1] = '[';  /* [ */

	esc_char[2] = 'A';
	insert_seq(esc_char,CURSOR_UP);
	
	esc_char[2] = 'B';
	insert_seq(esc_char,CURSOR_DOWN);
	
	esc_char[2] = 'D';
	insert_seq(esc_char,CURSOR_LEFT);
	
	esc_char[2] = 'C';
	insert_seq(esc_char,CURSOR_RIGHT);
	
	esc_char[3] = '~';

	esc_char[2] = '2';
	insert_seq(esc_char,TOGGLE_INS);
	
	esc_char[2] = '3';
	insert_seq(esc_char,DEL_CHAR);

	esc_char[1] = 'O';
	esc_char[3] = 0;

	esc_char[2] = 'H';
	insert_seq(esc_char,START_LINE);
	
	esc_char[2] = 'F';
	insert_seq(esc_char,END_LINE);
	}

esc_char[0] = KB_CTRL_Q;
esc_char[1] = 0;
insert_seq(esc_char,COMMAND_LINE);
insert_key_desc("       Ctrl-Q",COMMAND_LINE);

esc_char[0] = KB_CTRL_Y;
esc_char[1] = 0;
insert_seq(esc_char,DEL_LINE);
insert_key_desc("       Ctrl-Y",DEL_LINE);

esc_char[0] = KB_CTRL_Z;
esc_char[1] = 0;
insert_seq(esc_char,CONTROL_CHAR);
insert_key_desc("       Ctrl-Z",CONTROL_CHAR);

esc_char[0] = KB_CTRL_F;
esc_char[1] = 0;
insert_seq(esc_char,FIND_FOR);
insert_key_desc("       Ctrl-F",FIND_FOR);

esc_char[0] = KB_CTRL_T;
esc_char[1] = 0;
insert_seq(esc_char,START_FILE);
insert_key_desc("       Ctrl-T",START_FILE);

esc_char[0] = KB_CTRL_E;
esc_char[1] = 0;
insert_seq(esc_char,END_FILE);
insert_key_desc("       Ctrl-E",END_FILE);

esc_char[0] = KB_CTRL_B;
esc_char[1] = 0;
insert_seq(esc_char,MARK_BLOCK);
insert_key_desc("       Ctrl-B",MARK_BLOCK);

esc_char[0] = KB_CTRL_V;
esc_char[1] = 0;
insert_seq(esc_char,PASTE_BLOCK);
insert_key_desc("       Ctrl-V",PASTE_BLOCK);

esc_char[0] = KB_CTRL_C;
esc_char[1] = 0;
insert_seq(esc_char,COPY_BLOCK);
insert_key_desc("       Ctrl-C",COPY_BLOCK);

esc_char[0] = KB_CTRL_K;
esc_char[1] = 0;
insert_seq(esc_char,MOVE_BLOCK);
insert_key_desc("       Ctrl-K",MOVE_BLOCK);

esc_char[0] = KB_CTRL_X;
esc_char[1] = 0;
insert_seq(esc_char,DEL_BLOCK);
insert_key_desc("       Ctrl-X",DEL_BLOCK);

esc_char[0] = KB_CTRL_N;
esc_char[1] = 0;
insert_seq(esc_char,CLEAR_MARK);
insert_key_desc("       Ctrl-N",CLEAR_MARK);

esc_char[0] = KB_CTRL_P;
esc_char[1] = 0;
insert_seq(esc_char,PAGEDOWN);
insert_key_desc("       Ctrl-P",PAGEDOWN);

esc_char[0] = KB_CTRL_O;
esc_char[1] = 0;
insert_seq(esc_char,PAGEUP);
insert_key_desc("       Ctrl-O",PAGEUP);

esc_char[0] = KB_CTRL_U;
esc_char[1] = 0;
insert_seq(esc_char,DEFINE_MACRO);
insert_key_desc("       Ctrl-U",DEFINE_MACRO);

esc_char[0] = KB_CTRL_W;
esc_char[1] = 0;
insert_seq(esc_char,REPLAY_MACRO);
insert_key_desc("       Ctrl-W",REPLAY_MACRO);

esc_char[0] = KB_CTRL_L;
esc_char[1] = 0;
insert_seq(esc_char,START_LINE);
insert_key_desc("       Ctrl-L",START_LINE);

esc_char[0] = KB_CTRL_R;
esc_char[1] = 0;
insert_seq(esc_char,END_LINE);
insert_key_desc("       Ctrl-R",END_LINE);

esc_char[0] = KB_BACKSPACE;
esc_char[1] = 0;
insert_seq(esc_char,BACKSPACE);

esc_char[0] = KB_DEL;
esc_char[1] = 0;
insert_seq(esc_char,BACKSPACE);

esc_char[0] = KB_NEW_LINE;
esc_char[1] = 0;
insert_seq(esc_char,NEW_LINE);

macro_define_mapped = TRUE;
macro_replay_mapped = TRUE;
blk_cmd_mapped = TRUE;
copyblk_mapped = TRUE;
deleteblk_mapped = TRUE;
pasteblk_mapped = TRUE;
moveblk_mapped = TRUE;
markblk_mapped = TRUE;

esc_current = NULL;
next_mess("Default keymap - press Ctrl-Q then enter \"help\" for keys.");
#endif
}

/**************************/
void load_buffer()
{
strcpy(line_buffer,line_table_cur->text);
}

/**************************/
void dec_command_start()
{
if (command_start != command_end)
  {
  command_start--;
  if (command_start == -1)
    command_start = (COMMAND_IMAX-1);
  if (command_start == command_end)
    {
    command_start++;
    if (command_start == COMMAND_IMAX)
      command_start = 0;
    }
  }
}

/**************************/
void inc_command_start()
{
if (command_start != command_end)
  {
  command_start++;
  if (command_start == COMMAND_IMAX)
    command_start = 0;
  if (command_start == command_end)
    {
    command_start--;
    if (command_start == -1)
      command_start = (COMMAND_IMAX-1);
    }
  }
}

/**************************/
void dec_command_index()
{
if (command_index != command_start)
  {
  command_index--;
  if (command_index == -1)
    command_index = (COMMAND_IMAX-1);
  }
else
  command_index = command_end;
}

/**************************/
void inc_command_index()
{
if (command_index != command_end)
  {
  command_index++;
  if (command_index == COMMAND_IMAX)
    command_index = 0;
/*
  if (command_index == command_end)
    {
    command_index--;
    if (command_index == -1)
      command_index = (COMMAND_IMAX-1);
    }
*/
  }
}

/**************************/
void inc_command_end()
{
command_end++;
if (command_end == COMMAND_IMAX)
  command_end = 0;
if (command_end == command_start)
  {
  command_start++;
  if (command_start == COMMAND_IMAX)
    command_start = 0;
  }
}

/**************************/
int get_string( char command_str[],
                int command_max,
                int funkeys_allowed,
                int screeny,
                int screenx,
                int save_command,
                int ctrl_allowed,
                int tab_ends_input,
                char prompt[])
{
int c_ptr,i,c,count;
int finished,ins_mode_copy,status_sx,status_vx;
int command_from_hist = FALSE;
char * buffer_ptr;
char ctrl_string[STRINGMAX];

if (prompt[0] != '\0')
  {
  normal();
  enter_bold();
  cmove(screeny,screenx-(int)strlen(prompt));
  clreol();
  x_waddstr(prompt,NO_VX_CHECK,0,FALSE);
  }

normal();
status_bold = 0;
status_standout = 0;
status_reverse = 0;
status_blink = 0;
status_underline = 0;

command_index = command_end;
i = 0;
status_vx = 0;

/* strcpy(command_str,""); */
ins_mode_copy = insert_mode;

finished = FALSE;

c = decode_key();

while (  (c != NEW_LINE)
      && (! finished)
      && (  (c != TAB)
         || (!tab_ends_input)
         )
      )
  {
/* add char to command line */
  if (  (  (!ctrl_allowed)
        && (  (  (c >= CHAR_SPACE)
              && (c < CHAR_DEL)
              )
           || (c == TAB)
           )
        )
     || (  (ctrl_allowed)
        && (c >= CHAR_NULL)
        && (c <= CHAR_255)
        && (c != BACKSPACE)
        )
     )
    {
    if (!ctrl_allowed)
      next_char_raw = FALSE;

    if (insert_mode)
      {
      if ((int)strlen(command_str) < (command_max-1))
        {
        ins_char_str(command_str,i,c,command_max-1);
        i++;
        command_from_hist = FALSE;
        }
      }
    else
      {
      if (i < (command_max-1))
        {
        if (command_str[i] == '\0')
          ins_char_str(command_str,i,c,command_max-1);
        else
          command_str[i] = c;
        i++;
        command_from_hist = FALSE;
        }
      }
    }

/* Control Char - set ctrl_char_next flag */

  else if (c == CONTROL_CHAR)
    {
    if (!ctrl_allowed)
      {
      count = control_char(ctrl_string);
      c_ptr = 0;
      while (c_ptr < count)
        {
        if (insert_mode)
          {
          if ((int)strlen(command_str) < (command_max-1))
            {
            ins_char_str(command_str,i,ctrl_string[c_ptr],command_max-1);
            i++;
            command_from_hist = FALSE;
            }
          }
        else
          {
          if (c_ptr < (command_max-1))
            {
            if (command_str[c_ptr] == '\0')
              ins_char_str(command_str,i,ctrl_string[c_ptr],command_max-1);
            else
              command_str[i] = ctrl_string[c_ptr];
            i++;
            command_from_hist = FALSE;
            }
          }

        c_ptr++;
        }
      cmove(screeny,screenx-(int)strlen(prompt));
      normal();
      enter_bold();
      clreol();
      s_waddstr(prompt,NO_VX_CHECK,0,screenx-(int)strlen(prompt),SCREENCOLS-2,FALSE);
      normal();
      status_bold = 0;
      status_standout = 0;
      status_reverse = 0;
      status_blink = 0;
      status_underline = 0;
      }
    }


/* Insert - switch insert/overtype mode */

  else if (c == TOGGLE_INS)
    {
    if (insert_mode)
      insert_mode = FALSE;
    else
      insert_mode = TRUE;
    }

/* cursor up - previous command */
  else if (c == CURSOR_UP)
    {
    if (  (command_start != command_end)
       && (save_command)
       )
      {
      if (command_index == -1)
        command_index = command_end;
      dec_command_index();
      i = 0;
      strncpy(command_str,command_hist[command_index],PREV_COMMAND_MAX);
      command_from_hist = TRUE;
      }
    }

/* cursor down - next command */
  else if (c == CURSOR_DOWN)
    {
    if (  (command_start != command_end)
       && (save_command)
       )
      {
      if (command_index == command_end)
        command_index = command_start;
      else
        inc_command_index();
      i = 0;
      strncpy(command_str,command_hist[command_index],PREV_COMMAND_MAX);
      command_from_hist = TRUE;
      }
    }

/* command line - goto end of command history */
  else if (c == COMMAND_LINE)
    {
    if (  (command_start != command_end)
       && (save_command)
       )
      {
      command_index = command_end;
      i = 0;
      strncpy(command_str,command_hist[command_index],PREV_COMMAND_MAX);
      command_from_hist = TRUE;
      }
    }

/* backspace */
  else if (  (c == BACKSPACE)
          || (  (c == DEL_LINE)
             && (ctrl_allowed)
             )
          )
    {
    if (i > 0)
      {
      shift_left_str(command_str,i,command_max);
      i = i - 1;
      command_from_hist = FALSE;
      }
    }

/* forwards delete */
  else if (c == DEL_CHAR)
    {
    shift_left_str(command_str,i+1,command_max);
    command_from_hist = FALSE;
    }

/* cursor left */
  else if (c == CURSOR_LEFT)
    {
    if (i > 0)
      i = i - 1;
    }
/* cursor right */
  else if (c == CURSOR_RIGHT)
    {
    if (i < (int) strlen(command_str))
      i = i + 1;
    }

/* delete line */
  else if (c == DEL_LINE)
    {
    i = 0;
    command_str[i] = '\0';
    command_from_hist = FALSE;
    }

/* clear line */
  else if (c == CLEAR_LINE)
    {
    command_str[i] = '\0';
    command_from_hist = FALSE;
    }

/* start of line */
  else if (c == START_LINE)
    {
    if (i > 0)
      i = 0;
    }

/* end of line */
  else if (c == END_LINE)
    {
    if (i < (int) strlen(command_str))
      i = (int) strlen(command_str);
    }

  status_sx = calc_status_sx(command_str,VX_CHECK,status_vx,i,screenx,SCREENCOLS-2,FALSE);
  while (status_sx > (SCREENCOLS - 2))
    {
    status_vx = status_vx + 5;
    status_sx = calc_status_sx(command_str,VX_CHECK,status_vx,i,screenx,SCREENCOLS-2,FALSE);
    }

  if (i <= status_vx)
    {
    status_vx = i-1;
    if (status_vx < 0) status_vx = 0;
    }

  cmove(screeny,screenx);
  s_waddstr(command_str,VX_CHECK,status_vx,screenx,SCREENCOLS-2,FALSE);
  clreol();

  status_sx = calc_status_sx(command_str,VX_CHECK,status_vx,i,screenx,SCREENCOLS-2,FALSE);
  cmove(screeny,status_sx);
  if (! finished)
    c = decode_key();
  }

/* truncate trailing spaces */
buffer_ptr = command_str;
if (*buffer_ptr != '\0')
  {
  while (*buffer_ptr != '\0')
    buffer_ptr++;
  buffer_ptr--;
  while (*buffer_ptr == ' ')
    buffer_ptr--;
  buffer_ptr++;
  *buffer_ptr = '\0';
  }

if (  (strcmp(command_str,"") != STR_SAME)
   && (save_command)
   && (!command_from_hist)
   && (macro_state == MAC_NULL)
   )
  {
  strncpy(command_hist[command_end],command_str,PREV_COMMAND_MAX);
  inc_command_end();
  strcpy(command_hist[command_end],"");
  }
insert_mode = ins_mode_copy;

status_bold = A_BOLD;
status_standout = 0;
status_reverse = 0;
status_blink = 0;
status_underline = 0;

return c;
}

/**************************/
void moveblock()
{
struct line_rec *line_table_ptr;
struct line_rec *line_table_prev;
int top_of_file = TRUE;

if (  macexec
   && macro_block_range
   )
  {
  next_mess("Macro terminated by MOVE-BLOCK command.");
  macro_range_error = TRUE;
  last_op_failed = TRUE;
  }
else if (!block_marked)
  {
  last_op_failed = TRUE;
  next_mess("No block marked.");
  }
else
  {
  line_table_ptr = line_table_cur;
  line_table_prev = line_table_cur;
  up_no_upd();
  if (line_table_prev != line_table_cur)
    {
    line_table_prev = line_table_cur;
    down_no_upd();
    top_of_file = FALSE;
    }
  if (line_table_ptr->in_block)
    {
    last_op_failed = TRUE;
    next_mess("Destination must be outside block.");
    }
  else
    {
    deleteblock(FROM_MOVEBLOCK);
    line_table_cur = line_table_ptr;
    pasteblock(FROM_MOVEBLOCK);
    showblock(NO_HILITE);
    highlight_block(FALSE);
    block_marked = FALSE;
    line_table_block_start = line_table_block_end = NULL;
    showscreen();
    restore_status(ALL_STATUS,SCREENLINES-1,FALSE);
    next_mess("Block moved.");
    file_needs_saving = TRUE;
    }
  }
}

/**************************/
void dup_block()
{
struct line_rec *line_table_ptr;

if (  macexec
   && macro_block_range
   )
  {
  next_mess("Macro terminated by COPY-BLOCK command.");
  macro_range_error = TRUE;
  last_op_failed = TRUE;
  }
else if (!block_marked)
  {
  last_op_failed = TRUE;
  next_mess("No block marked.");
  }
else
  {
  line_table_ptr = line_table_cur;

  copyblock(FROM_DELETEBLOCK);
  if (!last_op_failed)
    {
    line_table_cur = line_table_ptr;
    pasteblock(FROM_MOVEBLOCK);
    showblock(NO_HILITE);
    highlight_block(FALSE);
    block_marked = FALSE;
    line_table_block_start = line_table_block_end = NULL;
    showscreen();
    restore_status(ALL_STATUS,SCREENLINES-1,FALSE);
    if (!last_op_failed)
      next_mess("Block copied.");
    file_needs_saving = TRUE;
    }
  }
}

/**************************/
void next_file()
{
int i;

if (arg_no < g_argc)
  {
  strncpy(filename,g_argv[arg_no],FILENAMEMAX-1);
  if (strcmp(filename,g_argv[arg_no]) != STR_SAME)
    {
    sprintf(errortext,"Filename argument > %d characters.",FILENAMEMAX-1);
    strcat(errortext,"\n\n");
    strcat(errortext,usage);
    finish(1);
    }
  arg_no += 1;

  empty_memory();
  readfile(filename,LOAD_FILE);
  if (!read_failed)
    {
    strcpy(file_text,"File: ");
    strncat(file_text,filename,FILENAMEMAX-1);
    new_count = 1;
    lines_counted = TRUE;
    }
  else
    {
    showscreen();
    last_op_failed = TRUE;
    }
  }
else
  finish(0);
}
  
/**************************/
void command_line()
{
char command_str[STRINGMAX];
char temp_token[STRINGMAX];
char * subst_filename;
char token[9][STRINGMAX];
char uc_token[9][STRINGMAX];
char temp_str[STRINGMAX];
char prev_filename[STRINGMAX];
char unexp_filename[STRINGMAX];
char quote_str[2];
char QUOTE_STR[2];

char *temp_ptr;
char *command_ptr;

int intarg = 0;
int i,j,t;
int find_dir;
int finished;
int ok_to_write;
int ok_to_quit;
int quoted;
int no_tokens_quoted=0;
int token_quoted[8] = {FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE,FALSE};
int * quoted_ptr;
int temp_cx;
int new_len;
int erroffset;

char c;

const char *errptr;

strcpy(temp_token,"");
strcpy(unexp_filename,filename);

cmove(SCREENLINES-1,9);

strcpy(command_str,"");
get_string(command_str,STRINGMAX,FUNKEYS_ALLOWED,SCREENLINES-1,9,SAVE_COMMAND,NO_CTRL,NO_TAB_ENDS_INPUT,command_prompt);
command_ptr = (char *) &command_str;

if (*command_ptr == '!')
  {
  strcpy(token[0],"!");
  token_quoted[0] = NOT_QUOTED;
  command_ptr++;
  strcpy(token[1],command_ptr);
  token_quoted[1] = NOT_QUOTED;
  strcpy(token[2],"");
  token_quoted[2] = NOT_QUOTED;
  strcpy(token[3],"");
  token_quoted[3] = NOT_QUOTED;
  strcpy(uc_token[0],"");
  strcpy(uc_token[1],"");
  strcpy(uc_token[2],"");
  strcpy(uc_token[3],"");
  }
else
  {
  t = 0;
  quoted = NOT_QUOTED;
  while (t < 8)
    {
    command_ptr = parse(temp_token,command_ptr,quote_str,quoted,STRINGMAX-1);

    strcpy(token[t],temp_token);
    
    upper_case(temp_token);
    strcpy(uc_token[t],temp_token);
    t+=1;
    if (!quoted)
      {
      /* The range of allowed "quote" characters can not be increased
         because of the possibility of them conflicting with the
         characters allowed in path/filenames
      */
      if (  (*command_ptr == '\'')
         || (*command_ptr == '"')
         || (*command_ptr == '`')
         )
        {
        quoted = QUOTED;
        token_quoted[t] = QUOTED;
        quote_str[0] = *command_ptr;
        quote_str[1] = '\0';
        QUOTE_STR[0] = *command_ptr;
        QUOTE_STR[1] = '\0';
        command_ptr++;
        }
      }
    else
      {
      no_tokens_quoted+=1;
      if (*command_ptr == quote_str[0])
        {
        if (  (strcmp(uc_token[0],"REPLACE") == STR_SAME)
           || (strcmp(uc_token[0],"R")       == STR_SAME)
           || (strcmp(uc_token[0],"RW")      == STR_SAME)
           || (strcmp(uc_token[0],"RW")      == STR_SAME)
           || (strcmp(uc_token[0],"RWC")     == STR_SAME)
           || (strcmp(uc_token[0],"RCW")     == STR_SAME)
           || (strcmp(uc_token[0],"REPEXP")  == STR_SAME)
           || (strcmp(uc_token[0],"RX")      == STR_SAME)
           )
          {
          if (no_tokens_quoted < 2)
            token_quoted[t] = QUOTED;
          else
            {
            quoted = NOT_QUOTED;
            quote_str[0] = '\0';
            }
          command_ptr++;
          }
        else
          {
          quoted = NOT_QUOTED;
          token_quoted[t] = NOT_QUOTED;
          quote_str[0] = '\0';
          command_ptr++;
          }
        }
      else
        quoted = NOT_QUOTED;
      }
    }
  }

/* COMMAND: quit : quit without saving */
  if (  (  (strcmp(uc_token[0],"QUIT") == STR_SAME)
        || (strcmp(uc_token[0],"Q") == STR_SAME)
        )
     && (  (strcmp(uc_token[1],"ALL") == STR_SAME)
        || (strcmp(uc_token[1],"A") == STR_SAME)
        || (strcmp(uc_token[1],"") == STR_SAME)
        )
     && (strcmp(uc_token[2],"") == STR_SAME)
     )
    {
    if (strcmp(filename,"") != STR_SAME)
      {
      if (  (!read_only_mode)
         && (file_needs_saving)
         )
        {
        c = query("File not saved. Do you want to save it (Y or N or C)? ");
        if (c == 'Y')
          ok_to_write = TRUE;
        else
          ok_to_write = FALSE;
        if (c == 'C')
          ok_to_quit = FALSE;
        else
          ok_to_quit = TRUE;
        }
      else
        {
        ok_to_write = FALSE;
        ok_to_quit = TRUE;
        }
      if (  (ok_to_write)
         && (ok_to_quit)
         )
        {
        save(SAVE_FILE_FLAG,OVERWRITE);
        if (  (! save_failed)
           && (! save_abandoned)
           )
          {
          sprintf(errortext," %s saved ok.",filename);
          cmove(SCREENLINES-1,0);
          clreol();
          if (  (strcmp(uc_token[1],"ALL") == STR_SAME)
             || (strcmp(uc_token[1],"A") == STR_SAME)
             )
            finish(0);
          else
            next_file();
          }
        else if (message_pending < 2)
          {
          last_op_failed = TRUE;
          next_mess("File not saved.");
          }
        }
      else if (  (!ok_to_write)
              && (ok_to_quit)
              )
        {
        if (  (!read_only_mode)
           && (file_needs_saving)
           )
          sprintf(errortext," %s NOT SAVED.",filename);
        else
          sprintf(errortext," quitted.");
        cmove(SCREENLINES-1,0);
        clreol();
        if (  (strcmp(uc_token[1],"ALL") == STR_SAME)
           || (strcmp(uc_token[1],"A") == STR_SAME)
           )
          finish(0);
        else
          next_file();
        }
      else
        {
        last_op_failed = TRUE;
        next_mess("Quit cancelled.");
        }
      }
    else
      {
      if (file_needs_saving)
        {
        c = query("File not saved. Do you want to save it (Y or N or C)? ");

        if (c == 'N')
          ok_to_quit = TRUE;
        else
          ok_to_quit = FALSE;
        }
      else
        ok_to_quit = TRUE;
      if (ok_to_quit)
        {
        if (file_needs_saving)
          sprintf(errortext," %s NOT SAVED.",filename);
        else
          sprintf(errortext," quitted.");
        cmove(SCREENLINES-1,0);
        clreol();
        if (  (strcmp(uc_token[1],"ALL") == STR_SAME)
           || (strcmp(uc_token[1],"A") == STR_SAME)
           )
          finish(0);
        else
          next_file();
        }
      else
        {
        last_op_failed = TRUE;
        next_mess("Quit cancelled.");
        }
      }
    }

/* COMMAND: tab : set tab stops */
  else if (  (  (strcmp(uc_token[0],"TAB") == STR_SAME)
             || (strcmp(uc_token[0],"T") == STR_SAME)
             )
          && (strcmp(uc_token[2],"") == STR_SAME)
          )
    {
    if (sscanf(token[1],"%d",&intarg) == 1)
      {
      j = 0;
      i = 1;
      while (i <= (SCREENMAX-1))
         {
         j += intarg;
         if (j == 0)
           tabstop[i] = 32000;
         else
           tabstop[i] = j;
         i = i + 1;
         }
      showscreen();
      next_mess("Tab stops reset.");
      }
    else
      {
      last_op_failed = TRUE;
      next_mess("Tab stop number is invalid.");
      }
    }

/* COMMAND: macdef : define macro */
  else if (  (  (strcmp(uc_token[0],"MACDEF") == STR_SAME)
             || (strcmp(uc_token[0],"MD") == STR_SAME)
             )
          && (strcmp(uc_token[1],"") == STR_SAME)
          && (!macro_cmd_mapped)
          )
    {
    define_macro();
    }

/* COMMAND: mac : replay macro */
  else if (  (strcmp(uc_token[0],"MAC") == STR_SAME)
          && (strcmp(uc_token[1],"") == STR_SAME)
          && (!macro_cmd_mapped)
          )
    {
    replay_macro();
    }

/* COMMAND: macexec , : repeat play macro */
  else if (  (  (strcmp(uc_token[0],"MACEXEC") == STR_SAME)
             || (strcmp(uc_token[0],"MX") == STR_SAME)
             )
          && (strcmp(uc_token[1],"") == STR_SAME)
          )
    {
    if (macro_state == MAC_NULL)
      {
      if (block_marked)
        macro_block_range = TRUE;
      else
        macro_block_range = FALSE;
      macexec = TRUE;
      replay_macro();
      }
    else if (macro_state == DEFINE)
      {
      next_mess("MACROEXEC command will be ignored on replay.");
      }
    }

/* COMMAND: map : map keys */
  else if (  (strcmp(uc_token[0],"MAP") == STR_SAME)
          && (strcmp(uc_token[1],"") == STR_SAME)
          )
    {
    map_functions();
    }

/* COMMAND: exit : save & exit */
  else if (  (  (strcmp(uc_token[0],"EXIT") == STR_SAME)
             || (strcmp(uc_token[0],"E") == STR_SAME)
             )
          && (strcmp(uc_token[2],"") == STR_SAME)
          )
    {
    if (read_only_mode) finish(0);

    if (  (file_needs_saving)
       || (strcmp(token[1],"") != STR_SAME)
       )
      {
      if (  (strcmp(filename,"") == STR_SAME)
         || (strcmp(token[1],"") != STR_SAME)
         )
        {  
        if (strcmp(token[1],"") != STR_SAME)
          {
          temp_cx = 0;
          strcpy(unexp_filename,token[1]);
          if (!no_tilde)
          if (!token_quoted[1])
          if (in_str(token[1],"~",&temp_cx,FORWARDS))
            {
            subst_filename = repl_string(&new_len,token[1],"~",home,&temp_cx);
            if (new_len >= STRINGMAX)
              {
              free(subst_filename);
              next_mess("Command line too long.");
              restore_status(ALL_STATUS,SCREENLINES-1,FALSE);
              return;
              }
            else if (subst_filename == NULL)
              {
              next_mess("Not enough memory available for ~ substitution.");
              restore_status(ALL_STATUS,SCREENLINES-1,FALSE);
              return;
              }
            else
              strcpy(token[1],subst_filename);
            }
    
          if (access(token[1],0) != UNIX_OK)
            ok_to_write = TRUE;
          else
            {
            c = query("File exists. Do you want to overwrite it (Y or N)? ");
            if (c == 'Y')
              ok_to_write = TRUE;
            else
              ok_to_write = FALSE;
            }
          if (ok_to_write)
            {
            strcpy(prev_filename,filename);
            strncpy(filename,token[1],STRINGMAX-1);
    
            save(SAVE_FILE_FLAG,OVERWRITE);
            if (  (!save_failed)
               && (!save_abandoned)
               )
              {
              strcpy(filename,unexp_filename);
              sprintf(errortext," %s saved ok.",filename);
              cmove(SCREENLINES-1,0);
              clreol();
              next_file();
              }
    
            else 
              {
              last_op_failed = TRUE;
              strcpy(filename,prev_filename);
              if (message_pending < 2)
                next_mess("File not saved.");
              }
            }
          else
            {
            last_op_failed = TRUE;
            next_mess("File not saved.");
            }
          }
        else
          {
          last_op_failed = TRUE;
          next_mess("Filename must be specified.");
          }
        }
      else
        {
        temp_cx = 0;

        if (!no_tilde)
        if (in_str(filename,"~",&temp_cx,FORWARDS))
          {
          subst_filename = repl_string(&new_len,filename,"~",home,&temp_cx);
          if (new_len >= STRINGMAX)
            {
            free(subst_filename);
            next_mess("Filename line too long.");
            restore_status(ALL_STATUS,SCREENLINES-1,FALSE);
            return;
            }
          else if (subst_filename == NULL)
            {
            next_mess("Not enough memory available for ~ substitution.");
            restore_status(ALL_STATUS,SCREENLINES-1,FALSE);
            return;
            }
          else
            {
            strcpy(unexp_filename,filename);
            strcpy(filename,subst_filename);
            }
          }

         save(SAVE_FILE_FLAG,OVERWRITE);
         if (  (! save_failed)
            && (! save_abandoned)
            )
           {
           strcpy(filename,unexp_filename);
           sprintf(errortext," %s saved ok.",filename);
           cmove(SCREENLINES-1,0);
           clreol();
           next_file();
           }
         else if (message_pending < 2)
           {
           last_op_failed = TRUE;
           next_mess("File not saved.");
           }
        }
      }
    else
      {
      cmove(SCREENLINES-1,0);
      clreol();
      next_file();
      }
    }

/* COMMAND: save , s , S : Save the file */
  else if (  (  (strcmp(uc_token[0],"SAVE") == STR_SAME)
             || (strcmp(uc_token[0],"S") == STR_SAME)
             )
          && (strcmp(uc_token[2],"") == STR_SAME)
          )
    {
    if (read_only_mode)
      {
      next_mess("Read-only mode: SAVE is disabled.");
      restore_status(ALL_STATUS,SCREENLINES-1,FALSE);
      return;
      }
    if (strcmp(token[1],"") != STR_SAME)
      {
      temp_cx = 0;
      strcpy(unexp_filename,token[1]);
      if (!no_tilde)
      if (!token_quoted[1])
      if (in_str(token[1],"~",&temp_cx,FORWARDS))
        {
        subst_filename = repl_string(&new_len,token[1],"~",home,&temp_cx);
        if (new_len >= STRINGMAX)
          {
          free(subst_filename);
          next_mess("Command line too long.");
          restore_status(ALL_STATUS,SCREENLINES-1,FALSE);
          return;
          }
        else if (subst_filename == NULL)
          {
          next_mess("Not enough memory available for ~ substitution.");
          restore_status(ALL_STATUS,SCREENLINES-1,FALSE);
          return;
          }
        else
          strcpy(token[1],subst_filename);
        }

      if ((fptr = fopen(token[1],"r")) == NULL)
        ok_to_write = TRUE;
      else
        {
        fclose(fptr);
        fptr = NULL;
        c = query("File exists. Do you want to overwrite it (Y or N)? ");
        if (c == 'Y')
          ok_to_write = TRUE;
        else
          ok_to_write = FALSE;
        }
      if (ok_to_write)
        {
        strcpy(prev_filename,filename);
        strncpy(filename,token[1],STRINGMAX-1);

        save(SAVE_FILE_FLAG,OVERWRITE);
        if (  (!save_failed)
           && (!save_abandoned)
           )
          {
          next_mess("File saved ok.");
          strcpy(filename,unexp_filename);
          sprintf(file_text,"File: %s",filename);
          }
 
        else
          {
          last_op_failed = TRUE;
          strcpy(filename,prev_filename);
          if (message_pending < 2)
            next_mess("File not saved.");
          }
        }
      else
        {
        last_op_failed = TRUE;
        next_mess("File not saved.");
        }
      }
    else
      {
      if (strcmp(filename,"") == STR_SAME)
        {
        last_op_failed = TRUE;
        next_mess("Filename must be specified.");
        }
      else
        {
        temp_cx = 0;
        if (!no_tilde)
        if (in_str(filename,"~",&temp_cx,FORWARDS))
          {
          subst_filename = repl_string(&new_len,filename,"~",home,&temp_cx);
          if (new_len >= STRINGMAX)
            {
            free(subst_filename);
            next_mess("Filename line too long.");
            restore_status(ALL_STATUS,SCREENLINES-1,FALSE);
            return;
            }
          else if (subst_filename == NULL)
            {
            next_mess("Not enough memory available for ~ substitution.");
            restore_status(ALL_STATUS,SCREENLINES-1,FALSE);
            return;
            }
          else
            {
            strcpy(unexp_filename,filename);
            strcpy(filename,subst_filename);
            }
          }

        save(SAVE_FILE_FLAG,OVERWRITE);
        if (  (!save_failed)
           && (!save_abandoned)
           )
           {
           strcpy(filename,unexp_filename);
           next_mess("File saved ok.");
           }
        else
          {
          last_op_failed = TRUE;
          if (message_pending < 2)
            next_mess("File not saved.");
          }
        }
      }
    }

/* COMMAND: write to a new file name */
  else if (  (  (strcmp(uc_token[0],"WRITE") == STR_SAME)
             || (strcmp(uc_token[0],"W") == STR_SAME)
             )
          && (  (strcmp(uc_token[2],"APPEND") == STR_SAME)
             || (strcmp(uc_token[2],"A") == STR_SAME)
             || (strcmp(uc_token[2],"") == STR_SAME)
             )
          && (strcmp(uc_token[3],"") == STR_SAME)
          )
    {
    if (strcmp(token[1],"") != STR_SAME)
      {
      if (read_only_mode)
        if (strcmp(filename,token[1]) == STR_SAME)
           {
           c = query("Read-only mode: do you really want to overwite the file. (Y or N)? ");
           if (c != 'Y')
             {
             next_mess("File not written.");
             restore_status(ALL_STATUS,SCREENLINES-1,FALSE);
             return;
             }
           }
      
      temp_cx = 0;
      strcpy(unexp_filename,token[1]);
      if (!no_tilde)
      if (!token_quoted[1])
      if (in_str(token[1],"~",&temp_cx,FORWARDS))
        {
        subst_filename = repl_string(&new_len,token[1],"~",home,&temp_cx);
        if (new_len >= STRINGMAX)
          {
          free(subst_filename);
          next_mess("Command line too long.");
          restore_status(ALL_STATUS,SCREENLINES-1,FALSE);
          return;
          }
        else if (subst_filename == NULL)
          {
          next_mess("Not enough memory available for ~ substitution.");
          restore_status(ALL_STATUS,SCREENLINES-1,FALSE);
          return;
          }
        else
          strcpy(token[1],subst_filename);
        }
      if (  (strcmp(uc_token[2],"APPEND") == STR_SAME)
         || (strcmp(uc_token[2],"A") == STR_SAME)
         )
        ok_to_write = TRUE;
      else
        if ((fptr = fopen(token[1],"r")) == NULL)
          ok_to_write = TRUE;
        else
          {
          fclose(fptr);
          fptr = NULL;
          c = query("File exists. Do you want to overwrite it (Y or N)? ");
          if (c == 'Y')
            ok_to_write = TRUE;
          else
            ok_to_write = FALSE;
          }
      if (ok_to_write)
        {
        strcpy(prev_filename,filename);
        strncpy(filename,token[1],STRINGMAX-1);

        if (  (strcmp(uc_token[2],"APPEND") == STR_SAME)
           || (strcmp(uc_token[2],"A") == STR_SAME)
           )
          open_mode=APPEND;
        else
          open_mode=OVERWRITE;

        if (block_marked)
          {
          save(SAVE_BLOCK_FLAG,open_mode);
          if (  (!save_failed)
             && (!save_abandoned)
             )
            {
            next_mess("Block saved ok.");
            strcpy(filename,prev_filename);
            }

          else
            {
            last_op_failed = TRUE;
            strcpy(filename,prev_filename);
            if (message_pending < 2)
              next_mess("Block not written.");
            }
          }
        else
          {
          save(SAVE_FILE_FLAG,open_mode);
          if (  (!save_failed)
             && (!save_abandoned)
             )
            {
            next_mess("File saved ok.");
            strcpy(filename,unexp_filename);
            sprintf(file_text,"File: %s",filename);
            }

          else
            {
            last_op_failed = TRUE;
            strcpy(filename,prev_filename);
            if (message_pending < 2)
              next_mess("File not written.");
            }
          }
        }
      else
        {
        last_op_failed = TRUE;
        next_mess("File not written.");
        }
      }
    else
      {
      last_op_failed = TRUE;
      next_mess("Filename must be specified.");
      }
    }

/* COMMAND: execute unix command */
  else if (strcmp(token[0],"!") == STR_SAME)
    {
    if (strcmp(token[1],"") != STR_SAME)
      {
      clrscr();
      unset_term();
      flush_scr_buffer();
      /* system("stty -raw"); */

      temp_error = system(token[1]);

      set_raw();

      printf("\n** Press any key to return to Medit **\n");

      c = decode_key();

      if (strlen(mess_text) == 0)
        next_mess(find_text);
      showscreen();
      restore_status(ALL_STATUS,SCREENLINES-1,FALSE);
      }
    }

/* COMMAND: paste from a file */
  else if (  (  (strcmp(uc_token[0],"FILE") == STR_SAME)
             || (strcmp(uc_token[0],"F")    == STR_SAME)
             )
          && (strcmp(uc_token[2],"") == STR_SAME)
          )
    {
    if (strcmp(token[1],"") != STR_SAME)
      {
      temp_cx = 0;
      if (!no_tilde)
      if (!token_quoted[1])
      if (in_str(token[1],"~",&temp_cx,FORWARDS))
        {
        subst_filename = repl_string(&new_len,token[1],"~",home,&temp_cx);
        if (new_len >= STRINGMAX)
          {
          free(subst_filename);
          next_mess("Command line too long.");
          restore_status(ALL_STATUS,SCREENLINES-1,FALSE);
          return;
          }
        else if (subst_filename == NULL)
          {
          next_mess("Not enough memory available for ~ substitution.");
          restore_status(ALL_STATUS,SCREENLINES-1,FALSE);
          return;
          }
        else
          {
          strcpy(unexp_filename,token[1]);
          strcpy(token[1],subst_filename);
          }
        }

      readfile(token[1],PASTE_FILE);
      lines_counted = FALSE;
      if (read_failed) last_op_failed = TRUE;
      }
    else
      next_mess("Filename must be specified.");
    }

/* COMMAND: open a file */
  else if (  (  (strcmp(uc_token[0],"OPEN") == STR_SAME)
             || (strcmp(uc_token[0],"O")    == STR_SAME)
             )
          && (strcmp(uc_token[2],"") == STR_SAME)
          )
    {
    if (strcmp(token[1],"") == STR_SAME)
      {
      last_op_failed = TRUE;
      next_mess("Filename must be specified.");
      }
    else
      {
      if (strcmp(filename,"") != STR_SAME)
        {
        if (file_needs_saving)
          {
          c = query("File not saved. Do you want to save it (Y or N or Cancel)? ");
          if (c == 'Y')
            ok_to_write = TRUE;
          else
            ok_to_write = FALSE;
          if (c == 'C')
            ok_to_quit = FALSE;
          else
            ok_to_quit = TRUE;
          }
        else
          {
          ok_to_write = FALSE;
          ok_to_quit = TRUE;
          }
        if (  (ok_to_write)
           && (ok_to_quit)
           )
          {
          temp_cx = 0;
          strcpy(unexp_filename,token[1]);
          if (!no_tilde)
          if (in_str(filename,"~",&temp_cx,FORWARDS))
            {
            subst_filename = repl_string(&new_len,filename,"~",home,&temp_cx);
            if (new_len >= STRINGMAX)
              {
              free(subst_filename);
              next_mess("Filename line too long.");
              restore_status(ALL_STATUS,SCREENLINES-1,FALSE);
              return;
              }
            else if (subst_filename == NULL)
              {
              next_mess("Not enough memory available for ~ substitution.");
              restore_status(ALL_STATUS,SCREENLINES-1,FALSE);
              return;
              }
            else
              strcpy(filename,subst_filename);
            }
     
          save(SAVE_FILE_FLAG,OVERWRITE);
          strcpy(filename,unexp_filename);
          if (  (save_failed)
             || (save_abandoned)
             )
            {
            last_op_failed = TRUE;
            if (message_pending < 2)
              {
              next_mess("File not saved.");
              return;
              }
            }
          }
  
        else if (  (!ok_to_write)
                && (ok_to_quit)
                )
          {
          ; /* do nothing */
          }
        else
          {
          last_op_failed = TRUE;
          next_mess("Open cancelled.");
          return;
          }
        }
      else
        {
        if (file_needs_saving)
          {
          c = query("File not saved. Do you want to save it (Y or N)? ");
          if (c == 'N')
            ok_to_quit = TRUE;
          else
            ok_to_quit = FALSE;
          }
        else
          ok_to_quit = TRUE;
        if (!ok_to_quit)
          {
          last_op_failed = TRUE;
          next_mess("Open cancelled.");
          return;
          }
        }
  
      empty_memory();
  
      /* now we can load the new file  - phew! */
      strcpy(unexp_filename,token[1]);
      if (strcmp(token[1],"") != STR_SAME)
        {
        temp_cx = 0;
        if (!no_tilde)
        if (!token_quoted[1])
        if (in_str(token[1],"~",&temp_cx,FORWARDS))
          {
          subst_filename = repl_string(&new_len,token[1],"~",home,&temp_cx);
          if (new_len >= STRINGMAX)
            {
            free(subst_filename);
            next_mess("Command line too long.");
            restore_status(ALL_STATUS,SCREENLINES-1,FALSE);
            return;
            }
          else if (subst_filename == NULL)
            {
            next_mess("Not enough memory available for ~ substitution.");
            restore_status(ALL_STATUS,SCREENLINES-1,FALSE);
            return;
            }
          else
            {
            strcpy(token[1],subst_filename);
            }
          }
  
        readfile(token[1],LOAD_FILE);
        lines_counted = FALSE;
        if (!read_failed)
          {
          strcpy(filename,unexp_filename);
          strcpy(file_text,"File: ");
          strncat(file_text,filename,FILENAMEMAX-1);
          }
        else
          {
          showscreen();
          restore_status(ALL_STATUS,SCREENLINES-1,FORCE);
          last_op_failed = TRUE;
          }
        }
      else
        {
        last_op_failed = TRUE;
        next_mess("Filename must be specified.");
        }
      }
    }
  
/* COMMAND: mark block */
  else if (  (  (strcmp(uc_token[0],"BLOCK") == STR_SAME)
             || (strcmp(uc_token[0],"B") == STR_SAME)
             )
          && (strcmp(uc_token[1],"") == STR_SAME)
          )
    {
    markblock();
    }

/* COMMAND: paste block */
  else if (  (  (strcmp(uc_token[0],"PASTE") == STR_SAME)
             || (strcmp(uc_token[0],"P")    == STR_SAME)
             )
          && (strcmp(uc_token[1],"") == STR_SAME)
          )
    {
    pasteblock(NOT_FROM_MOVEBLOCK);
    lines_counted = FALSE;
    }

/* COMMAND: move block */
  else if (  (  (strcmp(uc_token[0],"MOVE") == STR_SAME)
             || (strcmp(uc_token[0],"M")    == STR_SAME)
             )
          && (strcmp(uc_token[1],"") == STR_SAME)
          )
    {
    moveblock();
    lines_counted = FALSE;
    }

/* COMMAND: delete block */
  else if (  (  (strcmp(uc_token[0],"DELETE") == STR_SAME)
             || (strcmp(uc_token[0],"D") == STR_SAME)
             )
          && (strcmp(uc_token[1],"") == STR_SAME)
          )
    {
    deleteblock(NOT_FROM_MOVEBLOCK);
    lines_counted = FALSE;
    }

/* COMMAND: a number , eg 999 : goto that line */
  else if (  (sscanf(token[0],"%d",&intarg) == 1)
          && (strcmp(uc_token[1],"") == STR_SAME)
          )
    {
    if (intarg != 0)
      gotoline(intarg);
    }


/* COMMAND: help , H , h : show help screen */
  else if (  (  (strcmp(uc_token[0],"HELP") == STR_SAME)
             || (strcmp(uc_token[0],"H") == STR_SAME)
             )
          && (strcmp(uc_token[1],"") == STR_SAME)
          )
    {
    help();
    }


/* COMMAND: replace 'string' command */
  else if
          (  (  (token_quoted[1])
             && (  (strcmp(uc_token[0],"RW")      == STR_SAME)
                || (strcmp(uc_token[0],"REPLACE") == STR_SAME)
                || (strcmp(uc_token[0],"R")       == STR_SAME)
                || (strcmp(uc_token[0],"RC")      == STR_SAME)
                || (strcmp(uc_token[0],"RCW")     == STR_SAME)
                || (strcmp(uc_token[0],"RWC")     == STR_SAME)
                )
             )
          || (  (token_quoted[2])
             && (  (strcmp(uc_token[0],"REPLACE") == STR_SAME)
                || (strcmp(uc_token[0],"R")       == STR_SAME)
                )
             && (  (strcmp(uc_token[1],"WORD")    == STR_SAME)
                || (strcmp(uc_token[1],"W")       == STR_SAME)
                )
             )
          || (  (token_quoted[2])
             && (  (strcmp(uc_token[0],"REPLACE") == STR_SAME)
                || (strcmp(uc_token[0],"R")       == STR_SAME)
                )
             && (  (strcmp(uc_token[1],"CASE")    == STR_SAME)
                || (strcmp(uc_token[1],"C")       == STR_SAME)
                )
             )
          || (  (token_quoted[3])
             && (  (strcmp(uc_token[0],"REPLACE") == STR_SAME)
                || (strcmp(uc_token[0],"R")       == STR_SAME)
                )
             && (   (  (  (strcmp(uc_token[1],"CASE") == STR_SAME)
                      || (strcmp(uc_token[1],"C")    == STR_SAME)
                      )
                   && (  (strcmp(uc_token[2],"WORD") == STR_SAME)
                      || (strcmp(uc_token[2],"W")    == STR_SAME)
                      )
                   )
                || (  (  (strcmp(uc_token[2],"CASE") == STR_SAME)
                      || (strcmp(uc_token[2],"C")    == STR_SAME)
                      )
                   && (  (strcmp(uc_token[1],"WORD") == STR_SAME)
                      || (strcmp(uc_token[1],"W")    == STR_SAME)
                      )
                   )
                )
             )
          )
    {


    if (  (strcmp(uc_token[0],"RW")             == STR_SAME)
       || (strcmp(uc_token[0],"RCW")            == STR_SAME)
       || (strcmp(uc_token[0],"RWC")            == STR_SAME)
       || (  (!token_quoted[1])
          && (  (strcmp(uc_token[1],"WORD")     == STR_SAME)
             || (strcmp(uc_token[1],"W")        == STR_SAME)
             )
          )
       || (  (!token_quoted[2])
          && (  (strcmp(uc_token[2],"WORD")     == STR_SAME)
             || (strcmp(uc_token[2],"W")        == STR_SAME)
             )
          )
       )
      word_search = TRUE;
    else
      word_search = FALSE;

    if (  (strcmp(uc_token[0],"RC")             == STR_SAME)
       || (strcmp(uc_token[0],"RCW")            == STR_SAME)
       || (strcmp(uc_token[0],"RWC")            == STR_SAME)
       || (  (!token_quoted[1])
          && (  (strcmp(uc_token[1],"CASE")     == STR_SAME)
             || (strcmp(uc_token[1],"C")        == STR_SAME)
             )
          )
       || (  (!token_quoted[2])
          && (  (strcmp(uc_token[2],"CASE")     == STR_SAME)
             || (strcmp(uc_token[2],"C")        == STR_SAME)
             )
          )
       )
      case_sens = TRUE;
    else
      case_sens = FALSE;

    if (  (  (strcmp(uc_token[0],"REPLACE")  == STR_SAME)
          || (strcmp(uc_token[0],"R")        == STR_SAME)
          )
       && (!token_quoted[1])
       && (  (strcmp(uc_token[1],"WORD")     == STR_SAME)
          || (strcmp(uc_token[1],"W")        == STR_SAME)
          || (strcmp(uc_token[1],"CASE")     == STR_SAME)
          || (strcmp(uc_token[1],"C")        == STR_SAME)
          )
       )
       {
       strcpy(uc_token[1],uc_token[2]);
       strcpy(uc_token[2],uc_token[3]);
       strcpy(uc_token[3],uc_token[4]);
       strcpy(uc_token[4],uc_token[5]);
       strcpy(uc_token[5],uc_token[6]);
       strcpy(uc_token[6],uc_token[7]);
       strcpy(uc_token[7],uc_token[8]);
       strcpy(uc_token[8],"");
       strcpy(token[1],token[2]);
       strcpy(token[2],token[3]);
       strcpy(token[3],token[4]);
       strcpy(token[4],token[5]);
       strcpy(token[5],token[6]);
       strcpy(token[6],token[7]);
       strcpy(token[7],token[8]);
       strcpy(token[8],"");
       token_quoted[1]=token_quoted[2];
       token_quoted[2]=token_quoted[3];
       token_quoted[3]=token_quoted[4];
       token_quoted[4]=token_quoted[5];
       token_quoted[5]=token_quoted[6];
       token_quoted[6]=token_quoted[7];
       token_quoted[7]=token_quoted[8];
       token_quoted[8]=FALSE;
       }


    if (  (  (strcmp(uc_token[0],"REPLACE")  == STR_SAME)
          || (strcmp(uc_token[0],"R")        == STR_SAME)
          )
       && (!token_quoted[1])
       && (  (strcmp(uc_token[1],"WORD")     == STR_SAME)
          || (strcmp(uc_token[1],"W")        == STR_SAME)
          || (strcmp(uc_token[1],"CASE")     == STR_SAME)
          || (strcmp(uc_token[1],"C")        == STR_SAME)
          )
       )
       {
       strcpy(uc_token[1],uc_token[2]);
       strcpy(uc_token[2],uc_token[3]);
       strcpy(uc_token[3],uc_token[4]);
       strcpy(uc_token[4],uc_token[5]);
       strcpy(uc_token[5],uc_token[6]);
       strcpy(uc_token[6],uc_token[7]);
       strcpy(uc_token[7],uc_token[8]);
       strcpy(uc_token[8],"");
       strcpy(token[1],token[2]);
       strcpy(token[2],token[3]);
       strcpy(token[3],token[4]);
       strcpy(token[4],token[5]);
       strcpy(token[5],token[6]);
       strcpy(token[6],token[7]);
       strcpy(token[7],token[8]);
       strcpy(token[8],"");
       token_quoted[1]=token_quoted[2];
       token_quoted[2]=token_quoted[3];
       token_quoted[3]=token_quoted[4];
       token_quoted[4]=token_quoted[5];
       token_quoted[5]=token_quoted[6];
       token_quoted[6]=token_quoted[7];
       token_quoted[7]=token_quoted[8];
       token_quoted[8]=FALSE;
       }


    if (  (strcmp(uc_token[3],"ALL") == STR_SAME)
       || (strcmp(uc_token[3],"A") == STR_SAME)
       || (strcmp(uc_token[3],"QUERY") == STR_SAME)
       || (strcmp(uc_token[3],"Q") == STR_SAME)
       )
      {
      strncpy(findstr,token[1],FINDSTR_MAX);

      strcpy(find_text,"");

      if ((case_sens) && (word_search))
        strcat(find_text,"CW");
      else if (case_sens)
        strcat(find_text,"C");
      else if (word_search)
        strcat(find_text,"W");

      strcat(find_text,QUOTE_STR);
      strncat(find_text,findstr,status_mess_len-2);
      strcat(find_text,QUOTE_STR);

      replace(findstr,token[2],uc_token[3]);
      lines_counted = FALSE;
      }
    else
      {
      last_op_failed = TRUE;
      next_mess("Replace option not recognised.");
      }
    }

/* COMMAND: replace 'regular expression' command */
  else if (  (  (strcmp(uc_token[0],"REPEXP") == STR_SAME)
             || (strcmp(uc_token[0],"RX") == STR_SAME)
             )
          && (  (  (strcmp(uc_token[4],"") == STR_SAME)
                && (  (strcmp(uc_token[3],"QUERY") == STR_SAME)
                   || (strcmp(uc_token[3],"Q")     == STR_SAME)
                   || (strcmp(uc_token[3],"A")     == STR_SAME)
                   || (strcmp(uc_token[3],"ALL")   == STR_SAME)
                   )
                )
             || (  (strcmp(uc_token[5],"") == STR_SAME)
                && (  (strcmp(uc_token[3],"QUERY") == STR_SAME)
                   || (strcmp(uc_token[3],"Q")     == STR_SAME)
                   || (strcmp(uc_token[3],"A")     == STR_SAME)
                   || (strcmp(uc_token[3],"ALL")   == STR_SAME)
                   )
                && (  (strcmp(uc_token[4],"CASE") == STR_SAME)
                   || (strcmp(uc_token[4],"C")    == STR_SAME)
                   )
                )
             )
          )
    {
    if (strcmp(token[1],"") == STR_SAME)
      {
      last_op_failed = TRUE;
      next_mess("Expression to replace must not be empty.");
      }
    else if (!token_quoted[1])
      {
      last_op_failed = TRUE;
      next_mess("Expression to replace must be in quotes.");
      }
    else if (!token_quoted[2])
      {
      last_op_failed = TRUE;
      next_mess("Replacement string must be in quotes.");
      }
    else
      {
      if (  (strcmp(uc_token[3],"ALL") == STR_SAME)
         || (strcmp(uc_token[3],"A") == STR_SAME)
         || (strcmp(uc_token[3],"QUERY") == STR_SAME)
         || (strcmp(uc_token[3],"Q") == STR_SAME)
         )
        {
        if (  (strcmp(uc_token[4],"CASE") == STR_SAME)
           || (strcmp(uc_token[4],"C")    == STR_SAME)
           )
          case_sens = 0;
        else
          case_sens = PCRE_CASELESS;

        if (expr_ptr != NULL) free(expr_ptr);
        if ((expr_ptr = pcre_compile(token[1],PCRE_DOLLAR_ENDONLY | PCRE_DOTALL | case_sens,&errptr,&erroffset,NULL)) != NULL)
          {
          strncpy(findstr,token[1],FINDSTR_MAX);
          strcpy(find_text,"Expr");
          strcat(find_text,QUOTE_STR);
          strncat(find_text,findstr,status_mess_len-7);
          strcat(find_text,QUOTE_STR);
          findstr_is_re = TRUE;
          replace_expr(token[2],uc_token[3]);
          lines_counted = FALSE;
          }
        else
          {
          last_op_failed = TRUE;
          sprintf(temp_str,"Regular expression: %s",errptr);
          next_mess(temp_str);
          }
        }
      else
        {
        last_op_failed = TRUE;
        if (strcmp(token[3],"") == STR_SAME)
          next_mess("Replace expression option must be 'Query' or 'All'.");
        else
          next_mess("Replace expression option not recognised.");
        }
      }
    }


/* COMMAND: find 'regular expression' command */
  else if (  (  (strcmp(uc_token[0],"EXPR") == STR_SAME)
             || (strcmp(uc_token[0],"X") == STR_SAME)
             )
          && (  (strcmp(uc_token[2],"") == STR_SAME)
             || (  (strcmp(uc_token[3],"") == STR_SAME)
                && (  (strcmp(uc_token[2],"CASE") == STR_SAME)
                   || (strcmp(uc_token[2],"C")    == STR_SAME)
                   )
                )
             )
          )
    {
    if (strcmp(token[1],"") == STR_SAME)
      {
      last_op_failed = TRUE;
      next_mess("Regular expression must not be empty.");
      }
    else if (!token_quoted[1])
      {
      last_op_failed = TRUE;
      next_mess("Regular expression must be in quotes.");
      }
    else
      {
      if (  (strcmp(uc_token[2],"CASE") == STR_SAME)
         || (strcmp(uc_token[2],"C")    == STR_SAME)
         )
        case_sens = 0;
      else
        case_sens = PCRE_CASELESS;

      if (expr_ptr != NULL) free(expr_ptr);
      if ((expr_ptr = pcre_compile(token[1],PCRE_DOLLAR_ENDONLY | PCRE_DOTALL | case_sens,&errptr,&erroffset,NULL)) != NULL)
        {
        strncpy(findstr,token[1],FINDSTR_MAX);
        strcpy(find_text,"Expr");
        strcat(find_text,QUOTE_STR);
        strncat(find_text,findstr,status_mess_len-7);
        strcat(find_text,QUOTE_STR);
        findstr_is_re = TRUE;

        find_dir = FORWARDS;

        if (expr(expr_ptr,find_dir,case_sens))
          {
          if (find_dir == FORWARDS)
            {
            cur_sx = calc_sx_str(line_table_cur->text,cx);
  
            if (  (cur_sx > (vx + SCREENCOLS - 2 - (int)strlen(findstr)))
               || (cur_sx < vx)
               || (  (cur_sx < (SCREENCOLS - 2 - (int)strlen(findstr)))
                  && (vx > 0)
                  )
               )
              {
              vx = cur_sx - SCREENCOLS + 2 + (int)strlen(findstr);
              if (vx < 0) vx = 0;
              use_new_cy = FALSE;
              }
  
            showscreency(SCREENLINES/4);
            }
          else
            {
            cur_sx = calc_sx_str(line_table_cur->text,cx);
  
            if (  (cur_sx > (vx + SCREENCOLS - 2 - (int)strlen(findstr)))
               || (cur_sx < vx)
               || (  (cur_sx < (SCREENCOLS - 2 - (int)strlen(findstr)))
                  && (vx > 0)
                  )
               )
              {
              vx = cur_sx - SCREENCOLS + 2 + (int)strlen(findstr);
              if (vx < 0) vx = 0;
              use_new_cy = FALSE;
              }
  
            showscreency(SCREENLINES/4*3);
            }
          lines_counted = FALSE;
          next_mess(find_text);
          }
        else
          {
          last_op_failed = TRUE;
          if (  macexec
             && macro_block_range
             )
            {
            macro_range_error = TRUE;
            next_mess("Macro reached end of block.");
            }
          else
            next_mess("Regular expression not found.");
          }
        }
      else
        {
        last_op_failed = TRUE;
        sprintf(temp_str,"RE: %s",errptr);
        next_mess(temp_str);
        }
      }
    }

/* COMMAND: 'string' , "string" : find next line containing string */

/* the word option can not be a prefix to the string because
   of conflict with the Write command.
*/

  else if (  (  (token_quoted[1])
             && (strcmp(token[0],"")                 == STR_SAME)
             && (  (strcmp(uc_token[2],"")           == STR_SAME)
                || (  (strcmp(uc_token[2],"CW")      == STR_SAME)
                   && (strcmp(token[3],"")           == STR_SAME)
                   )
                || (  (strcmp(uc_token[2],"WC")      == STR_SAME)
                   && (strcmp(token[3],"")           == STR_SAME)
                   )
                || (  (  (strcmp(uc_token[2],"CASE") == STR_SAME)
                      || (strcmp(uc_token[2],"C")    == STR_SAME)
                      )
                   && (  (strcmp(token[3],"")        == STR_SAME)
                      || (strcmp(uc_token[3],"WORD") == STR_SAME)
                      || (strcmp(uc_token[3],"W")    == STR_SAME)
                      )
                   )
                || (  (  (strcmp(uc_token[2],"WORD") == STR_SAME)
                      || (strcmp(uc_token[2],"W")    == STR_SAME)
                      )
                   && (  (strcmp(token[3],"")        == STR_SAME)
                      || (strcmp(uc_token[3],"CASE") == STR_SAME)
                      || (strcmp(uc_token[3],"C")    == STR_SAME)
                      )
                   )
                )
             && (strcmp(uc_token[4],"") == STR_SAME)
             )
          )
    {
    find_dir = FORWARDS;

    if (  (strcmp(uc_token[2],"CASE") == STR_SAME)
       || (strcmp(uc_token[2],"C")    == STR_SAME)
       || (strcmp(uc_token[2],"CW")   == STR_SAME)
       || (strcmp(uc_token[2],"WC")   == STR_SAME)
       || (strcmp(uc_token[3],"CASE") == STR_SAME)
       || (strcmp(uc_token[3],"C")    == STR_SAME)
       || (strcmp(uc_token[3],"CW")   == STR_SAME)
       || (strcmp(uc_token[3],"WC")   == STR_SAME)
       )
      case_sens = TRUE;
    else
      case_sens = FALSE;

    if (  (strcmp(uc_token[2],"WORD") == STR_SAME)
       || (strcmp(uc_token[2],"W")    == STR_SAME)
       || (strcmp(uc_token[2],"CW")   == STR_SAME)
       || (strcmp(uc_token[2],"WC")   == STR_SAME)
       || (strcmp(uc_token[3],"WORD") == STR_SAME)
       || (strcmp(uc_token[3],"W")    == STR_SAME)
       || (strcmp(uc_token[3],"CW")   == STR_SAME)
       || (strcmp(uc_token[3],"WC")   == STR_SAME)
       )
      word_search = TRUE;
    else
      word_search = FALSE;

    strncpy(findstr,token[1],FINDSTR_MAX);
    if ((case_sens) && (word_search))
      {
      strcpy(find_text,"CW");
      strcat(find_text,QUOTE_STR);
      strncat(find_text,findstr,status_mess_len-4);
      }
    else if (case_sens)
      {
      strcpy(find_text,"C");
      strcat(find_text,QUOTE_STR);
      strncat(find_text,findstr,status_mess_len-3);
      }
    else if (word_search)
      {
      strcpy(find_text,"W");
      strcat(find_text,QUOTE_STR);
      strncat(find_text,findstr,status_mess_len-3);
      }
    else
      {
      strcpy(find_text,QUOTE_STR);
      strncat(find_text,findstr,status_mess_len-2);
      }
    strcat(find_text,QUOTE_STR);
    findstr_is_re = FALSE;

    if (find(findstr,find_dir,case_sens))
      {
      if (find_dir == FORWARDS)
        {
        cur_sx = calc_sx_str(line_table_cur->text,cx);

        if (  (cur_sx > (vx + SCREENCOLS - 2 - (int)strlen(findstr)))
         || (cur_sx < vx)
         || (  (cur_sx < (SCREENCOLS - 2 - (int)strlen(findstr)))
            && (vx > 0)
            )
         )
        {
        vx = cur_sx - SCREENCOLS + 2 + (int)strlen(findstr);
        if (vx < 0) vx = 0;
        use_new_cy = FALSE;
        }

        showscreency(SCREENLINES/4);
        }
      else
        {
        cur_sx = calc_sx_str(line_table_cur->text,cx);

        if (  (cur_sx > (vx + SCREENCOLS - 2 - (int)strlen(findstr)))
         || (cur_sx < vx)
         || (  (cur_sx < (SCREENCOLS - 2 - (int)strlen(findstr)))
            && (vx > 0)
            )
         )
        {
        vx = cur_sx - SCREENCOLS + 2 + (int)strlen(findstr);
        if (vx < 0) vx = 0;
        use_new_cy = FALSE;
        }

        showscreency(SCREENLINES/4*3);
        }
      lines_counted = FALSE;
      next_mess(find_text);
      }
    else
      {
      last_op_failed = TRUE;
      if (  macexec
         && macro_block_range
         )
        {
        macro_range_error = TRUE;
        next_mess("Macro reached end of block.");
        }
      else
        next_mess("String not found.");
      }
    }
  else if (  (strcmp(token[1],"") == STR_SAME)
          && (token_quoted[1])
          )
         next_mess("String to find must not be empty.");


/* COMMAND: copy block */
  else if (  (  (strcmp(uc_token[0],"COPY") == STR_SAME)
             || (strcmp(uc_token[0],"C")    == STR_SAME)
             )
          && (strcmp(uc_token[1],"") == STR_SAME)
          )
    {
    dup_block();
    lines_counted = FALSE;
    }

  else
    {
    if (strcmp(command_str,"") == STR_SAME)
      next_mess("No command entered.");
    else
      /* unrecognised command */
      {
      last_op_failed = TRUE;
      next_mess("Command not recognised.");
      }
    }

restore_status(ALL_STATUS,SCREENLINES-1,FALSE);
}

/*************************/
void save_file()
{
int temp_cx;
char * subst_filename;
int new_len;
char unexp_filename[STRINGMAX];

strcpy(unexp_filename,filename);

if (read_only_mode)
	{
	next_mess("Read-only mode: SAVE is disabled.");
	restore_status(ALL_STATUS,SCREENLINES-1,FALSE);
	return;
	}

/*
if (strcmp(token[1],"") != STR_SAME)
	{
	temp_cx = 0;
	strcpy(unexp_filename,token[1]);
	if (!no_tilde)
	if (!token_quoted[1])
	if (in_str(token[1],"~",&temp_cx,FORWARDS))
		{
		subst_filename = repl_string(&new_len,token[1],"~",home,&temp_cx);
		if (new_len >= STRINGMAX)
			{
			free(subst_filename);
			next_mess("Command line too long.");
			restore_status(ALL_STATUS,SCREENLINES-1,FALSE);
			return;
			}
		else if (subst_filename == NULL)
			{
			next_mess("Not enough memory available for ~ substitution.");
			restore_status(ALL_STATUS,SCREENLINES-1,FALSE);
			return;
			}
		else
			strcpy(token[1],subst_filename);
		}

	if ((fptr = fopen(token[1],"r")) == NULL)
		ok_to_write = TRUE;
	else
		{
		fclose(fptr);
		fptr = NULL;
		c = query("File exists. Do you want to overwrite it (Y or N)? ");
		if (c == 'Y')
			ok_to_write = TRUE;
		else
			ok_to_write = FALSE;
		}

	if (ok_to_write)
		{
		strcpy(prev_filename,filename);
		strncpy(filename,token[1],STRINGMAX-1);
		save(SAVE_FILE_FLAG,OVERWRITE);
		if	(  (!save_failed)
				&& (!save_abandoned)
				)
			{
			next_mess("File saved ok.");
			strcpy(filename,unexp_filename);
			sprintf(file_text,"File: %s",filename);
			}
		else
			{
			last_op_failed = TRUE;
			strcpy(filename,prev_filename);
			if (message_pending < 2)
			next_mess("File not saved.");
			}
		}
	else
		{
		last_op_failed = TRUE;
		next_mess("File not saved.");
		}
	}
else
	{
	if (strcmp(filename,"") == STR_SAME)
		{
		etc
		}
	}
*/

	if (strcmp(filename,"") == STR_SAME)
		{
		last_op_failed = TRUE;
		next_mess("Filename must be specified.");
		}
	else
		{
		temp_cx = 0;
		if (!no_tilde)
		if (in_str(filename,"~",&temp_cx,FORWARDS))
			{
			subst_filename = repl_string(&new_len,filename,"~",home,&temp_cx);
			if (new_len >= STRINGMAX)
				{
				free(subst_filename);
				next_mess("Filename is too long.");
				restore_status(ALL_STATUS,SCREENLINES-1,FALSE);
				return;
				}
			else if (subst_filename == NULL)
				{
				next_mess("Not enough memory available for ~ substitution.");
				restore_status(ALL_STATUS,SCREENLINES-1,FALSE);
				return;
				}
			else
				{
				strcpy(unexp_filename,filename);
				strcpy(filename,subst_filename);
				}
			}
		save(SAVE_FILE_FLAG,OVERWRITE);
		if	(  (!save_failed)
			&& (!save_abandoned)
			)
			{
			strcpy(filename,unexp_filename);
			next_mess("File saved ok.");
			}
		else
			{
			last_op_failed = TRUE;
			if (message_pending < 2)
			next_mess("File not saved.");
			}
		}

}

/*************************/
void save(int save_block, int open_mode)
{
struct line_rec *line_table_ptr;
struct line_rec *line_table_next;
char temp_str[FILENAMEMAX];
char mv_error[ERRORTEXT_MAX];
int read_only = FALSE;
int bak_read_only = FALSE;
int ok_to_write = FALSE;
int rename_failed = FALSE;
int fflag;
int rename_error = 0;
char reply;
char * p;
FILE * ofptr = NULL;
struct stat fstat_buffer;
mode_t mode;

save_abandoned = FALSE;
save_failed = FALSE;
message_pending = 0;

if (access(filename,0) != UNIX_OK)
  /* if filename does not exist */
  {
  fptr = fopen(filename,"w");

  if (  (fptr == NULL)
     || (ferror(fptr))
     )
    {
    sprintf(errortext,"%s on file '%s'",strerror(errno),filename);
    next_mess(errortext);
    save_failed = TRUE;
    goto exit;
    }
 
  if (save_block)
    line_table_ptr = line_table_block_start;
  else
    line_table_ptr = line_table_start;
  while (  (line_table_ptr != NULL)
        && (! save_failed)
        )
    {
    fflag = fputs(line_table_ptr->text,fptr);
    if (  (fflag == EOF)
       || (ferror(fptr))
       )
      {
      sprintf(errortext,"%s on file '%s'",strerror(errno),filename);
      next_mess(errortext);
      save_failed = TRUE;
      goto exit;
      }
    if (!file_empty)
      {
      fflag = fputc('\n',fptr);
      if (  (fflag == EOF)
         || (ferror(fptr))
         )
        {
        sprintf(errortext,"%s on file '%s'",strerror(errno),filename);
        next_mess(errortext);
        save_failed = TRUE;
        goto exit;
        }
      }
    if (  (save_block)
       && (line_table_ptr == line_table_block_end)
       )
      line_table_ptr = NULL;
    else
      {
      line_table_next = line_table_ptr->next_line;
      line_table_ptr = line_table_next;
      }
    }
  fclose(fptr);
  fptr = NULL;
  }
else /* filename exists */
  {
#ifndef MSDOS

  if (stat(filename,&fstat_buffer) == -1)
    {
    sprintf(errortext,"Cannot stat file '%s'",filename);
    goto exit;
    }
  mode = fstat_buffer.st_mode;

  if (open_mode == APPEND)
    {
    fptr = fopen(filename,"a");

    if (  (fptr == NULL)
       || (ferror(fptr))
       )
      {
      sprintf(errortext,"%s on file '%s'",strerror(errno),filename);
      next_mess(errortext);
      save_failed = TRUE;
      goto exit;
      }
    }
  else
    {
    fptr = tmpfile();

    if (  (fptr == NULL)
       || (ferror(fptr))
       )
      {
      sprintf(errortext,"%s on temporary file",strerror(errno));
      next_mess(errortext);
      save_failed = TRUE;
      goto exit;
      }
    }

  if (save_block)
    line_table_ptr = line_table_block_start;
  else
    line_table_ptr = line_table_start;

  while (  (line_table_ptr != NULL)
        && (! save_failed)
        )
    {
    fflag = fputs(line_table_ptr->text,fptr);
    if (  (fflag == EOF)
       || (ferror(fptr))
       )
      {
      sprintf(errortext,"%s on temporary file",strerror(errno));
      next_mess(errortext);
      save_failed = TRUE;
      goto exit;
      }
    if (!file_empty)
      {
      fflag = fputc('\n',fptr);
      if (  (fflag == EOF)
         || (ferror(fptr))
         )
        {
        sprintf(errortext,"%s on temporary file",strerror(errno));
        next_mess(errortext);
        save_failed = TRUE;
        goto exit;
        }
      }
    if (  (save_block)
       && (line_table_ptr == line_table_block_end)
       )
      line_table_ptr = NULL;
    else
      {
      line_table_next = line_table_ptr->next_line;
      line_table_ptr = line_table_next;
      }
    }

  rewind(fptr);

  if (open_mode == OVERWRITE)
    {
    if (stat(filename,&fstat_buffer) == -1)
      {
      sprintf(errortext,"Cannot stat file '%s'",filename);
      goto exit;
      }
    mode = fstat_buffer.st_mode;

    ofptr = fopen(filename,"w");

    if (  (ofptr == NULL)
       || (ferror(ofptr))
       )
      {
      sprintf(mv_error,"%s on file '%s'",strerror(errno),filename);

      if (  (strstr(mv_error,"Permission") == NULL)
         && (strstr(mv_error,"Access Denied") == NULL)
         )
        {
        next_mess(mv_error);
        save_failed = TRUE;
        goto exit;
        }
      if (ofptr != NULL) fclose(ofptr);
      rename_failed = TRUE;
      }
    else
      {
      if ((rename_error = rename_file(fptr,ofptr)) != UNIX_OK)
        {
        rename_failed = TRUE;
        if (mess_text[0] == '\0')
          sprintf(mv_error,"%s while writing file",strerror(rename_error));
        else
          strcpy(mv_error,mess_text);
        }
      }

    if (rename_failed)
      {
      if (  (strstr(mv_error,"Permission") == NULL)
         && (strstr(mv_error,"Access Denied") == NULL)
         )
        {
        next_mess(mv_error);
        save_failed = TRUE;
        goto exit;
        }
      else
        {
        reply = query("File is read-only. Do you want to overwrite it(Y or N)? ");
        if (reply == 'Y')
          {
          if (stat(filename,&fstat_buffer) == -1)
            {
            cmove(SCREENLINES-1,9);
            clreol();
            sprintf(errortext,"File '%s' has been deleted",filename);
            next_mess(errortext);
            save_abandoned = TRUE;
            goto exit;
            }
          mode = fstat_buffer.st_mode;
          if (chmod(filename,(mode | S_IWUSR)) != 0)
            {
            cmove(SCREENLINES-1,9);
            clreol();
            sprintf(errortext,"Cannot get write permission on file '%s'",filename);
            next_mess(errortext);
            save_abandoned = TRUE;
            goto exit;
            }

          read_only = TRUE;

          ofptr = fopen(filename,"w");

          if (  (ofptr == NULL)
             || (ferror(ofptr))
             )
             {
             cmove(SCREENLINES-1,9);
             clreol();
             sprintf(errortext,"%s on file '%s'",strerror(errno),filename);
             next_mess(errortext);
             save_abandoned = TRUE;
             goto exit;
             }

          if (rename_file(fptr,ofptr) != UNIX_OK)
            {
            sprintf(mv_error,"%s on file '%s'",strerror(errno),filename);
            next_mess(mv_error);
            save_abandoned = TRUE;
            save_failed = TRUE;
            goto exit;
            }
          }
        else
          save_abandoned = TRUE;
        }
      }
    if (! rename_failed)
      {
      if (chmod(filename,mode) != 0)
        {
        sprintf(errortext,"Cannot chmod file '%s'",filename);
        goto exit;
        }
      }
    }
  }

#else

  strcpy(backup,filename);
  strcat(backup,".BAK");

  if (rename(filename,backup))
    {
    reply = query("Cannot create backup. Continue(Y or N)? ");
    if (reply == 'N')
      {
      cmove(SCREENLINES-1,9);
      clreol();
      sprintf(errortext,"Cannot create backup of %s",filename);
      next_mess(errortext);
      save_abandoned = TRUE;
      goto exit;
      }
    if (unlink(filename))
      {
      sprintf(mv_error,"%s",strerror(errno));

      if (  (strstr(mv_error,"Permission") == NULL)
         && (strstr(mv_error,"Access Denied") == NULL)
         )
        {
        next_mess(mv_error);
        save_failed = TRUE;
        goto exit;
        }
      else
        {
        reply = query("File is read-only. Do you want to overwrite it(Y or N)? ");
        if (reply == 'Y')
          {
          if (stat(filename,&fstat_buffer) == -1)
            {
              cmove(SCREENLINES-1,9);
              clreol();
              sprintf(errortext,"File '%s' has been deleted",filename);
              next_mess(errortext);
              save_abandoned = TRUE;
              goto exit;
            }
          mode = fstat_buffer.st_mode;
          if (chmod(filename,(mode | S_IWUSR)) != 0)
            {
            cmove(SCREENLINES-1,9);
            clreol();
            sprintf(errortext,"Cannot get write permission on file '%s'",filename);
            next_mess(errortext);
            save_abandoned = TRUE;
            goto exit;
            }
          read_only = TRUE;
          }
        }
      }
    }

  fptr = fopen(filename,"w");
  if (  (fptr == NULL)
     || (ferror(fptr))
     )
    {
    sprintf(errortext,"%s on file '%s'",strerror(errno),filename);
    next_mess(errortext);
    save_failed = TRUE;
    goto exit;
    }

  if (save_block)
    line_table_ptr = line_table_block_start;
  else
    line_table_ptr = line_table_start;

  while (  (line_table_ptr != NULL)
        && (! save_failed)
        )
    {
    fflag = fputs(line_table_ptr->text,fptr);
    if (  (fflag == EOF)
       || (ferror(fptr))
       )
      {
      sprintf(errortext,"%s on file '%s'",strerror(errno),temp_str);
      next_mess(errortext);
      save_failed = TRUE;
      goto exit;
      }
    if (!file_empty)
      {
      fflag = fputc('\n',fptr);
      if (  (fflag == EOF)
         || (ferror(fptr))
         )
        {
        sprintf(errortext,"%s on file '%s'",strerror(errno),temp_str);
        next_mess(errortext);
        save_failed = TRUE;
        goto exit;
        }
      }
    if (  (save_block)
       && (line_table_ptr == line_table_block_end)
       )
      line_table_ptr = NULL;
    else
      {
      line_table_next = line_table_ptr->next_line;
      line_table_ptr = line_table_next;
      }
    }
  fclose(fptr);
  fptr = NULL;

  }

#endif


if (  (!save_failed)
   && (!save_abandoned)
   )
  {
  if (save_block)
    {
    showblock(NO_HILITE);
    highlight_block(FALSE);
    block_marked = FALSE;
    line_table_block_start = line_table_block_end = NULL;
    }
  else
    {
    file_needs_saving = FALSE;
    if (read_only)
      /* unset the user write permissions bit */
      /* for a discussion of this see the readfile() subroutine */
      if (chmod(filename,(mode & (~S_IWUSR))) != 0)
        {
        sprintf(errortext,"Could not reset read-only permission on file '%s'",filename);
        next_mess(errortext);
        }
     }
  }

exit:

  if (fptr != NULL) fclose(fptr);
  fptr = NULL;

  if (ofptr != NULL) fclose(ofptr);
  ofptr = NULL;

}


/*************************/
int control_char(char * str)
{
char command_str[STRINGMAX];
char first_token[STRINGMAX];
char * command_ptr;
int intarg = 0;
int count = 0;

next_char_raw = TRUE;

do
  {
  command_ptr = (char *) &command_str;

  cmove(SCREENLINES-1,0);
  enter_bold();
  clreol();
  s_waddstr("Insert control character: ",NO_VX_CHECK,0,0,SCREENCOLS-2,FALSE);
  normal();

  cmove(SCREENLINES-1,26);
  clreol();

  strcpy(command_str,"");
  get_string(command_str,STRINGMAX,NO_FUNKEYS,SCREENLINES-1,26,NO_SAVE,CTRL_ALLOWED,NO_TAB_ENDS_INPUT,"");

  upper_case(command_str);

  /* start parsing the command line by skipping leading spaces */
  while (*command_ptr == ' ') command_ptr++;

  if (*command_ptr == '\0')
    {
    last_op_failed = TRUE;
    next_mess("No control characters entered.");
    }
  else if (  (strcmp(command_str,"HELP") == STR_SAME)
          || (strcmp(command_str,"H") == STR_SAME)
          )
    {
    ctrl_char_help();
    }
  else while (  (*command_ptr != '\0')
             && (*command_ptr != NEW_LINE)
             )
    {
    if (  (*command_ptr < ' ')
       && (*command_ptr != '\0')
       && (*command_ptr != NEW_LINE)
       )
     /* then its actual control codes */
      {
      /* insert_char(*command_ptr); */
      *str = *command_ptr;
      str++;
      count++;
      command_ptr++;
      }
    else if (  (*command_ptr > ' ')
            && (*command_ptr != '\0')
            && (*command_ptr != NEW_LINE)
            )
      /* then its text representing ascii codes */
      {
      command_ptr = parse(first_token,command_ptr," ",NOT_QUOTED,STRINGMAX-1);
      if (strcmp(first_token,"") != STR_SAME)
        {
        if (sscanf(first_token,"%d",&intarg) == 1)
          {
          if (  (intarg > 0)
             && (intarg <= 255)
             && (intarg != NEW_LINE)
             )
            {
            if (intarg != '\0')
              {
              /* insert_char(intarg); */
              *str = intarg;
              str++;
              count++;
              }
            else
              {
              last_op_failed = TRUE;
              next_mess("Invalid character code.");
              restore_status(ALL_STATUS,SCREENLINES-1,FALSE);
              next_char_raw = FALSE;
              return 0;
              }
            }
          }
        else
          {
          last_op_failed = TRUE;
          next_mess("Invalid character code.");
          restore_status(ALL_STATUS,SCREENLINES-1,FALSE);
          next_char_raw = FALSE;
          return 0;
          }
        }
      else
        if ((int)strlen(command_ptr) != 0)
          {
          last_op_failed = TRUE;
          next_mess("Invalid character code.");
          restore_status(ALL_STATUS,SCREENLINES-1,FALSE);
          next_char_raw = FALSE;
          return 0;
          }
      }
    while (*command_ptr == ' ') command_ptr++;
    }
  } while (  (strcmp(command_str,"HELP") == STR_SAME)
          || (strcmp(command_str,"H") == STR_SAME)
          );
next_char_raw = FALSE;
return count;
}

/*************************/
char * parse(char * target, char * source, char * delimiter, int quoted, int target_max)
{
char * target_start = target;
int target_count = 0;


/*
The range of allowed "quote" characters can not be increased
because of the possibility of them conflicting with the
characters allowed in path/filenames
*/

if (!quoted)
    while (  (*source == ' ')
          || (*source == '\t')
          )
      source++;

if (!quoted)
  {
  while (  (*source > ' ')
        && (*source < CHAR_DEL)
        && (*source != '"')
        && (*source != '\'')
        && (*source != '`')
        && (*source != '\0')
        && (target_count < (target_max-1))
        )
    {
    *target = *source;
    source++;
    target++;
    target_count += 1;
    }
  }
else
  {
  while (  (*source != *delimiter)
        && (*source != '\0')
        && (target_count < (target_max-1))
        )
    {
    *target = *source;
    source++;
    target++;
    }
  }

if (!quoted)
  while (  (*source == ' ')
        || (*source == '\t')
        )
    source++;

*target = '\0';

return source;
}

/**************************/
void shift_left_str(char * string, int position,int max_len)
/* shift chars (may be a subset) in a string to the left */
{
int count;
char * dest;
char * origin;

if (  (position <= max_len)
   && (position > 0)
   )
  {
  count = 0;
  origin = string;
  while (count < position)
    {
    origin++;
    count += 1;
    }

  dest = origin;
  dest--;

  while (*dest != '\0')
    {
    *dest = *origin;
    dest++;
    origin++;
    count += 1;
    }
  }
}

/**************************/
void shift_right_str(char * string,int position,int max_len)
/* shift chars (may be a subset) in a string to the right */
{
int count,total;
char * dest;
char * origin;

/* find the position of the substring to shifted right */
count = 0;
origin = string;

while (  (count < position)
      && (count < max_len)
      )
  {
  if (*origin == '\0')
    {
    *origin = ' ';
    origin++;
    *origin = '\0';
    }
  else
    origin++;
  count += 1;
  }
total = count;

/* now count the number of chars in the substring that have to be shifted */
count = 0;
dest = origin;
while (*dest != '\0')
  {
  dest++;
  count += 1;
  }
total = total + count;

/* if the end of the substring ( = null) is less than the max length of the
   allocated space, then the null is to be shifted right with the substring,
   and the destination of the substring is one after the null.

   if, hwoever the '\0' terminater is at the max length of the allocated space,
   then the null must be left where it is intact, and the destination of the
   substring is the one BEFORE the null.
*/

if (total == max_len)
  {
  dest--;
  count -= 1;
  }
else
  {
  dest++;
  count += 1;
  }

/* on a move right in situ, the chars have to be moved at the right end first,
   working BACKWARDS/leftwards towards the start of the substring.
*/
origin = dest;
origin--;

while (count > 0)
  {
  *dest = *origin;
  *origin = ' ';
  dest--;
  origin--;
  count -= 1;
  }

}

/**************************/
void ins_char_str(char string[], int position, char c, int max_len)
/* insert char into string */
{
shift_right_str(string,position,max_len);
string[position] = c;
}

/**************************/
void winattr(int window)
{
if (window == winptr)
  {
  normal();
  if (win_reverse == A_REVERSE)
    enter_inv();

  if (win_bold == A_BOLD)
    enter_bold();

  if (win_underline == A_UNDERLINE)
    enter_under();

  if (win_blink == A_BLINK)
    enter_blink();
  }

if (window == statusptr)
  {
  normal();
  if (status_reverse == A_REVERSE)
    enter_inv();

  if (status_bold == A_BOLD)
    enter_bold();

  if (status_underline == A_UNDERLINE)
    enter_under();

  if (status_blink == A_BLINK)
    enter_blink();
  }

if (window == helpptr)
  {
  normal();
  if (help_reverse == A_REVERSE)
    enter_inv();

  if (help_bold == A_BOLD)
    enter_bold();

  if (help_underline == A_UNDERLINE)
    enter_under();

  if (help_blink == A_BLINK)
    enter_blink();
  }
}

/**************************/
void calc_status_ch(
              int c,
              int no_vx_check,
              int cx,
              int vx,
              int left_sx,
              int right_sx,
              int high_ctrl)
{
int i;
int n = 0;

  if (  (  (c >= ' ')
        && (c <= '\176')
        )
     )
    sx++;
  else
    if (c == TAB)
      {
      i = 1;
      while (  (tabstop[i] <= sx)
            && (i < TABSTOP_MAX)
            && (tabstop[i] < 32000)
            )
        i = i + 1;
      if (  (i < TABSTOP_MAX)
         && (tabstop[i] < 32000)
         )
        while (  (sx < tabstop[i])
              && (sx <= right_sx)
              )
          sx++;
      }
    else
      sx++;
}

/**************************/
int calc_status_sx(char * string,
                     int no_vx_check,
                     int vx,
                     int cx,
                     int left_sx,
                     int right_sx,
                     int high_ctrl)
{
int i = 0;

sx = left_sx;

ovr_mode();

while (  (*string != '\0')
      && (i < vx)
      )
  {
  string++;
  i++;
  }

while (  (*string != '\0')
      /* && (sx < right_sx) */
      && (i < cx)
      )
  {
  calc_status_ch((unsigned char)*string,no_vx_check,i,vx,left_sx,right_sx,high_ctrl);
  string++;
  i++;
  }

return sx;
}

/**************************
int calc_status_sx(char * string,int vx,int cx,int left_sx)
{
int i = vx;
sx = left_sx;
while (  (*string != '\0')
      && (i < cx)
      )
  {
  calc_sx_ch((unsigned char)*string);
  string++;
  i++;
  }
return sx;
}
*/

/**************************/
void calc_sx_ch(int c)
{
int i;

  if (  (  (c >= ' ')
        && (c <= '\176')
        )
     )
    sx = sx + 1;
  else
    if (c == TAB)
      {
      i = 1;
      while (  (tabstop[i] <= sx)
            && (i < TABSTOP_MAX)
            && (tabstop[i] < 32000)
            )
        i = i + 1;
      if (  (i < TABSTOP_MAX)
         && (tabstop[i] < 32000)
         )
        while (sx < tabstop[i])
          sx = sx + 1;
      }
    else
      sx = sx + 1;
}

/**************************/
int calc_sx_str(char * string,int cx)
{
int c = 0;
sx = 0;
while (  (*string != '\0')
      && (c < cx)
      )
  {
  calc_sx_ch((unsigned char)*string);
  string++;
  c += 1;
  }
return sx;
}

/**************************/
void n_waddch(int winptr,int c,int no_vx_check,int init_cx,int cx,int high_ctrl)
{
int i;
int n = 0;

  if (  (  (c >= ' ')
        && (c <= '\176')
        )
     )
    {
    if (  (no_vx_check)
       || (  (sx >= vx)
          && (cx >= init_cx)
          )
       )
      x_buffch(c);
    sx = sx + 1;
    }
  else
    if (c == TAB)
      {
      if (highlight_tabs)
        {
        enter_inv();
        enter_bold();
        enter_under();
        if (high_ctrl) enter_blink();
        }
      i = 1;
      while (  (tabstop[i] <= sx)
            && (i < TABSTOP_MAX)
            && (tabstop[i] < 32000)
            )
        i = i + 1;
      if (  (i < TABSTOP_MAX)
         && (tabstop[i] < 32000)
         )
        while (  (sx < tabstop[i])
              && (sx < (vx + SCREENCOLS - 1)) /* test */
              )
          {
          if (  (no_vx_check)
             || (  (sx >= vx)
                && (cx >= init_cx)
                )
             )
            x_buffch(' ');
          sx = sx + 1;
          }
      if (highlight_tabs)
          winattr(winptr);
      }
    else
      {
      enter_inv();
      enter_bold();
      enter_under();
      if (high_ctrl) enter_blink();
      if (c > '\176')
        {
        if (  (no_vx_check)
           || (  (sx >= vx)
              && (cx >= init_cx)
              )
           )
          x_buffch('?');
        sx = sx + 1;
        }
      else
        {
        if (c == '\0')
          {
          if (  (no_vx_check)
             || (  (sx >= vx)
                && (cx >= init_cx)
                )
             )
            x_buffch(' ');
          sx = sx + 1;
          }
        else
          {
          if (  (no_vx_check)
             || (  (sx >= vx)
                && (cx >= init_cx)
                )
             )
            x_buffch(c+'A'-1);
          sx = sx + 1;
          }
        }
      winattr(winptr);
      }
}

/**************************/
void n_waddstr(char * string,int no_vx_check,int init_cx)
{
int i=0;

sx = 0;

ovr_mode();

while (  (*string != '\0')
      && (sx < (vx + SCREENCOLS - 1))
      )
  {
  n_waddch(winptr,(unsigned char)*string,no_vx_check,init_cx,i,FALSE);
  string++;
  i++;
  }
}

/**************************/
void ni_waddstr(char * string,int no_vx_check,int init_cx,int count,int high_ctrl)
{
int cx=0;

sx = 0;

ovr_mode();


while (  (*string != '\0')
      && (sx < (vx + SCREENCOLS - 1))
      && (count > (cx - init_cx))
      )
  {
  n_waddch(winptr,(unsigned char)*string,no_vx_check,init_cx,cx,high_ctrl);
  string++;
  cx++;
  }
}

/**************************/
void x_waddch(int winptr,int c,int no_vx_check,int high_ctrl)
{
int i;

  if (  (  (c >= ' ')
        && (c <= '\176')
        )
     )
    {
    if (  (no_vx_check)
       || (sx >= vx)
       )
      x_buffch(c);
    sx = sx + 1;
    }
  else
    if (c == TAB)
      {
      if (highlight_tabs)
        {
        enter_inv();
        enter_bold();
        enter_under();
        if (high_ctrl) enter_blink();
        }
      i = 1;
      while (  (tabstop[i] <= sx)
            && (i < TABSTOP_MAX)
            && (tabstop[i] < 32000)
            )
        i = i + 1;
      if (  (i < TABSTOP_MAX)
         && (tabstop[i] < 32000)
         )
        while (  (sx < tabstop[i])
              && (sx < (vx + SCREENCOLS - 1))
              )
          {
          if (  (no_vx_check)
             || (sx >= vx)
             )
            x_buffch(' ');
          sx = sx + 1;
          }
      if (highlight_tabs)
          winattr(winptr);
      }
    else
      {
      enter_inv();
      enter_bold();
      enter_under();
      if (high_ctrl) enter_blink();
      if (c > '\176')
        {
        if (  (no_vx_check)
           || (sx >= vx)
           )
          x_buffch('?');
        sx = sx + 1;
        }
      else
        {
        if (c == '\0')
          {
          if (  (no_vx_check)
             || (sx >= vx)
             )
            x_buffch(' ');
          sx = sx + 1;
          }
        else
          {
          if (  (no_vx_check)
             || (sx >= vx)
             )
            x_buffch(c+'A'-1);
          sx = sx + 1;
          }
        }
      winattr(winptr);
      }
}

/**************************/
void x_waddstr(char * string,int no_vx_check,int init_sx,int high_ctrl)
{
sx = init_sx;

ovr_mode();

while (  (*string != '\0')
      && (sx < (vx + SCREENCOLS - 1))
      )
  {
  x_waddch(winptr,(unsigned char)*string,no_vx_check,high_ctrl);
  string++;
  }
}

/**************************/
void s_waddch(int c,
              int no_vx_check,
              int cx,
              int vx,
              int left_sx,
              int right_sx,
              int high_ctrl)
{
int i;
int n = 0;

  if (  (  (c >= ' ')
        && (c <= '\176')
        )
     )
    {
    if (  (  (no_vx_check)
          || (cx >= vx)
          )
       && (sx <= right_sx)
       )
      x_buffch(c);
    sx++;
    }
  else
    if (c == TAB)
      {
      if (highlight_tabs)
        {
        enter_inv();
        enter_bold();
        enter_under();
        if (high_ctrl) enter_blink();
        }
      i = 1;
      while (  (tabstop[i] <= sx)
            && (i < TABSTOP_MAX)
            && (tabstop[i] < 32000)
            )
        i = i + 1;
      if (  (i < TABSTOP_MAX)
         && (tabstop[i] < 32000)
         )
        while (  (sx < tabstop[i])
              && (sx <= right_sx)
              )
          {
          if (  (  (no_vx_check)
                || (cx >= vx)
                )
             && (sx <= right_sx)
             )
            x_buffch(' ');
          sx++;
          }
      if (highlight_tabs)
          winattr(statusptr);
      }
    else
      {
      enter_inv();
      enter_bold();
      enter_under();
      if (high_ctrl) enter_blink();
      if (c > '\176')
        {
        if (  (  (no_vx_check)
              || (cx >= vx)
              )
           && (sx <= right_sx)
           )
          x_buffch('?');
        sx++;
        }
      else
        {
        if (c == '\0')
          {
          if (  (  (no_vx_check)
                || (cx >= vx)
                )
             && (sx <= right_sx)
             )
            x_buffch('0');
          sx++;
          }
        else
          {
          if (  (  (no_vx_check)
                || (cx >= vx)
                )
             && (sx <= right_sx)
             )
            x_buffch(c+'A'-1);
          sx++;
          }
        }
      winattr(statusptr);
      }
}

/**************************/
void s_waddstr(char * string,
               int no_vx_check,
               int vx,
               int left_sx,
               int right_sx,
               int high_ctrl)
{
int cx = 0;

sx = left_sx;

ovr_mode();

while (  (*string != '\0')
      && (cx < vx)
      )
  {
  string++;
  cx++;
  }

while (  (*string != '\0')
      && (sx < right_sx)
      )
  {
  s_waddch((unsigned char)*string,no_vx_check,cx,vx,left_sx,right_sx,high_ctrl);
  string++;
  cx++;
  }
}

/**************************************/
char * str_str(char *string,char *pattern)
{
int len;
len = strlen(pattern);

while (  (strncmp(string,pattern,len) != STR_SAME)
      && (*string != '\0')
      )
  string++;

if (*string == '\0')
  return NULL;
else
  return string;
}

/**************************************/
void zap_spaces(char *source)
{
char *dest;

dest = source;
while (*dest != '\0')
  {
  if (  (*source != ' ')
     && (*source != '\t')
     )
    {
    *dest = *source;
    source++;
    dest++;
    }
  else
    source++;
  }
}


/**************************************/
void new_line()
{
if (cx == 0)
  {
  file_needs_saving = TRUE;
  if (cy < (SCREENLINES-2))
    {
    insert_line();
    ins_line();
    restore_status(ALL_STATUS,SCREENLINES-1,FALSE);
    cy = cy + 1;
    recalc_screen_cy(cy);
    cmove(cy,0);
    }
  else
    {
    insert_line();
    if (line_table_top->next_line != NULL)
      line_table_top = line_table_top->next_line;
    recalc_screen_cur();
    cmove(0,0);
    deline();
    cmove(SCREENLINES-3,0);
    ins_line();
    cx = 0;
    cur_sx = calc_sx_str(line_table_cur->text,cx);
    recalc_screen_cur();
    restore_status(ALL_STATUS,SCREENLINES-1,FALSE);
    }
  }
else
  {
  if (cx > ((int)(strlen(line_table_cur->text) - 1)))
    {
    if (line_table_cur != line_table_end)
      {
      if (cy < (SCREENLINES-2))
        {
        down_no_upd();
        insert_line();
        up_no_upd();
        cy += 1;
        recalc_screen_cy(cy);
        cx = 0;
        cur_sx = calc_sx_str(line_table_cur->text,cx);
        cmove(cy,0);
        ins_line();
        restore_status(ALL_STATUS,SCREENLINES-1,FALSE);
        file_needs_saving = TRUE;
        }
      else
/* its the last line on the screen */
        {
        down_no_upd();
        insert_line();
        if (line_table_cur->prev_line != NULL)
          line_table_cur = line_table_cur->prev_line;
        recalc_screen_cy(cy);
        cmove(0,0);
        deline();
        cmove(SCREENLINES-2,0);
        ins_line();
        cx = 0;
        cur_sx = calc_sx_str(line_table_cur->text,cx);
        cmove(cy,cur_sx-vx);
        }
      }
    else
/* its the last line in the file */
      {
      file_needs_saving = TRUE;
      if (cy < (SCREENLINES-2))
        {
        insert_line_end();
        cy += 1;
        recalc_screen_cy(cy);
        cx = 0;
        cur_sx = calc_sx_str(line_table_cur->text,cx);
        cmove(cy,0);
        ins_line();
        restore_status(ALL_STATUS,SCREENLINES-1,FALSE);
        }
      else
/* its the last line in the file & screen */
        {
        insert_line_end();
        down_no_upd();
        cmove(0,0);
        deline();
        cmove(SCREENLINES-2,0);
        ins_line();
        cx = 0;
        if (line_table_top->next_line != NULL)
          line_table_top = line_table_top->next_line;
        recalc_screen_cy(cy);
        cur_sx = calc_sx_str(line_table_cur->text,cx);
        cmove(cy,cur_sx-vx);
        }
      }
    }
  else
/* its a split line */
    {
    if (cy < (SCREENLINES-2))
      {
      split_line();
      clreol();
      cy = cy + 1;
      recalc_screen_cur();
      cx = 0;
      cur_sx = calc_sx_str(line_table_cur->text,cx);
      cmove(cy,0);
      ins_line();
      showline_mv(line_table_cur,line_table_cur->text,cy,0,HILITE);
      cmove(cy,cur_sx-vx);
      restore_status(ALL_STATUS,SCREENLINES-1,FALSE);
      }
    else
/* its the last line on the screen */
      {
      split_line();
      clreol();
      if (line_table_top->next_line != NULL)
        line_table_top = line_table_top->next_line;
      recalc_screen_cur();
      cmove(0,0);
      deline();
      cmove(SCREENLINES-2,0);
      showline_mv(line_table_cur,line_table_cur->text,cy,0,HILITE);
      cx = 0;
      cur_sx = calc_sx_str(line_table_cur->text,cx);
      cmove(cy,cur_sx-vx);
      restore_status(ALL_STATUS,SCREENLINES-1,FALSE);
      }
    file_needs_saving = TRUE;
    }
  }
cur_sx = calc_sx_str(line_table_cur->text,cx);

if (cur_sx < vx)
  {
  vx = cur_sx - (SCREENCOLS/3);
  if (vx < 0) vx = 0;
  showscreen();
  }

new_count = (cur_line_no + 1);
}

/**************************************/
void delete_char()
/* text only - not command line */
{
  if (cx > (int) strlen(line_buffer))
    cx = (int) strlen(line_buffer);

 if (cx < ((int)strlen(line_buffer)))
   /* then cursor is before end of line */
   {
   shift_left_str(line_buffer,cx+1,LINE_BUFFER_MAX);
   cur_sx = calc_sx_str(line_buffer,cx);
   showline_right(line_table_cur,line_buffer,cy,cx,HILITE);
   cmove(cy,cur_sx-vx);
   file_needs_saving = TRUE;
   line_needs_updating = TRUE;
   }
 else
   if (line_table_cur->next_line != NULL)
     {
     if (line_needs_updating)
       updateline(LEAVE_TRAILING_SPACES);
     cx = strlen(line_table_cur->text);
     line_table_cur = join_ptr(line_table_cur->next_line);
     showline_mv(line_table_cur,line_table_cur->text,cy,cx,HILITE);
     cur_sx = calc_sx_str(line_table_cur->text,cx);
     if (cy < (SCREENLINES-2))
       {
       cmove(cy+1,0);
       deline();
       if (line_table_bot->next_line != NULL)
         {
         line_table_bot = line_table_bot->next_line;
         show_bot_line();
         restore_status(ALL_STATUS,SCREENLINES-1,FALSE);
         }
       else
         {
         cmove(SCREENLINES-2,0);
         ins_line();
         }
       }
     recalc_screen_cur();
     cmove(cy,cur_sx-vx);
     file_needs_saving = TRUE;
     load_buffer();
     }

 if (  (line_table_cur->prev_line == NULL)
    && (line_table_cur->next_line == NULL)
    && ((int)strlen(line_buffer) == 0)
    && (! file_empty)
    )
   {
   file_empty = TRUE;
   restore_status(ALL_STATUS,SCREENLINES-1,FALSE);
   lines_counted = FALSE;
   }
}

/**************************************/
void backspace()
/* text only - not command line */
{
struct line_rec *line_table_temp;

 if (cx > (int) strlen(line_buffer))
   cx = (int) strlen(line_buffer);

 if (cx > 0)
     /* then cursor is after beginning of line */
     {
     shift_left_str(line_buffer,cx,LINE_BUFFER_MAX);
     cx = cx - 1;
     cur_sx = calc_sx_str(line_buffer,cx);
     if (cur_sx < vx)
       {
       vx = cur_sx - (SCREENCOLS/3);
       if (vx < 0) vx = 0;
       updateline(LEAVE_TRAILING_SPACES);
       showscreen();
       }
     else
       {
       cmove(cy,cur_sx-vx);
       showline_right(line_table_cur,line_buffer,cy,cx,HILITE);
       cmove(cy,cur_sx-vx);
       line_needs_updating = TRUE;
       }
     file_needs_saving = TRUE;
     }
 else
     /* then cursor is at beginning of line - so join current & prev lines */
     {
     if (line_needs_updating)
       updateline(LEAVE_TRAILING_SPACES);

     line_table_temp = line_table_cur->prev_line;
     if (line_table_temp != NULL)
       {
       cx = strlen(line_table_temp->text);

       line_table_cur = join_ptr(line_table_cur);

       if (cy == 0)
         {
         if (line_table_top->prev_line != NULL)
           {
           line_table_top = line_table_top->prev_line;
           line_table_cur = line_table_top;
           cmove(cy,0);
           clreol();
           cur_sx = calc_sx_str(line_table_cur->text,cx);
           showline_mv(line_table_cur,line_table_cur->text,cy,cx,HILITE);
           recalc_screen_cur();
           cmove(cy,cur_sx-vx);
           }
         }
       else
         {
         cmove(SCREENLINES-1,0);
         clreol();
         cmove(cy,0);
         deline();
         cy = cy - 1;
         cur_sx = calc_sx_str(line_table_cur->text,cx);
         showline_mv(line_table_cur,line_table_cur->text,cy,cx,HILITE);
         recalc_screen_cy(cy);
         show_bot_line();
         restore_status(ALL_STATUS,SCREENLINES-1,FALSE);
         }

       if (cur_sx > (vx + SCREENCOLS - 1))
         {
         vx = cur_sx - SCREENCOLS + (SCREENCOLS/3);
         showscreen();
         }

       new_count = (cur_line_no - 1);
       file_needs_saving = TRUE;
       lines_counted = FALSE;
       load_buffer();
       }
     }

 if (  (line_table_cur->prev_line == NULL)
    && (line_table_cur->next_line == NULL)
    && ((int)strlen(line_buffer) == 0)
    && (! file_empty)
    )
   {
   file_empty = TRUE;
   restore_status(ALL_STATUS,SCREENLINES-1,FALSE);
   lines_counted = FALSE;
   }
}

/**********************/
/*
These defines used in the following routines only:
w_toggle_case()
move_to_word()
back_to_word()
*/

#define SPACE_CHAR (1)
#define SYMBOL_CHAR (-1)
#define ALPHA_CHAR (0)
#define ANY_CHAR (2)

/**********************/
int w_toggle_case()
{

struct line_rec *line_table_ptr;
struct line_rec *line_table_next;
char temp_line[LINEMAXLEN];
int temp_cx;
int found = FALSE;
int finished = FALSE;
int beg_of_line = FALSE;
char * temp_cx_ptr;
int i,current;

new_cy = cy;

line_table_ptr = line_table_cur;

temp_cx = ((int) strlen(line_table_ptr->text) - 1);
if (cx <= temp_cx)
  temp_cx = cx;

/* determine whether we are looking at an alphabetic char */
/*
if (  (toupper(line_table_ptr->text[temp_cx]) >= 'A')
   && (toupper(line_table_ptr->text[temp_cx]) <= 'Z')
   )
*/
if (  (line_table_ptr->text[temp_cx] >= 'A')
   && (line_table_ptr->text[temp_cx] <= 'Z')
   )
  {
  current = ALPHA_CHAR;
  }
else /* determine if we are looking at a white space char */
if (  (line_table_ptr->text[temp_cx] == ' ')
   || (line_table_ptr->text[temp_cx] == CHAR_TAB)
   )
  {
  current = SPACE_CHAR;
  }
else /* we are looking at a symbol char */
  {
  current = SYMBOL_CHAR;
  }

temp_cx = ((int) strlen(line_table_ptr->text) - 1);
if (cx <= temp_cx)
  temp_cx = cx;

temp_cx++;

if (line_table_ptr->text[temp_cx] == '\0')
  {
  line_table_ptr = line_table_ptr->next_line;
  temp_cx = 0;
  new_cy += 1;
  current = SPACE_CHAR;
  }

if (line_table_ptr == NULL)
  {
  last_op_failed = TRUE;
  return FALSE;
  }
else
  {
  strcpy(temp_line,line_table_ptr->text);
  upper_case(temp_line);

  while (  (temp_line[temp_cx] != '\0')
        && (!finished)
        )
    {
    if (current == SPACE_CHAR)
        {
        while (  (  (temp_line[temp_cx] == ' ')
                 || (temp_line[temp_cx] == CHAR_TAB)
                 )
              && (temp_line[temp_cx] != '\0')
              )
            temp_cx++;
        finished = (found = (temp_line[temp_cx] != '\0'));
        }

    if (current == SYMBOL_CHAR)
        {
        while (  (  (temp_line[temp_cx] < 'A')
                 || (temp_line[temp_cx] > 'Z')
                 )
              && (temp_line[temp_cx] != ' ')
              && (temp_line[temp_cx] != CHAR_TAB)
              && (temp_line[temp_cx] != '\0')
              )
            {
            temp_cx++;
            }

        while (  (  (temp_line[temp_cx] == ' ')
                 || (temp_line[temp_cx] == CHAR_TAB)
                 )
              && (temp_line[temp_cx] != '\0')
              )
            temp_cx++;

        finished = (found = (temp_line[temp_cx] != '\0'));
        }

    if (current == ALPHA_CHAR)
        {
        while (  (temp_line[temp_cx] >= 'A')
              && (temp_line[temp_cx] <= 'Z')
              && (temp_line[temp_cx] != '\0')
              )
            {
            temp_cx++;
            }

        while (  (  (temp_line[temp_cx] == ' ')
                 || (temp_line[temp_cx] == CHAR_TAB)
                 )
              && (temp_line[temp_cx] != '\0')
              )
            temp_cx++;

        finished = (found = (temp_line[temp_cx] != '\0'));
        }
    }

  while (!finished)
    {
    line_table_ptr = line_table_ptr->next_line;
    temp_cx = 0;
    new_cy += 1;

    if (line_table_ptr != NULL)
      {
      strcpy(temp_line,line_table_ptr->text);

      while (  (  (temp_line[temp_cx] == ' ')
               || (temp_line[temp_cx] == CHAR_TAB)
               )
            && (temp_line[temp_cx] != '\0')
            )
          temp_cx++;

      finished = (found = (temp_line[temp_cx] != '\0'));
      }
    else
      finished = TRUE;
    }

  if (!found)
    {
    use_new_cy = FALSE;
    last_op_failed = TRUE;
    return FALSE;
    }
  else
    {
    line_table_cur = line_table_ptr;
    cx = temp_cx;
    use_new_cy = TRUE;
    return TRUE;
    }
  }
}


/**********************/
int move_to_word()
{

struct line_rec *line_table_ptr;
struct line_rec *line_table_next;
char temp_line[LINEMAXLEN];
int temp_cx;
int found = FALSE;
int finished = FALSE;
int beg_of_line = FALSE;
char * temp_cx_ptr;
int i,current;

new_cy = cy;

line_table_ptr = line_table_cur;

temp_cx = ((int) strlen(line_table_ptr->text) - 1);
if (cx <= temp_cx)
  temp_cx = cx;

/* determine whether we are looking at an alphabetic char */
if (  (  (toupper(line_table_ptr->text[temp_cx]) >= 'A')
      && (toupper(line_table_ptr->text[temp_cx]) <= 'Z')
      )
   || (  (line_table_ptr->text[temp_cx] >= '0')
      && (line_table_ptr->text[temp_cx] <= '9')
      )
   )
  {
  current = ALPHA_CHAR;
  }
else /* determine if we are looking at a white space char */
if (  (line_table_ptr->text[temp_cx] == ' ')
   || (line_table_ptr->text[temp_cx] == CHAR_TAB)
   )
  {
  current = SPACE_CHAR;
  }
else /* we are looking at a symbol char */
  {
  current = SYMBOL_CHAR;
  }

temp_cx = ((int) strlen(line_table_ptr->text) - 1);
if (cx <= temp_cx)
  temp_cx = cx;

temp_cx++;

if (line_table_ptr->text[temp_cx] == '\0')
  {
  line_table_ptr = line_table_ptr->next_line;
  temp_cx = 0;
  new_cy += 1;
  current = SPACE_CHAR;
  }

if (line_table_ptr == NULL)
  {
  last_op_failed = TRUE;
  return FALSE;
  }
else
  {
  strcpy(temp_line,line_table_ptr->text);
  upper_case(temp_line);

  while (  (temp_line[temp_cx] != '\0')
        && (!finished)
        )
    {
    if (  (current == SPACE_CHAR)
       || (current == SYMBOL_CHAR)
       )
        {
        while (  (  (temp_line[temp_cx] < 'A')
                 || (temp_line[temp_cx] > 'Z')
                 )
              && (  (temp_line[temp_cx] < '0')
                 || (temp_line[temp_cx] > '9')
                 )
              && (temp_line[temp_cx] != '\0')
              )
            {
            temp_cx++;
            }
        finished = (found = (temp_line[temp_cx] != '\0'));
        }

    if (current == ALPHA_CHAR)
        {
        while (  (  (  (temp_line[temp_cx] >= 'A')
                    && (temp_line[temp_cx] <= 'Z')
                    )
                 || (  (temp_line[temp_cx] >= '0')
                    && (temp_line[temp_cx] <= '9')
                    )
                 )
              && (temp_line[temp_cx] != '\0')
              )
            {
            temp_cx++;
            }

        while (  (  (temp_line[temp_cx] < 'A')
                 || (temp_line[temp_cx] > 'Z')
                 )
              && (  (temp_line[temp_cx] < '0')
                 || (temp_line[temp_cx] > '9')
                 )
              && (temp_line[temp_cx] != '\0')
              )
            {
            temp_cx++;
            }

        finished = (found = (temp_line[temp_cx] != '\0'));
        }
    }

  while (!finished)
    {
    line_table_ptr = line_table_ptr->next_line;
    temp_cx = 0;
    new_cy += 1;

    if (line_table_ptr != NULL)
      {
      strcpy(temp_line,line_table_ptr->text);
      upper_case(temp_line);

      while (  (  (temp_line[temp_cx] < 'A')
               || (temp_line[temp_cx] > 'Z')
               )
            && (  (temp_line[temp_cx] < '0')
               || (temp_line[temp_cx] > '9')
               )
            && (temp_line[temp_cx] != '\0')
            )
        {
        temp_cx++;
        }

      finished = (found = (temp_line[temp_cx] != '\0'));
      }
    else
      finished = TRUE;
    }

  if (!found)
    {
    use_new_cy = FALSE;
    last_op_failed = TRUE;
    return FALSE;
    }
  else
    {
    line_table_cur = line_table_ptr;
    cx = temp_cx;
    use_new_cy = TRUE;
    return TRUE;
    }
  }
}



/**********************/
int back_to_word()
{

struct line_rec *line_table_ptr;
struct line_rec *line_table_next;
char temp_line[LINEMAXLEN];
int temp_cx;
int found = FALSE;
int finished = FALSE;
int beg_of_line = FALSE;
char * temp_cx_ptr;
int i,current;

new_cy = cy;

line_table_ptr = line_table_cur;

temp_cx = ((int) strlen(line_table_ptr->text) - 1);
if (cx <= temp_cx)
  temp_cx = cx;

temp_cx--;

if (temp_cx < 0)
    {
    line_table_ptr = line_table_ptr->prev_line;
    if (line_table_ptr != NULL)
      temp_cx = strlen(line_table_ptr->text) - 1;
    else
      {
      last_op_failed = TRUE;
      return FALSE;
      }
    new_cy -= 1;
    }

/* determine whether we are looking at an alphabetic char */
if (  (  (toupper(line_table_ptr->text[temp_cx]) >= 'A')
      && (toupper(line_table_ptr->text[temp_cx]) <= 'Z')
      )
   || (  (line_table_ptr->text[temp_cx] >= '0')
      && (line_table_ptr->text[temp_cx] <= '9')
      )
   )
  {
  current = ALPHA_CHAR;
  }
else /* determine if we are looking at a white space char */
if (  (line_table_ptr->text[temp_cx] == ' ')
   || (line_table_ptr->text[temp_cx] == CHAR_TAB)
   )
  {
  current = SPACE_CHAR;
  }
else /* we are looking at a symbol char */
  {
  current = SYMBOL_CHAR;
  }

if (line_table_ptr == NULL)
  {
  last_op_failed = TRUE;
  return FALSE;
  }
else
  {
  strcpy(temp_line,line_table_ptr->text);
  upper_case(temp_line);

  while (  (temp_cx >= 0)
        && (!finished)
        )
    {
    if (current == ALPHA_CHAR)
        {
        while (  (  (  (temp_line[temp_cx] >= 'A')
                    && (temp_line[temp_cx] <= 'Z')
                    )
                 || (  (temp_line[temp_cx] >= '0')
                    && (temp_line[temp_cx] <= '9')
                    )
                 )
              && (temp_cx >= 0)
              )
            {
            temp_cx--;
            }
        temp_cx++;
        finished = (found = (temp_cx >= 0));
        }

    if (  (current == SPACE_CHAR)
       || (current == SYMBOL_CHAR)
       )
        {
        while (  (  (temp_line[temp_cx] < 'A')
                 || (temp_line[temp_cx] > 'Z')
                 )
              && (  (temp_line[temp_cx] < '0')
                 || (temp_line[temp_cx] > '9')
                 )
              && (temp_cx >= 0)
              )
            {
            temp_cx--;
            }
	if (temp_cx >=0)
            {
            while (  (  (  (temp_line[temp_cx] >= 'A')
                        && (temp_line[temp_cx] <= 'Z')
                        )
                     || (  (temp_line[temp_cx] >= '0')
                        && (temp_line[temp_cx] <= '9')
                        )
                     )
                  && (temp_cx >= 0)
                  )
                {
                temp_cx--;
                }
            temp_cx++;
            finished = (found = (temp_cx >= 0));
            }
        }
    }

  while (!finished)
    {
    line_table_next = line_table_ptr->prev_line;
    if (line_table_next != NULL)
      temp_cx = strlen(line_table_next->text) - 1;
    new_cy -= 1;
    line_table_ptr = line_table_next;

    if (line_table_ptr != NULL)
      {
      strcpy(temp_line,line_table_ptr->text);
      upper_case(temp_line);

      while (  (  (temp_line[temp_cx] < 'A')
               || (temp_line[temp_cx] > 'Z')
               )
            && (  (temp_line[temp_cx] < '0')
               || (temp_line[temp_cx] > '9')
               )
            && (temp_cx >= 0)
            )
          {
          temp_cx--;
          }

      if (temp_cx >=0)
          {
          while (  (  (  (temp_line[temp_cx] >= 'A')
                      && (temp_line[temp_cx] <= 'Z')
                      )
                   || (  (temp_line[temp_cx] >= '0')
                      && (temp_line[temp_cx] <= '9')
                      )
                   )
                && (temp_cx >= 0)
                )
              {
              temp_cx--;
              }
          temp_cx++;
          finished = (found = (temp_cx >= 0));
          }
      }
    else
      finished = TRUE;
    }

  if (!found)
    {
    use_new_cy = FALSE;
    last_op_failed = TRUE;
    return FALSE;
    }
  else
    {
    line_table_cur = line_table_ptr;
    cx = temp_cx;
    use_new_cy = TRUE;
    return TRUE;
    }
  }
}


/**************************************/
void toggle_case()
{
  int x;

  if (cx > (int) strlen(line_buffer))
    cx = (int) strlen(line_buffer);

  if (cur_sx > (vx + SCREENCOLS - 1))
    {
    vx = cur_sx - SCREENCOLS + (SCREENCOLS/3);
    showscreen();
    }
  else
    if (cur_sx < vx)
      {
      vx = cur_sx - (SCREENCOLS/3);
      if (vx < 0) vx = 0;
      showscreen();
      }

  if (line_table_cur->in_block == TRUE)
    enter_inv();
  else
    normal();

  if (  (line_buffer[cx] >= 'a')
     && (line_buffer[cx] <= 'z')
     )
     line_buffer[cx] = (char) (line_buffer[cx] - ('a'-'A'));
  else if (  (line_buffer[cx] >= 'A')
          && (line_buffer[cx] <= 'Z')
          )
     line_buffer[cx] = (char) (line_buffer[cx] + ('a'-'A'));

  if (cx < (LINE_BUFFER_MAX-1))
    cx+=1;
  cur_sx = calc_sx_str(line_buffer,cx);
  if (cur_sx > (vx + SCREENCOLS - 1))
    {
    vx = cur_sx - SCREENCOLS + (SCREENCOLS/3);
    updateline(LEAVE_TRAILING_SPACES);
    showscreen();
    }
  else
    {
    showline_mv(line_table_cur,line_buffer,cy,cx,HILITE);
    cmove(cy,cur_sx-vx);
    }

  line_needs_updating = TRUE;
  file_needs_saving = TRUE;
}

/**************************************/
void insert_char(int c)
{
  int x;

  if (cx > (int) strlen(line_buffer))
    cx = (int) strlen(line_buffer);

  if (cur_sx > (vx + SCREENCOLS - 1))
    {
    vx = cur_sx - SCREENCOLS + (SCREENCOLS/3);
    showscreen();
    }
  else
    if (cur_sx < vx)
      {
      vx = cur_sx - (SCREENCOLS/3);
      if (vx < 0) vx = 0;
      showscreen();
      }

  if (line_table_cur->in_block == TRUE)
    enter_inv();
  else
    normal();

  if (insert_mode)
    {
    if ( (int)strlen(line_buffer) >= (LINE_BUFFER_MAX - 1) )
      {
      next_mess("Line is maximum length.");
      return;
      }
    else
      {
      ins_char_str(line_buffer,cx,c,LINE_BUFFER_MAX);
      cx+=1;
      cur_sx = calc_sx_str(line_buffer,cx);
      if (cur_sx > (vx + SCREENCOLS - 1))
        {
        vx = cur_sx - SCREENCOLS + (SCREENCOLS/3);
        updateline(LEAVE_TRAILING_SPACES);
        showscreen();
        }
      else
        {
        cx -= 1;
        cur_sx = calc_sx_str(line_buffer,cx);
        cmove(cy,cur_sx-vx);
        showline_right(line_table_cur,line_buffer,cy,cx,HILITE);
        cx += 1;
        cur_sx = calc_sx_str(line_buffer,cx);
        cmove(cy,cur_sx-vx);
        }
      }
    }
  else
    {
    if (cx >= ((int)strlen(line_buffer)))
      {
      if ( (int)strlen(line_buffer) >= (LINE_BUFFER_MAX - 1) )
        {
        next_mess("Line is maximum length.");
        return;
        }
      else
        ins_char_str(line_buffer,cx,c,LINE_BUFFER_MAX);
      }
    else
      line_buffer[cx] = c;
    if (cx < (LINE_BUFFER_MAX-1))
      cx+=1;
    cur_sx = calc_sx_str(line_buffer,cx);
    if (cur_sx > (vx + SCREENCOLS - 1))
      {
      vx = cur_sx - SCREENCOLS + (SCREENCOLS/3);
      updateline(LEAVE_TRAILING_SPACES);
      showscreen();
      }
    else
      {
      showline_mv(line_table_cur,line_buffer,cy,cx,HILITE);
      cmove(cy,cur_sx-vx);
      }
    }

  if (file_empty)
    {
    file_empty = FALSE;
    restore_status(ALL_STATUS,SCREENLINES-1,FALSE);
    lines_counted = FALSE;
    }

  line_needs_updating = TRUE;
  file_needs_saving = TRUE;
}

/**************************************/
char * repl_string(int *len,char *line,char *search,char *replace,int *cx)
{
int i,count;
char * new_line;
char * dest;
char * orig;

count = (int) strlen(replace) - (int) strlen(search);

*len = (int) strlen(line);
if (count > 0)
  *len += count;

if (*len < LINEMAXLEN)
  {
  new_line = (char *) malloc(*len + 2);

  if (new_line != NULL)
    {
    strcpy(new_line,line);

    i = 0;
    if (count < 0)
      while (i != count)
        {
        shift_left_str(new_line,*cx + 1,*len + 1);
        i -= 1;
        }
    else if (count > 0)
      while (i != count)
        {
        shift_right_str(new_line,*cx,*len + 1);
        i += 1;
        }

    dest = new_line;
    dest += *cx;
    orig = replace;

    while (*orig != '\0')
      {
      *dest = *orig;
      dest++;
      orig++;
      }
    }
  }

*cx += (int) strlen(replace);
return new_line;
}


/**************************************/
char * repl_expr(int *len,char *line,char *replace,int *cx,int search_len)
{
int i,count;
char * new_line;
char * dest;
char * orig;

count = (int) strlen(replace) - search_len;

*len = (int) strlen(line);
if (count > 0)
  *len += count;

if (*len < LINEMAXLEN)
  {
  new_line = (char *) malloc(*len + 2);

  if (new_line != NULL)
    {
    strcpy(new_line,line);

    i = 0;
    if (count < 0)
      while (i != count)
        {
        shift_left_str(new_line,*cx + 1,*len + 1);
        i -= 1;
        }
    else if (count > 0)
      while (i != count)
        {
        shift_right_str(new_line,*cx,*len + 1);
        i += 1;
        }

    dest = new_line;
    dest += *cx;
    orig = replace;

    while (*orig != '\0')
      {
      *dest = *orig;
      dest++;
      orig++;
      }
    }
  }

*cx += (int) strlen(replace);
return new_line;
}

/**********************/
void replace_expr(char replace_str[],char suffix_str[])
{
struct line_rec *line_table_oldcur;
struct line_rec *line_table_prev;
char temp_str[82];
int occurances = 0;

char *new_text;
int temp_len;
int new_len;
int old_len;
int finished = FALSE;
int replaced = FALSE;
int found_one = FALSE;
int temp_cx;
int temp_sx;
int prev_cx;
int prev_cy;
int old_cx;
int old_cy;
int replace_all = FALSE;
int replace_query = FALSE;
char reply_str[82];
int find_len;
int ok_to_replace = FALSE;
char reply;
int keypress;
int interrupted = FALSE;
int iteration=0;
int set_kb_blocking = FALSE;

last_op_failed = FALSE;
next_mess("");
old_cx = cx;
old_cy = cy;
line_table_oldcur = line_table_cur;

temp_cx = cx;
prev_cx = cx;
prev_cy = cy;
line_table_prev = line_table_cur;

if (  (strcmp(suffix_str,"A") == STR_SAME)
   || (strcmp(suffix_str,"ALL") == STR_SAME)
   )
  replace_all = TRUE;

if (  (strcmp(suffix_str,"Q") == STR_SAME)
   || (strcmp(suffix_str,"QUERY") == STR_SAME)
   )
  replace_query = TRUE;

if (  (replace_all)
   || (replace_query)
   )
  {
  if (block_marked == TRUE)
    line_table_cur = line_table_block_start;
  else
    line_table_cur = line_table_start;

  cx = 0;
  recalc_screen_cy(0);

  line_table_prev = line_table_cur;
  /* cx = -1; */
  if (! expr(expr_ptr,FORWARDS,CASE_SENS))
    {
    cx = 0;
    line_table_cur = line_table_prev;
    finished = TRUE;
    }
  else
    {
    temp_len = findlen;
    if (  (block_marked == TRUE)
       && (line_table_cur->in_block != TRUE)
       )
      finished = TRUE;
    else
      {
      if (replace_query)
        {
        cur_sx = calc_sx_str(line_table_cur->text,temp_cx);

        if (  (cur_sx > (vx + SCREENCOLS - 2 - temp_len))
           || (cur_sx < vx)
           )
          {
          vx = cur_sx - (SCREENCOLS/4) + 2 + temp_len;
          if (vx < 0) vx = 0;
          }
        use_new_cy = FALSE;
        showscreency(SCREENLINES/4);
        }
      }
    }
  }
else
  {
  next_mess("Internal error: ALL or QUERY must be specified.");
  return;
  }

if (kb_blocking)
  {
  non_block_kb(0);
  set_kb_blocking = TRUE;
  }

while (!finished)
  {
  temp_cx = cx;
  prev_cx = cx;
  prev_cy = new_cy;

  found_one = TRUE;
  replaced = FALSE;
  ok_to_replace = FALSE;
  if (!replace_query)
    ok_to_replace = TRUE;
  else
    {
    cmove(cy,cur_sx-vx);
    enter_inv();
    enter_bold();
    enter_under();
    win_reverse = A_REVERSE;
    win_bold = A_BOLD;
    win_underline = A_UNDERLINE;
    ni_waddstr(line_table_cur->text,VX_CHECK,temp_cx,temp_len,TRUE);
    normal();
    win_reverse = 0;
    win_bold = 0;
    win_underline = 0;
    reply = query("Do you want to replace this expression (Y,N or Cancel)? ");
    cmove(new_cy,temp_cx);
    if (reply == 'Y')
      ok_to_replace = TRUE;
    else if (reply == 'C')
      {
      showline_mv(line_table_cur,line_table_cur->text,new_cy,temp_cx,HILITE);
      finished = TRUE;
      }
    else
      showline_mv(line_table_cur,line_table_cur->text,new_cy,temp_cx,HILITE);
    }
  if (!ok_to_replace)
    {
    temp_cx += temp_len;
    }
  else
    {
    old_len = strlen(line_table_cur->text);
    new_text = repl_expr(&new_len,line_table_cur->text,replace_str,&temp_cx,temp_len);

    if (new_len >= LINEMAXLEN)
      {
      free(new_text);
      next_mess("Line too long.");
      break;
      }
    else if (new_text == NULL)
      {
      next_mess("Not enough memory available.");
      break;
      }
    else
      {
      if (new_len != old_len)
        {
        if (line_table_cur != line_table_oldcur)
          line_table_cur = replace_line(line_table_cur,new_text);
        else
          {
          line_table_cur = replace_line(line_table_cur,new_text);
          line_table_oldcur = line_table_cur;
          }
        }
      else
        strcpy(line_table_cur->text,new_text);

      free(new_text);
      new_text = NULL;

      if (replace_query)
        showline_mv(line_table_cur,line_table_cur->text,new_cy,temp_cx,HILITE);

      occurances = occurances + 1;
      }
    }
  line_table_prev = line_table_cur;
  if (!finished)
    {
    if (  (replace_all)
       || (replace_query)
       )
      {
      cx = temp_cx - 1;
      re_cx = -1;
      if (expr(expr_ptr,FORWARDS,CASE_SENS))
        {
        temp_len = findlen;
        if (  (block_marked == TRUE)
           && (line_table_cur->in_block != TRUE)
           )
          {
          line_table_cur = line_table_prev;
          finished = TRUE;
          }
        else
          {
          temp_cx = cx;
          if (replace_query)
            {
            cur_sx = calc_sx_str(line_table_cur->text,temp_cx);

            if (  (cur_sx > (vx + SCREENCOLS - 2 - (int)strlen(replace_str)))
               || (cur_sx < vx)
               )
              {
              vx = cur_sx - (SCREENCOLS/4) + 2 + temp_len;
              if (vx < 0) vx = 0;
              use_new_cy = FALSE;
              showscreency(SCREENLINES/4);
              }
            else
              {
              if (new_cy > (SCREENLINES-2))
                showscreency(SCREENLINES/4);
              else
                showscreency(new_cy);
              }
            }
          }
        }
      else
        {
        line_table_cur = line_table_prev;
        finished = TRUE;
        }
      }
    else
      {
      line_table_cur = line_table_prev;
      finished = TRUE;
      }
    }
  keypress = KB_ERR;
  iteration+=1;
  if (iteration > 10)
    {
    keypress = x_getch();
    iteration=0;
    }
  if (keypress != KB_ERR)
    {
    finished = TRUE;
    interrupted = TRUE;
    last_op_failed = TRUE;
    while (keypress != KB_ERR) keypress = x_getch();
    }
  }

if (set_kb_blocking)
  block_kb();

if (!found_one)
  {
  last_op_failed = TRUE;
  next_mess("Expression not found.");
  line_table_cur = line_table_oldcur;
  cx = old_cx;
  cy = old_cy;
  recalc_screen_cy(cy);
  }
else
  {
  if (occurances > 0)
    file_needs_saving = TRUE;
  if (mess_text[0] == '\0')
    {
    if (interrupted)
      sprintf(temp_str,"Interrupted: replaced %d occurrences.",occurances);
    else
      sprintf(temp_str,"Replaced %d occurrences of expression.",occurances);
    next_mess(temp_str);
    }

  if (replace_all)
    {
    line_table_cur = line_table_oldcur;
    cx = old_cx;
    cy = old_cy;
    use_new_cy = FALSE;
    showscreency(cy);
    }
  else
    if (!replace_query)
      {
      cx = old_cx;
      showline_mv(line_table_cur,line_table_cur->text,cy,cx,HILITE);
      }
    else
      {
      cx = prev_cx;
      cy = prev_cy;
      line_table_cur = line_table_prev;
      }
  }

use_new_cy = FALSE;
}


/**********************/
void replace(char find_str[],char replace_str[],char suffix_str[])
{
struct line_rec *line_table_oldcur;
struct line_rec *line_table_prev;
char temp_str[STRINGMAX];
char found_str[STRINGMAX];
char * found_ptr;
int occurances = 0;

char *new_text;
int new_len;
int old_len;
int finished = FALSE;
int replaced = FALSE;
int found_one = FALSE;
int temp_cx;
int temp_sx;
int prev_cx;
int prev_cy;
int old_cx;
int old_cy;
int replace_all = FALSE;
int replace_query = FALSE;
char reply_str[82];
int find_len;
int ok_to_replace = FALSE;
char reply;

next_mess("");
old_cx = cx;
old_cy = cy;
line_table_oldcur = line_table_cur;

temp_cx = cx;
prev_cx = cx;
prev_cy = cy;
line_table_prev = line_table_cur;

if (  (strcmp(suffix_str,"A") == STR_SAME)
   || (strcmp(suffix_str,"ALL") == STR_SAME)
   )
  replace_all = TRUE;

if (  (strcmp(suffix_str,"Q") == STR_SAME)
   || (strcmp(suffix_str,"QUERY") == STR_SAME)
   )
  replace_query = TRUE;

if (  (replace_all)
   || (replace_query)
   )
  {
  if (block_marked == TRUE)
    line_table_cur = line_table_block_start;
  else
    line_table_cur = line_table_start;

  cx = 0;
  recalc_screen_cy(0);

  line_table_prev = line_table_cur;
  cx = -1;
/*  if (!find(find_str,FORWARDS,CASE_SENS)) */
  if (!find(find_str,FORWARDS,case_sens))
    {
    cx = 0;
    line_table_cur = line_table_prev;
    finished = TRUE;
    }
  else
    if (  (block_marked == TRUE)
       && (line_table_cur->in_block != TRUE)
       )
      finished = TRUE;
    else
      {
      if (replace_query)
        {
        cur_sx = calc_sx_str(line_table_cur->text,temp_cx);

        if (  (cur_sx > (vx + SCREENCOLS - 2 - (int)strlen(replace_str)))
           || (cur_sx < vx)
           )
          {
          vx = cur_sx - (SCREENCOLS/4) + 2 + (int)strlen(findstr);
          if (vx < 0) vx = 0;
          }
        use_new_cy = FALSE;
        showscreency(SCREENLINES/4);
        }
      }
  }
else
  {
  new_text = (char *) &line_table_cur->text[cx];
  find_len = (int) strlen(find_str);

  if (STR_SAME != strncmp(new_text,find_str,find_len))
    finished = TRUE;
  }

while (!finished)
  {
  temp_cx = cx;
  prev_cx = cx;
  prev_cy = new_cy;

  found_one = TRUE;
  replaced = FALSE;
  ok_to_replace = FALSE;
  if (!replace_query)
    ok_to_replace = TRUE;
  else
    {
    cmove(cy,cur_sx-vx);
    normal();
    /* enter_inv(); */
    enter_bold();
    enter_under();
    /* win_reverse = A_REVERSE; */
    win_bold = A_BOLD;
    win_underline = A_UNDERLINE;
    found_ptr = ((char *) &(line_table_cur->text)) + cx;
    strncpy(found_str,found_ptr,(int)strlen(find_str));
    found_str[(int)strlen(find_str)]='\0';
    x_waddstr(found_str,VX_CHECK,cur_sx,TRUE);
    normal();
    win_reverse = 0;
    win_bold = 0;
    win_underline = 0;
    reply = query("Do you want to replace this string (Y,N or Cancel)? ");
    cmove(new_cy,temp_cx);
    if (reply == 'Y')
      ok_to_replace = TRUE;
    else if (reply == 'C')
      {
      showline_mv(line_table_cur,line_table_cur->text,new_cy,temp_cx,HILITE);
      finished = TRUE;
      }
    else
      showline_mv(line_table_cur,line_table_cur->text,new_cy,temp_cx,HILITE);
    }
  if (!ok_to_replace)
    {
    temp_cx += (int) strlen(find_str);
    }
  else
    {
    old_len = strlen(line_table_cur->text);
    new_text = repl_string(&new_len,line_table_cur->text,find_str,replace_str,&temp_cx);

    if (new_len >= LINEMAXLEN)
      {
      free(new_text);
      next_mess("Line too long.");
      break;
      }
    else if (new_text == NULL)
      {
      next_mess("Not enough memory available.");
      break;
      }
    else
      {
      if (new_len != old_len)
        {
        if (line_table_cur != line_table_oldcur)
          line_table_cur = replace_line(line_table_cur,new_text);
        else
          {
          line_table_cur = replace_line(line_table_cur,new_text);
          line_table_oldcur = line_table_cur;
          }
        }
      else
        strcpy(line_table_cur->text,new_text);

      free(new_text);
      new_text = NULL;

      if (replace_query)
        showline_mv(line_table_cur,line_table_cur->text,new_cy,temp_cx,HILITE);

      occurances = occurances + 1;
      }
    }
  line_table_prev = line_table_cur;
  if (!finished)
    {
    if (  (replace_all)
       || (replace_query)
       )
      {
      cx = temp_cx - 1;
      if (find(find_str,FORWARDS,case_sens))
        {
        if (  (block_marked == TRUE)
           && (line_table_cur->in_block != TRUE)
           )
          {
          line_table_cur = line_table_prev;
          finished = TRUE;
          }
        else
          {
          temp_cx = cx;
          if (replace_query)
            {
            cur_sx = calc_sx_str(line_table_cur->text,temp_cx);

            if (  (cur_sx > (vx + SCREENCOLS - 2 - (int)strlen(replace_str)))
               || (cur_sx < vx)
               )
              {
              vx = cur_sx - (SCREENCOLS/4) + 2 + (int)strlen(findstr);
              if (vx < 0) vx = 0;
              use_new_cy = FALSE;
              showscreency(SCREENLINES/4);
              }
            else
              {
              if (new_cy > (SCREENLINES-2))
                showscreency(SCREENLINES/4);
              else
                showscreency(new_cy);
              }
            }
          }
        }
      else
        {
        line_table_cur = line_table_prev;
        finished = TRUE;
        }
      }
    else
      {
      line_table_cur = line_table_prev;
      finished = TRUE;
      }
    }
  }

if (!found_one)
  {
  last_op_failed = TRUE;
  next_mess("String not found.");
  line_table_cur = line_table_oldcur;
  cx = old_cx;
  cy = old_cy;
  recalc_screen_cy(cy);
  }
else
  {
  last_op_failed = FALSE;
  if (occurances > 0)
    file_needs_saving = TRUE;
  if (mess_text[0] == '\0')
    {
    sprintf(temp_str,"Replaced %d occurrences of string.",occurances);
    next_mess(temp_str);
    }

  if (replace_all)
    {
    line_table_cur = line_table_oldcur;
    cx = old_cx;
    cy = old_cy;
    use_new_cy = FALSE;
    showscreency(cy);
    }
  else
    if (!replace_query)
      {
      cx = old_cx;
      showline_mv(line_table_cur,line_table_cur->text,cy,cx,HILITE);
      }
    else
      {
      cx = prev_cx;
      cy = prev_cy;
      line_table_cur = line_table_prev;
      }
  }

use_new_cy = FALSE;
}

/**********************/
void deleteblock(int from_moveblock)
{
struct line_rec *line_table_ptr;
struct line_rec *table_next;
struct line_rec *table_prev;
struct line_rec *line_table_before;
struct line_rec *line_table_after;

if (  macexec
   && macro_block_range
   )
  {
  next_mess("Macro terminated by DELETE-BLOCK command.");
  macro_range_error = TRUE;
  last_op_failed = TRUE;
  }
else if (block_marked == FALSE)
  next_mess("No block marked.");
else
  {
  highlight_block(FALSE);
  copyblock(FROM_DELETEBLOCK);
  if (!last_op_failed)
    {
    table_prev = NULL;
    line_table_before = line_table_block_start->prev_line;
    line_table_ptr = line_table_block_start;
  
    while (table_prev != line_table_block_end)
      {
      if (line_table_top == line_table_ptr)
        line_table_top = NULL;
      if (line_table_start == line_table_ptr)
        line_table_start = NULL;
      if (line_table_end == line_table_ptr)
        line_table_end = NULL;
      table_prev = line_table_ptr;
      table_next = line_table_ptr->next_line;
  
      if (  (line_table_before == NULL)
         && (table_next == NULL)
         )
             /* we are about to delete the last line of the file
                but we don't want to do that, just NULL the text */
        {
        strcpy(line_table_ptr->text,"");
        line_table_ptr->in_block = FALSE;
        if (! file_empty)
          {
          file_empty = TRUE;
          restore_status(ALL_STATUS,SCREENLINES-1,FALSE);
          }
        line_table_ptr->next_line = NULL;
        line_table_ptr->prev_line = NULL;
        line_table_after = NULL;
        }
      else
        {
        free(line_table_ptr);
        line_table_ptr = table_next;
        line_table_after = line_table_ptr;
        }
      }
  
    if (  (line_table_before != NULL)
       && (line_table_after != NULL)
       )
      {
      line_table_before->next_line = line_table_after;
      line_table_after->prev_line = line_table_before;
      line_table_cur = line_table_before;
      if (line_table_cur->next_line != NULL)
        line_table_cur = line_table_cur->next_line;
      }
    else if (  (line_table_before == NULL)
            && (line_table_after != NULL)
            )
      {
      line_table_cur = line_table_after;
      line_table_after->prev_line = NULL;
      }
    else if (  (line_table_before != NULL)
            && (line_table_after == NULL)
            )
      {
      line_table_cur = line_table_before;
      line_table_before->next_line = NULL;
      }
    else if (  (line_table_before == NULL)
            && (line_table_after == NULL)
            )
      {
      line_table_start = line_table_end = line_table_cur = line_table_ptr;
      line_table_top = line_table_ptr;
      }
  
    if (line_table_start == NULL) line_table_start = line_table_cur;
    if (line_table_end   == NULL) line_table_end   = line_table_cur;
    if (line_table_top   == NULL) line_table_top   = line_table_cur;
  
    line_table_block_end = NULL;
    line_table_block_start = NULL;
    block_marked = FALSE;
  
    if (!from_moveblock)
      {
      showscreency(cy);
      /* showscreency((SCREENLINES-1)/2); */
      /* showscreen(); */
      next_mess("Block deleted.");
      }
  
    file_needs_saving = TRUE;
    }
  }
}

/**********************/
void pasteblock(int from_moveblock)
{
struct line_rec *line_table_ptr;
struct line_rec *buff_table_ptr;

struct line_rec *insert_point_prev;
struct line_rec *insert_point_new;
struct line_rec *insert_point_next;
struct line_rec *insert_point_start;

if (buff_table_start == NULL)
	{
	last_op_failed = TRUE;
	next_mess("Buffer empty.");
	return;
	}

if (block_marked)
	{
	showblock(NO_HILITE);
	highlight_block(FALSE);
	block_marked = FALSE;
	line_table_block_start = line_table_block_end = NULL;
	}

insert_point_prev = line_table_cur->prev_line;
insert_point_next = line_table_cur;
insert_point_start = NULL;

buff_table_ptr = buff_table_start;

while (buff_table_ptr != NULL)
	{
	insert_point_new =
		(struct line_rec *)
		malloc(sizeof (struct line_rec) + strlen(buff_table_ptr->text));
	
	if (insert_point_new == NULL)
		{
		last_op_failed = TRUE;
		next_mess("Insufficient memory.");
		goto exit;
		}

	insert_point_new->prev_line = insert_point_prev;
	if (insert_point_prev == NULL)
		{
		line_table_start = insert_point_new;
		}
	else
		{
		insert_point_prev->next_line = insert_point_new;
		}

	insert_point_new->next_line = insert_point_next;
	if (insert_point_next != NULL)
		{
		insert_point_next->prev_line = insert_point_new;
		}

	strcpy(insert_point_new->text,buff_table_ptr->text);
	insert_point_new->in_block = FALSE;

	if (insert_point_start == NULL)
		{
		insert_point_start = insert_point_new;
		}

	insert_point_prev = insert_point_new;
	buff_table_ptr = buff_table_ptr->next_line;
	}

exit:

if	(file_empty)
	{
	file_empty = FALSE;

	insert_point_new->next_line = NULL;
	free(line_table_cur);
	line_table_cur = insert_point_start;
	line_table_start = line_table_cur;
	line_table_top = line_table_cur;
	line_table_end = insert_point_new;
	}
else
	{
	line_table_cur = insert_point_start;
	}

file_needs_saving = TRUE;
if (!from_moveblock)
	{
	restore_status(ALL_STATUS,SCREENLINES-1,FALSE);
	showscreency(cy);
	if (!last_op_failed)
		next_mess("Block pasted.");
	}
}


/**********************/
void copyblock(int from_deleteblock)
{
struct line_rec *line_table_ptr;
struct line_rec *buff_table_ptr;
struct line_rec *table_next;
struct line_rec *buff_table_prev;
struct line_rec *line_table_prev;

if (  macexec
   && macro_block_range
   )
  {
  next_mess("Macro terminated by COPY-BLOCK command.");
  macro_range_error = TRUE;
  last_op_failed = TRUE;
  }
else if (block_marked == FALSE)
  {
  last_op_failed = TRUE;
  next_mess("No block marked.");
  }
else
  {
  empty_buffer();
  showblock(NO_HILITE);
  highlight_block(FALSE);
  line_table_prev = NULL;
  line_table_ptr = line_table_block_start;

  buff_table_start =
      (struct line_rec *)
      malloc(sizeof (struct line_rec) + strlen(line_table_ptr->text));

  buff_table_ptr = buff_table_start;
  if (buff_table_ptr != NULL)
    buff_table_ptr->prev_line = NULL;

  while (line_table_prev != line_table_block_end)
    {
    if (buff_table_ptr == NULL)
      {
      last_op_failed = TRUE;
      next_mess("Insufficient memory.");
      goto exit;
      }
    strcpy(buff_table_ptr->text,line_table_ptr->text);
    line_table_ptr->in_block = FALSE;
    line_table_prev = line_table_ptr;
    table_next = line_table_ptr->next_line;
    line_table_ptr = table_next;

    if (line_table_ptr != NULL)
      table_next =
        (struct line_rec *)
        malloc(sizeof (struct line_rec) + strlen(line_table_ptr->text));
    else
      table_next =
        (struct line_rec *)
        malloc(sizeof (struct line_rec));

    buff_table_prev = buff_table_ptr;
    buff_table_ptr->next_line = table_next;
    buff_table_ptr = table_next;
    buff_table_ptr->prev_line = buff_table_prev;
    }
  free(buff_table_ptr);

exit:
  buff_table_ptr = buff_table_prev;
  buff_table_ptr->next_line = NULL;

  if (!from_deleteblock)
    {
    block_marked = FALSE;
    line_table_block_start = line_table_block_end = NULL;
    if (!last_op_failed)
      next_mess("Block copied.");
    restore_status(ALL_STATUS,SCREENLINES-1,FALSE);
    showscreen();
    }
  }
}

/***********************/
void empty_buffer()
{
struct line_rec *buff_table_ptr;
struct line_rec *table_next;

buff_table_ptr = buff_table_start;
while (buff_table_ptr != NULL)
  {
  table_next = buff_table_ptr->next_line;
  free(buff_table_ptr);
  buff_table_ptr = table_next;
  }
buff_table_end = buff_table_start = NULL;
}

/***********************/
void empty_memory()
{
struct line_rec *line_table_ptr;
struct line_rec *table_next;

line_table_ptr = line_table_start->next_line;
while (line_table_ptr != NULL)
  {
  table_next = line_table_ptr->next_line;
  free(line_table_ptr);
  line_table_ptr = table_next;
  }

file_empty = TRUE;
line_table_start->text[0] = '\0';
line_table_start->in_block = FALSE;
line_table_start->next_line = NULL;
line_table_start->prev_line = NULL;
line_table_block_start = NULL;
line_table_block_end = NULL;
block_marked = FALSE;
line_table_top = line_table_start;
line_table_cur = line_table_start;
line_table_bot = line_table_start;
line_table_end = line_table_start;
cx = 0; cy = 0;
}


/**********************/
void goto_marked_block()
{
if (line_table_block_start == NULL)
  {
  last_op_failed = TRUE;
  next_mess("No block marked.");
  return;
  }

line_table_top = line_table_cur = line_table_block_start;
showscreency((SCREENLINES-1)/3);
}


/**********************/
void markblock()
{
struct line_rec *line_table_ptr;
struct line_rec *line_table_next;

if (  macexec
   && macro_block_range
   )
  {
  next_mess("Macro terminated by MARK-BLOCK command.");
  macro_range_error = TRUE;
  last_op_failed = TRUE;
  }
else if (file_empty)
  next_mess("No text to mark.");
else
  if (line_table_block_start == NULL)
  /* there are no block markers */
    {
    line_table_block_start = line_table_cur;
    next_mess("One block marker placed.");
    }
  else if (line_table_block_end == NULL)
  /* there is a block start but no block end */
    {
    if (line_table_cur == line_table_block_start)
    /* there is a block start, block end will be on same line (1 line block) */
      {
      line_table_block_end = line_table_cur;
      block_marked = TRUE;
      highlight_block(TRUE);
      showblock(HILITE);
      next_mess("Block marked.");
      }
    else
    /* There is already a block start & the block end will not be on same line.
       So it is necessary to check that the 2nd marker (block end) is below
       the first (block start). If it is not, then they must be swapped around.
    */
      {
      line_table_ptr = line_table_end;
      while (  (line_table_ptr != line_table_block_start)
            && (line_table_ptr != line_table_cur)
            && (line_table_ptr != NULL)
            )
        {
        line_table_next = line_table_ptr->prev_line;
        line_table_ptr = line_table_next;
        }
      if (line_table_ptr == line_table_cur)
        line_table_block_end = line_table_cur;
      else if (line_table_ptr == line_table_block_start)
        {
        line_table_block_end = line_table_block_start;
        line_table_block_start = line_table_cur;
        }
      block_marked = TRUE;
      highlight_block(TRUE);
      showblock(HILITE);
      next_mess("Block marked.");
      }
    }
  else
  /* There is already a block start & block end, so NULL them to create
     a new block, with a block start only.
  */
    {
    showblock(NO_HILITE);
    highlight_block(FALSE);
    line_table_block_end = NULL;
    line_table_block_start = line_table_cur;
    block_marked = FALSE;
    next_mess("One block marker placed.");
    }
  
}

/**********************/
void highlight_block(int on_off)
{
struct line_rec *line_table_ptr;
struct line_rec *line_table_next;
struct line_rec *line_table_prev = NULL;

if (  (block_marked == TRUE)
   && (line_table_block_start != NULL)
   && (line_table_block_end != NULL)
   )
  {
  line_table_ptr = line_table_block_start;
  while (  (line_table_prev != line_table_block_end)
        && (line_table_ptr != NULL)
        )
    {
    line_table_prev = line_table_ptr;
    line_table_ptr->in_block = on_off;
    line_table_next = line_table_ptr->next_line;
    line_table_ptr = line_table_next;
    }
  }
}

/**************************************/
int in_str(char line[],char *pattern,int *cx,int direction)
{
/* these defines are for the found variable */
#define YES 0
#define NO 1

int len;
int found = 1;
int finished = FALSE;
char * start;

len = strlen(pattern);

start = (char *) &(line[*cx]);
if (*start == '\0')
  finished = TRUE;
else
  if (STR_SAME == strncmp(start,pattern,len))
    {
    if (word_search)
      {
      if (  (  (line[(*cx)+len] < 'a')
            || (line[(*cx)+len] > 'z')
            )
         && (  (line[(*cx)+len] < 'A')
            || (line[(*cx)+len] > 'Z')
            )
         && (  (line[(*cx)+len] < '0')
            || (line[(*cx)+len] > '9')
            )
         )
        {
        if (  (*cx > 0)
           && (  (line[(*cx)-1] < 'a')
              || (line[(*cx)-1] > 'z')
              )
           && (  (line[(*cx)-1] < 'A')
              || (line[(*cx)-1] > 'Z')
              )
           && (  (line[(*cx)-1] < '0')
              || (line[(*cx)-1] > '9')
              )
           )
          {
          finished = TRUE;
          found = YES;
          }
        else
          if (*cx == 0)
            {
            finished = TRUE;
            found = YES;
            }
        }
      }
    else
      {
      finished = TRUE;
      found = YES;
      }
    }

while (!finished)
  {
  if (direction == FORWARDS)
    *cx += 1;
  else
    *cx -= 1;

  if (*cx >= 0)
    {
    start = (char *) &(line[*cx]);
    if (*start == '\0')
      finished = TRUE;
    }
  else
    finished = TRUE;

  if (!finished)
    if (STR_SAME == strncmp(start,pattern,len))
      {
      if (word_search)
        {
        if (  (  (line[(*cx)+len] < 'a')
              || (line[(*cx)+len] > 'z')
              )
           && (  (line[(*cx)+len] < 'A')
              || (line[(*cx)+len] > 'Z')
              )
           && (  (line[(*cx)+len] < '0')
              || (line[(*cx)+len] > '9')
              )
           )
          {
          if (  (*cx > 0)
             && (  (line[(*cx)-1] < 'a')
                || (line[(*cx)-1] > 'z')
                )
             && (  (line[(*cx)-1] < 'A')
                || (line[(*cx)-1] > 'Z')
                )
             && (  (line[(*cx)-1] < '0')
                || (line[(*cx)-1] > '9')
                )
             )
            {
            finished = TRUE;
            found = YES;
            }
          else
            if (*cx == 0)
              {
              finished = TRUE;
              found = YES;
              }
          }
        }
      else
        {
        finished = TRUE;
        found = YES;
        }
      }
  }

if (found == YES)
  return TRUE;
else
  return FALSE;
}


/***************************************/
/* New version based on new RE library */
/***************************************/
/* int in_expr(char line[],char *pattern,int *cx,int direction) */
int in_expr(char line[],pcre *pattern,int *cx,int direction)
{
#define OVECSIZE 60
int return_code;
int ovector[OVECSIZE];
int pcre_options = 0;
char temp_str[LINEMAXLEN];

/* if (line[0] == '\0') return FALSE; */

if (*cx > 0) pcre_options = PCRE_NOTBOL;

return_code = pcre_exec(pattern,NULL,line,strlen(line),*cx,pcre_options,ovector,OVECSIZE);

if (return_code > 0)
  {
  *cx = ovector[0];
  re_cx = ovector[1];
  findlen = ovector[1] - ovector[0];
  return TRUE;
  }

switch (return_code)
  {
  case -2: next_mess("Internal error: <subject> or <RE> is null.");
           last_op_failed = TRUE;
           return FALSE;;
           ;
    
  case -3: next_mess("Internal error: pcre_exec() OPTION parameter is bad.");
           last_op_failed = TRUE;
           return FALSE;
           ;
    
  case -4: next_mess("Internal error: compiled <RE> is corrupt.");
           last_op_failed = TRUE;
           return FALSE;
           ;
    
  case -5: next_mess("Internal error: compiled <RE> is corrupt.");
           last_op_failed = TRUE;
           return FALSE;
           ;
    
  case -6: next_mess("Insufficient memory to match RE.");
           last_op_failed = TRUE;
           return FALSE;
           ;
  }

if (return_code < -6)
  {
  next_mess("RE library function call failed.");
  last_op_failed = TRUE;
  return FALSE;
  }

return FALSE;
}


/**********************/
/* int expr(char * str,int direction,int case_sens) */
int expr(pcre * str,int direction,int case_sens)
{
struct line_rec *line_table_ptr;
struct line_rec *line_table_next;
char temp_line[LINEMAXLEN];
char * str_to_find;
int temp_cx;
int found = FALSE;
int finished = FALSE;
int end_of_line = FALSE;
char * temp_cx_ptr;
int i;

new_cy = cy;
line_table_ptr = line_table_cur;
if (re_cx >= 0)
  temp_cx = re_cx;
else
  temp_cx = cx+1;

if (temp_cx >= 0)
  {
  if (temp_cx >= (int) strlen(line_table_ptr->text))
    end_of_line = TRUE;
  }
else
  end_of_line = TRUE;
if (end_of_line)
  {
  if (direction == FORWARDS)
    {
    line_table_ptr = line_table_ptr->next_line;
    temp_cx = 0;
    new_cy += 1;
    }
  else
    {
    line_table_ptr = line_table_ptr->prev_line;
    if (line_table_ptr != NULL)
      temp_cx = strlen(line_table_ptr->text) - 1;
    new_cy -= 1;
    }
  }
if (line_table_ptr == NULL)
  {
  last_op_failed = TRUE;
  return FALSE;
  }
else
  {
  strcpy(temp_line,line_table_ptr->text);
  finished = (found = in_expr(temp_line,str,&temp_cx,direction));
  while ((!finished) && (!last_op_failed))
    {
    if (direction == FORWARDS)
      {
      line_table_next = line_table_ptr->next_line;
      temp_cx = 0;
      new_cy += 1;
      }
    else
      {
      line_table_next = line_table_ptr->prev_line;
      if (line_table_next != NULL)
        temp_cx = strlen(line_table_next->text) - 1;
      new_cy -= 1;
      }
    line_table_ptr = line_table_next;
    if (line_table_ptr != NULL)
      {
      strcpy(temp_line,line_table_ptr->text);
      finished = (found = in_expr(temp_line,str,&temp_cx,direction));
      }
    else
      finished = TRUE;
    }
  if (!found)
    {
    use_new_cy = FALSE;
    last_op_failed = TRUE;
    if (  macexec
       && macro_block_range
       )
      {
      macro_range_error = TRUE;
      next_mess("Macro reached end of block.");
      }
    return FALSE;
    }
  else
    {
    line_table_cur = line_table_ptr;
    cx = temp_cx;
    use_new_cy = TRUE;
    return TRUE;
    }
  }
}


/**********************/
int find_str_re(int direction,int case_sens)
{
if (!findstr_is_re)
  return find(findstr,direction,case_sens);
else
  return expr(expr_ptr,direction,case_sens);
}

/**********************/
int find(char str[],int direction,int case_sens)
{
struct line_rec *line_table_ptr;
struct line_rec *line_table_next;
char temp_line[LINEMAXLEN];
char str_to_find[LINEMAXLEN];
int temp_cx;
int found = FALSE;
int finished = FALSE;
int end_of_line = FALSE;
char * temp_cx_ptr;
int i;

new_cy = cy;

if (strcmp(str,"") != STR_SAME)
  {
  line_table_ptr = line_table_cur;

  if (direction == FORWARDS)
    temp_cx = cx + 1;
  else
    temp_cx = cx - 1;

/*
 line[cx] == '\0' cannot be used to see if we are at or past EOL 
 because cx may be some way after EOL & therefore there may
 not be a null in that position
*/
  if (temp_cx >= 0)
    {
    if (temp_cx >= (int) strlen(line_table_ptr->text))
      end_of_line = TRUE;
    }
  else
    end_of_line = TRUE;

  if (end_of_line)
    {
    if (direction == FORWARDS)
      {
      line_table_ptr = line_table_ptr->next_line;
      temp_cx = 0;
      new_cy += 1;
      }
    else
      {
      line_table_ptr = line_table_ptr->prev_line;
      if (line_table_ptr != NULL)
        temp_cx = strlen(line_table_ptr->text) - 1;
      new_cy -= 1;
      }
    }

  if (line_table_ptr == NULL)
    {
    last_op_failed = TRUE;
    return FALSE;
    }
  else
    {
    strcpy(temp_line,line_table_ptr->text);
    strcpy(str_to_find,str);
    if (! case_sens)
      {
      upper_case(temp_line);
      upper_case(str_to_find);
      }

    finished = (found = in_str(temp_line,str_to_find,&temp_cx,direction));

    while (!finished)
      {
      if (direction == FORWARDS)
        {
        line_table_next = line_table_ptr->next_line;
        temp_cx = 0;
        new_cy += 1;
        }
      else
        {
        line_table_next = line_table_ptr->prev_line;
        if (line_table_next != NULL)
          temp_cx = strlen(line_table_next->text) - 1;
        new_cy -= 1;
        }
      line_table_ptr = line_table_next;

      if (line_table_ptr != NULL)
        {
        if (! case_sens)
          {
          strcpy(temp_line,line_table_ptr->text);
          upper_case(temp_line);
          }
        else
          strcpy(temp_line,line_table_ptr->text);

        finished = (found = in_str(temp_line,str_to_find,&temp_cx,direction));
        }
      else
        finished = TRUE;
      }

    if (!found)
      {
      use_new_cy = FALSE;
      last_op_failed = TRUE;
      return FALSE;
      }
    else
      {
      line_table_cur = line_table_ptr;
      cx = temp_cx;
      use_new_cy = TRUE;
      return TRUE;
      }
    }
  }
else
  {
  next_mess("No string to find.");
  use_new_cy = FALSE;
  last_op_failed = TRUE;
  return FALSE;
  }
}

/**********************/
char * upper_case(char *source)
{
char * orig;
orig = source;
while (*source != '\0')
  {
  *source = (char) toupper(*source);
  source++;
  }
return orig;
}

/**********************/
int gotoline(int line)
{
int i = 1;
struct line_rec *line_table_next;
struct line_rec *line_table_ptr;
struct line_rec *line_table_save = line_table_top;

line_table_ptr = line_table_start;
while (  (i < line)
      && (line_table_ptr->next_line != NULL)
      )
  {
  line_table_next = line_table_ptr->next_line;
  line_table_ptr = line_table_next;
  i = i + 1;
  }
if (i == line)
  {
  line_table_top = line_table_cur = line_table_ptr;
  showscreency((SCREENLINES-1)/2);
  new_count = line;
  return TRUE;
  }
else
  {
  last_op_failed = TRUE;
  next_mess("Line not found.");
  return TRUE;
  }
}

/**************************/
void split_line()
{
struct line_rec *line_table_new;

char prev_text[LINEMAXLEN];
char cur_text[LINEMAXLEN];

int i,j;

strcpy(prev_text,line_table_cur->text);
strcpy(cur_text,line_table_cur->text);

i = cx;
prev_text[i] = '\0';

insert_line_text(line_table_cur,prev_text);

if (line_table_block_start == line_table_cur)
  if (block_marked)
    {
    line_table_block_start = line_table_cur->prev_line;
    if (line_table_block_start == NULL)
      line_table_block_start = line_table_cur;
    line_table_block_start->in_block = TRUE;
    }

i = cx;
if (i >= ((int)strlen(cur_text)))
  i = strlen(cur_text);
j = 0;
do
  {
  cur_text[j] = cur_text[i];
  i += 1;
  j += 1;
  } while (cur_text[j-1] != '\0');

line_table_cur = replace_line(line_table_cur,cur_text);


}

/**************************/
void delete_line()
{
struct line_rec *line_table_next;
struct line_rec *line_table_prev;
struct line_rec *line_table_temp;
struct line_rec *line_table_new;

line_table_prev = line_table_cur->prev_line;
line_table_next = line_table_cur->next_line;
line_table_temp = line_table_cur;

if (block_marked)
  {
  if (  (line_table_cur == line_table_block_start)
     && (line_table_cur == line_table_block_end)
     )
      {
      showblock(NO_HILITE);
      highlight_block(FALSE);
      line_table_block_start = line_table_block_end = NULL;
      block_marked = FALSE;
      next_mess(" ");
      }
  else if (line_table_cur == line_table_block_start)
      {
      if (line_table_next != NULL)
        line_table_block_start = line_table_next;
      else
          {
          showblock(NO_HILITE);
          highlight_block(FALSE);
          line_table_block_start = line_table_block_end = NULL;
          block_marked = FALSE;
          next_mess(" ");
          }
      }
  else if (line_table_cur == line_table_block_end)
      {
      if (line_table_prev != NULL)
        line_table_block_end = line_table_prev;
      else
          {
          showblock(NO_HILITE);
          highlight_block(FALSE);
          line_table_block_start = line_table_block_end = NULL;
          block_marked = FALSE;
          next_mess(" ");
          }
      }
  }

if (  (line_table_next != NULL)
   && (line_table_prev != NULL)
   )
    {
    if (last_line_deleted != NULL)
        free(last_line_deleted);
    last_line_deleted = line_table_cur;
  
    line_table_next->prev_line = line_table_prev;
    line_table_prev->next_line = line_table_next;
    line_table_cur = line_table_next;
    if (line_table_top == line_table_temp) line_table_top = line_table_cur;
    deline();
    if (line_table_bot->next_line != NULL)
        {
        line_table_bot = line_table_bot->next_line;
        show_bot_line();
        cur_sx = calc_sx_str(line_table_cur->text,cx);
        cmove(cy,cur_sx-vx);
        restore_status(ALL_STATUS,SCREENLINES-1,FALSE);
        }
    else
        {
        if (line_table_bot == line_table_temp) line_table_bot = line_table_cur;
        cmove(SCREENLINES-2,0);
        ins_line();
        cur_sx = calc_sx_str(line_table_cur->text,cx);
        cmove(cy,cur_sx-vx);
        }
    if (  (line_table_cur->next_line == NULL) 
       && (message_pending == 0)
       )
      message_pending = 1;
  
    file_needs_saving = TRUE;
    lines_counted = FALSE;
    }

else /* end line of file */
    if (  (line_table_next == NULL)
       && (line_table_prev != NULL)
       )
        {
        if (last_line_deleted != NULL)
            free(last_line_deleted);

        last_line_deleted = line_table_cur;
    
        line_table_prev->next_line = NULL;
        line_table_end = line_table_prev;
        line_table_cur = line_table_prev;
        cmove(cy,0);
        clreol();
        cy = cy - 1;
        new_count = (cur_line_no - 1);
        
        if (cy < 0)
            {
            if (line_table_bot == line_table_temp) line_table_bot = line_table_cur;
            if (line_table_top == line_table_temp)
                {
                line_table_top = line_table_cur;
                showscreen();
                }
            }
        else
          if (line_table_bot == line_table_temp) line_table_bot = line_table_cur;
        cur_sx = calc_sx_str(line_table_cur->text,cx);
        cmove(cy,cur_sx-vx);
    
        file_needs_saving = TRUE;
        lines_counted = FALSE;
        }
  
    else /* first line of file */
        if (  (line_table_prev == NULL)
           && (line_table_next != NULL)
           )
            {
            if (last_line_deleted != NULL)
                free(last_line_deleted);

            last_line_deleted = line_table_cur;
      
            line_table_next->prev_line = NULL;
            line_table_start = line_table_next;
            line_table_cur = line_table_next;
            if (line_table_top == line_table_temp) line_table_top = line_table_cur;
            deline();
            if (line_table_bot->next_line != NULL)
                {
                line_table_bot = line_table_bot->next_line;
                show_bot_line();
                cur_sx = calc_sx_str(line_table_cur->text,cx);
                cmove(cy,cur_sx-vx);
                restore_status(ALL_STATUS,SCREENLINES-1,FALSE);
                }
            else
                {
                cmove(SCREENLINES-2,0);
                ins_line();
                cur_sx = calc_sx_str(line_table_cur->text,cx);
                cmove(cy,cur_sx-vx);
                }
            if (  (line_table_cur->next_line == NULL) 
               && (message_pending == 0)
               )
              message_pending = 1;
      
            file_needs_saving = TRUE;
            lines_counted = FALSE;
            }
    
        else /* last remaining line of file */
            {
            if (  (line_table_next == NULL)
               && (line_table_prev == NULL)
               && (! file_empty)
               )
            /* we are about to delete the last line in the file, but don't do that.
               Just null the text & set the file_empty flag
            */
                {
                if (last_line_deleted != NULL)
                    free(last_line_deleted);
  
                last_line_deleted = line_table_cur;
        
                line_table_new = (struct line_rec *) malloc(sizeof (struct line_rec));
                if (line_table_new == NULL)
                    {
                    next_mess("Insufficient memory.");
                    goto exit;
                    }
                strcpy(line_table_new->text,"");
                line_table_cur = line_table_new;
                line_table_cur->prev_line = NULL;
                line_table_cur->next_line = NULL;
        
                line_table_top = line_table_cur;
                line_table_start = line_table_cur;
                line_table_end = line_table_cur;
                line_table_bot = line_table_cur;
                cmove(cy,0);
                clreol();
                cy = 0;
                cx = 0;
                cur_sx = calc_sx_str(line_table_cur->text,cx);
                cmove(cy,cur_sx-vx);
                line_table_cur->in_block = FALSE;
                file_needs_saving = TRUE;
                lines_counted = FALSE;
        
                if (! file_empty)
                    {
                    file_empty = TRUE;
                    restore_status(ALL_STATUS,SCREENLINES-1,FALSE);
                    }
                }
            }
exit: ;
}

/**************************/
void undelete_line()
{
char c;
struct line_rec *line_table_ptr;
struct line_rec *temp_table_ptr;
struct line_rec *temp_table_next;
struct line_rec *temp_table_prev;

if (last_line_deleted == NULL)
  {
  last_op_failed = TRUE;
  next_mess("No line to undelete.");
  return;
  }

if (last_line_deleted->next_line != NULL)
    {
    if (block_marked)
      {
      showblock(NO_HILITE);
      highlight_block(FALSE);
      block_marked = FALSE;
      line_table_block_start = line_table_block_end = NULL;
      }
  
    line_table_ptr = line_table_start;
  
    while (  (line_table_ptr != last_line_deleted->next_line)
          && (line_table_ptr != last_line_deleted->prev_line)
          && (line_table_ptr != line_table_end)
          )
      {
      line_table_ptr = line_table_ptr->next_line;
      }
  
    if (  (line_table_ptr != last_line_deleted->next_line)
       && (line_table_ptr != last_line_deleted->prev_line)
       )
       {
       c = query_with_prompt("Context lines not found. Restore above current line (Y or N)? ","Medit: ");
       if (c != 'Y')
         {
         last_op_failed = TRUE;
         next_mess("Line not undeleted.");
         return;
         }
       line_table_ptr = line_table_cur;
       }

    if (file_empty)
       {
       line_table_start = last_line_deleted;
       line_table_top = last_line_deleted;
       last_line_deleted->prev_line = NULL;
       last_line_deleted->next_line = NULL;
       line_table_cur = last_line_deleted;
       free(line_table_ptr);
       file_empty = FALSE;
       }
    else if (line_table_ptr == last_line_deleted->prev_line)
       {
       temp_table_next = line_table_ptr->next_line;
       last_line_deleted->next_line = temp_table_next;
       temp_table_next->prev_line = last_line_deleted;
       line_table_ptr->next_line = last_line_deleted;
       line_table_cur = last_line_deleted;
       }
    else if (line_table_ptr == last_line_deleted->next_line)
       {
       line_table_start = last_line_deleted;
       line_table_top = last_line_deleted;
       line_table_ptr->prev_line = last_line_deleted;
       last_line_deleted->next_line = line_table_ptr;
       line_table_cur = last_line_deleted;
       }
    else
       {
       last_op_failed = TRUE;
       next_mess("Internal error in Undelete Line.");
       return;
       }
  
    last_line_deleted = NULL;
  
    file_needs_saving = TRUE;
    restore_status(ALL_STATUS,SCREENLINES-1,FALSE);
    showscreency(cy);
    if (!last_op_failed)
      next_mess("Line undeleted.");
    }

else /* if (last_line_deleted->next_line == NULL) */
    {
    if (block_marked)
        {
        showblock(NO_HILITE);
        highlight_block(FALSE);
        block_marked = FALSE;
        line_table_block_start = line_table_block_end = NULL;
        }

    if (file_empty)
       {
       free(line_table_cur);
       line_table_cur = last_line_deleted;
       line_table_start = line_table_cur;
       line_table_start->in_block = FALSE;
       line_table_start->next_line = NULL;
       line_table_start->prev_line = NULL;
       line_table_top = line_table_start;
       line_table_cur = line_table_start;
       line_table_bot = line_table_start;
       line_table_end = line_table_start;
       line_table_cur = line_table_start;
       file_empty = FALSE;

       last_line_deleted = NULL;
       file_needs_saving = TRUE;
       restore_status(ALL_STATUS,SCREENLINES-1,FALSE);
       showscreen();
       }
    else
       {
       line_table_end->next_line = last_line_deleted;
       last_line_deleted->prev_line = line_table_end;
       last_line_deleted->next_line = NULL;
     
       line_table_end = last_line_deleted;
       line_table_cur = last_line_deleted;

       last_line_deleted = NULL;
       file_needs_saving = TRUE;
       restore_status(ALL_STATUS,SCREENLINES-1,FALSE);
       showscreency(cy);
       }

    if (!last_op_failed)
      next_mess("Line undeleted.");
    }
}



/**************************/
void insert_line()
{
struct line_rec *line_table_new;
struct line_rec *line_table_prev;
struct line_rec *line_table_temp;

if (file_empty == TRUE)
  {
  strcpy(line_table_cur->text,"");
  file_empty = FALSE;
  restore_status(ALL_STATUS,SCREENLINES-1,FALSE);
  }
if (file_empty != TRUE)
  {
  line_table_new = (struct line_rec *) malloc(sizeof (struct line_rec));
  if (line_table_new == NULL)
    {
    next_mess("Insufficient memory.");
    goto exit;
    }
  strcpy(line_table_new->text,"");
  line_table_prev = line_table_cur->prev_line;
  if (line_table_prev != NULL)
    line_table_prev->next_line = line_table_new;
  line_table_cur->prev_line = line_table_new;
  line_table_new->next_line = line_table_cur;
  line_table_new->prev_line = line_table_prev;
  if (line_table_new->prev_line == NULL)
    line_table_start = line_table_new;
  if (line_table_top == line_table_cur)
    line_table_top = line_table_new;

  if (line_table_prev != NULL)
    {
    if (  (line_table_prev->in_block == TRUE)
       && (line_table_cur->in_block == TRUE)
       )
      line_table_new->in_block = TRUE;
    else
      line_table_new->in_block = FALSE;
    }
  else
    line_table_new->in_block = FALSE;

  file_needs_saving = TRUE;
  lines_counted = FALSE;
  }
exit:
  ;
}

/**********************/
void insert_line_end()
{
struct line_rec *line_table_new;

if (file_empty == TRUE)
  {
  strcpy(line_table_cur->text,"");
  file_empty = FALSE;
  restore_status(ALL_STATUS,SCREENLINES-1,FALSE);
  }
if (file_empty != TRUE)
  {
  line_table_new = (struct line_rec *) malloc(sizeof(struct line_rec));
  if (line_table_new == NULL)
    {
    next_mess("Insufficient memory.");
    goto exit;
    }
  strcpy(line_table_new->text,"");
  line_table_new->in_block = FALSE;
  line_table_end->next_line = line_table_new;
  line_table_new->prev_line = line_table_end;
  line_table_new->next_line = NULL;
  line_table_end = line_table_new;
  line_table_cur = line_table_new;
  file_needs_saving = TRUE;
  cx = 0;
  }
exit:
  ;
}


/**********************/
struct line_rec * join_ptr(struct line_rec *line_table_ptr)

/*-------------
join the line_table_ptr line to the previous line, if it exists,
and return a pointer to the new line.
-------------*/

{
struct line_rec *line_table_prev;
struct line_rec *line_table_temp;

int total_len,prev_len,cur_len;
char prev_text[LINEMAXLEN];
char cat_text[LINEMAXLEN];
char dummy;

line_table_prev = line_table_ptr->prev_line;

if (line_table_prev != NULL)
  {
  strcpy(prev_text,line_table_prev->text);
  strcpy(cat_text,line_table_ptr->text);

  prev_len = strlen(prev_text);

  cur_len = strlen(cat_text);
  total_len = prev_len + cur_len;

  if (total_len > (LINEMAXLEN-1))
    {
    next_mess("Line too long.");
    return line_table_ptr;
    }
  else
    {
    if (  (block_marked == TRUE)
       && (line_table_prev->in_block != line_table_ptr->in_block)
       )
      {
      showblock(NO_HILITE);
      highlight_block(FALSE);
      line_table_block_start = line_table_block_end = NULL;
      block_marked = FALSE;
      next_mess(find_text);
      }

    strcat(prev_text,cat_text);

    line_table_prev = replace_line(line_table_prev,prev_text);

    line_table_prev->next_line = line_table_ptr->next_line;
    if (line_table_prev->next_line == NULL)
      {
      line_table_bot = line_table_prev;
      line_table_end = line_table_prev;
      }
    else
      {
      line_table_temp = line_table_prev->next_line;
      line_table_temp->prev_line = line_table_prev;
      }

    line_table_prev->in_block = line_table_ptr->in_block;

    if (block_marked == TRUE)
      {
      if (line_table_ptr == line_table_block_start)
        line_table_block_start = line_table_prev;

      if (line_table_ptr == line_table_block_end)
        line_table_block_end = line_table_prev;
      }

    free(line_table_ptr);
    return line_table_prev;
    }
  }
else
  return line_table_ptr;
}


/*************************/
struct line_rec * replace_line(struct line_rec *line_table_ptr,char line_buffer[])
/*----------
replace the line_table_ptr text with line_buffer.
Note that this is now more compilacted with variable text fields.
------------
*/
{
struct line_rec *line_table_new;
struct line_rec *line_table_temp;
int x,c;

line_table_new =
  (struct line_rec *)
     malloc(sizeof (struct line_rec) + strlen(line_buffer));

if (line_table_new == NULL)
  {
  next_mess("Insufficient memory.");
  return line_table_ptr;
  }

strcpy(line_table_new->text,line_buffer);
line_table_new->in_block = line_table_ptr->in_block;

line_table_temp = line_table_ptr->prev_line;
if (line_table_temp != NULL)
  line_table_temp->next_line = line_table_new;
line_table_new->prev_line = line_table_temp;

line_table_temp = line_table_ptr->next_line;
if (line_table_temp != NULL)
  line_table_temp->prev_line = line_table_new;
line_table_new->next_line = line_table_temp;

if (line_table_cur == line_table_ptr) line_table_cur = line_table_new;
if (line_table_start == line_table_ptr) line_table_start = line_table_new;
if (line_table_end == line_table_ptr) line_table_end = line_table_new;
if (line_table_top == line_table_ptr) line_table_top = line_table_new;
if (line_table_bot == line_table_ptr) line_table_bot = line_table_new;
if (line_table_block_start == line_table_ptr)
  line_table_block_start = line_table_new;

if (line_table_block_end == line_table_ptr)  
  line_table_block_end = line_table_new;

free(line_table_ptr);
file_needs_saving = TRUE;
return line_table_new;
}

/**************************/
void insert_line_text(struct line_rec *line_table_ptr,char line_buffer[])
/*----------
insert a new line of text above the line_table_ptr line,
and containing the text in line_buffer.
------------
*/
{
  struct line_rec *line_table_new;
  struct line_rec *line_table_prev;
  int i = 0;

  if (file_empty == TRUE)
    {
    strcpy(line_table_cur->text,"");
    file_empty = FALSE;
    restore_status(ALL_STATUS,SCREENLINES-1,FALSE);
    }

  line_table_new =
    (struct line_rec *) malloc(sizeof (struct line_rec) + strlen(line_buffer));
  if (line_table_new == NULL)
    {
    next_mess("Insufficient memory.");
    goto exit;
    }
  strcpy(line_table_new->text,line_buffer);
  line_table_prev = line_table_ptr->prev_line;
  if (line_table_prev != NULL)
    line_table_prev->next_line = line_table_new;
  line_table_ptr->prev_line = line_table_new;
  line_table_new->next_line = line_table_ptr;
  line_table_new->prev_line = line_table_prev;
  if (line_table_new->prev_line == NULL)
    line_table_start = line_table_new;
  if (line_table_top == line_table_ptr)
    line_table_top = line_table_new;

  if (line_table_prev != NULL)
    {
    if (  (line_table_prev->in_block == TRUE)
       && (line_table_ptr->in_block == TRUE)
       )
      line_table_new->in_block = TRUE;
    else
      line_table_new->in_block = FALSE;
    }
  else
    line_table_new->in_block = FALSE;
  file_needs_saving = TRUE;

exit:
  ;
}

/*************************/
void updateline(int leave_trailing_spaces)
{
char * buffer_ptr;

line_table_cur = replace_line(line_table_cur,line_buffer);

if (  (strcmp(line_table_cur->text,"") == STR_SAME)
   && (line_table_cur->prev_line == NULL)
   && (line_table_cur->next_line == NULL)
   )
  {
  if (! file_empty)
    {
    file_empty = TRUE;
    restore_status(ALL_STATUS,SCREENLINES-1,FALSE);
    }
  }
else
  if (file_empty)
    {
    file_empty = FALSE;
    restore_status(ALL_STATUS,SCREENLINES-1,FALSE);
    }

line_needs_updating = FALSE;
}

/*************************/
void left()
{
if (cx > (int) strlen(line_buffer))
  cx = (int) strlen(line_buffer);

if (cx > 0)
  cx = cx - 1;
else
  {
  last_op_failed = TRUE;
  if (macro_state != MAC_NULL)
    next_mess("Could not move cursor.");
  }

cur_sx = calc_sx_str(line_buffer,cx);

if (cur_sx < vx)
  {
  if (line_needs_updating)
    updateline(LEAVE_TRAILING_SPACES);
  vx = cur_sx;
  if (vx < 0) vx = 0;
  showscreen();
  load_buffer();
  }
else
  cmove(cy,cur_sx-vx);
}

/*************************/
void right()
{
if (cx > (int) strlen(line_buffer))
  cx = (int) strlen(line_buffer);

if (cx < (int) strlen(line_buffer))
  cx = cx + 1;
else
  {
  last_op_failed = TRUE;
  if (macro_state != MAC_NULL)
    next_mess("Could not move cursor.");
  }

cur_sx = calc_sx_str(line_buffer,cx);

if (cur_sx > (vx + SCREENCOLS - 2))
  {
  if (line_needs_updating)
    updateline(LEAVE_TRAILING_SPACES);
  vx = cur_sx - SCREENCOLS + 1;
  showscreen();
  load_buffer();
  }
else
  cmove(cy,cur_sx-vx);

}

/*************************/
void scroll_left()
{

if (line_needs_updating)
  updateline(LEAVE_TRAILING_SPACES);
vx -= 1;
if (vx < 0) vx=0;
showscreen();
load_buffer();

}

/*************************/
void scroll_right()
{

cur_sx = calc_sx_str(line_buffer,cx);

if (line_needs_updating)
  updateline(LEAVE_TRAILING_SPACES);

vx += 1;

if (cur_sx < vx)
  {
  if (cx < (int) strlen(line_buffer))
    {
    cx = cx + 1;
    cur_sx = calc_sx_str(line_buffer,cx);
    }
/*
  else
    {
    vx -= 1;
    last_op_failed = TRUE;
    if (macro_state != MAC_NULL)
      next_mess("Could not move cursor.");
    }
*/
  }

showscreen();
load_buffer();

}

/*************************/
void up()
{
if (cy > 0)
  {
  if (line_table_cur->next_line == NULL)
    message_pending = 1;
  line_table_cur = line_table_cur->prev_line;
  cy = cy - 1;
  cur_sx = calc_sx_str(line_table_cur->text,cx);
  cmove(cy,cur_sx-vx);
  if (line_table_cur->prev_line == NULL)
    message_pending = 1;
  new_count = (cur_line_no - 1);
  }
else
  {
  if (line_table_top->prev_line == NULL)
    {
    last_op_failed = TRUE;
    if (macro_state != MAC_NULL)
      next_mess("Could not move cursor.");
    }
  else
    {
    if (line_table_cur->next_line == NULL)
      message_pending = 1;
    if (!scrolling)
      {
      scrolling = TRUE;
      scrollingup = TRUE;
      scrollingdown = FALSE;
      non_block_kb(1);
      }
    line_table_top = line_table_top->prev_line;
    line_table_cur = line_table_top;
    recalc_screen_cur();

    if (no_scroll)
      {
      cmove(SCREENLINES-1,0);
      clreol();
      cmove(0,0);
      ins_line();
      }
    else
      scroll_down();
    showline_mv(line_table_cur,line_table_cur->text,0,0,HILITE);
    cur_sx = calc_sx_str(line_table_cur->text,cx);
    if (line_table_cur->prev_line == NULL)
      message_pending = 1;
    new_count = (new_count - 1);
    }
  }
}

/*************************/
void up_no_upd()
{
if (line_table_cur != line_table_top)
  line_table_cur = line_table_cur->prev_line;
else
  {
  if (line_table_top->prev_line != NULL)
    {
    line_table_top = line_table_top->prev_line;
    line_table_bot = line_table_bot->prev_line;
    line_table_cur = line_table_top;
    }
  }
}

/*************************/
void down()
{
if (line_table_cur->next_line == NULL)
  {
  last_op_failed = TRUE;
  if (macro_state != MAC_NULL)
    next_mess("Could not move cursor.");
  }
else
  {
  if (cy < (SCREENLINES-2))
    {
    if (line_table_cur->prev_line == NULL)
      message_pending = 1;
    line_table_cur = line_table_cur->next_line;
    cy = cy + 1;
    cur_sx = calc_sx_str(line_table_cur->text,cx);
    cmove(cy,cur_sx-vx);
    if (line_table_cur->next_line == NULL)
      message_pending = 1;
    new_count = (new_count + 1);
    }
  else
    {
    if (line_table_bot->next_line != NULL)
      {
      if (line_table_cur->prev_line == NULL)
        message_pending = 1;
      if (!scrolling)
        {
        scrolling = TRUE;
        scrollingup = FALSE;
        scrollingdown = TRUE;
        non_block_kb(1);
        }
      line_table_bot = line_table_bot->next_line;
      line_table_top = line_table_top->next_line;
      line_table_cur = line_table_bot;

      if (no_scroll)
        {
        cmove(0,0);
        deline();
        }
      else
        {
        cmove(SCREENLINES-1,0);
        scroll_up();
        }
      showline_mv(line_table_cur,line_table_cur->text,SCREENLINES-2,0,HILITE);
      cur_sx = calc_sx_str(line_table_cur->text,cx);
      if (line_table_cur->next_line == NULL)
        message_pending = 1;
      new_count = (new_count + 1);
      }
    }
  }
}

/************************************************/
void down_no_upd()
{
if (line_table_cur->next_line != NULL)
  {
  if (line_table_cur != line_table_bot)
    line_table_cur = line_table_cur->next_line;
  else
    if (line_table_bot->next_line != NULL)
      {
      line_table_bot = line_table_bot->next_line;
      line_table_top = line_table_top->next_line;
      line_table_cur = line_table_bot;
      }
  }
}

/*************************/
void pagedown(int y)
{
int linecount = 0;
lines_paged = 0;

if (line_table_bot->next_line != NULL)
  {
  if (line_table_cur->prev_line == NULL)
    message_pending = 1;
  line_table_top = line_table_bot->next_line;
  line_table_cur = line_table_top;
  lines_paged = (y-1-cy);
  linecount = linecount + 1;
  while (  (line_table_bot->next_line != NULL)
        && (linecount < y)
        )
    {
    line_table_bot = line_table_bot->next_line;
    linecount = linecount + 1;
    }
  if (line_table_bot->next_line == NULL)
    {
    if (linecount < y)
      last_op_failed = TRUE;
    }
  }
else
  {
  last_op_failed = TRUE;
  next_mess("At end of file.");
  }
}

/*************************/
void pageup(int y)
{
int linecount = 0;

lines_paged = 0;

while (  (line_table_top->prev_line != NULL)
      && (linecount < y)
      )
  {
  if (line_table_cur->next_line == NULL)
    message_pending = 1;
  line_table_top = line_table_top->prev_line;
  line_table_bot = line_table_bot->prev_line;
  line_table_cur = line_table_top;
  linecount = linecount + 1;
  }
if (line_table_top->prev_line == NULL)
    {
    next_mess("At start of file.");
    if (linecount < y)
      last_op_failed = TRUE;
    }
lines_paged = linecount+cy;
}

/*************************/
/* a showline routine that uses cmove(x,y) at the beginning to position the
   cursor. DOES NOT write a new line at end of line */

void showline_mv(struct line_rec * line_table_ptr,
              char * text,
              int ly,
              int cx,
              int hilite_block)
{
  cmove(ly,0);
  sx = 0;
  if (  (line_table_ptr->in_block == TRUE)
     && (hilite_block)
     )
    {
    normal();
    enter_inv();
    win_reverse = A_REVERSE;
    win_blink = 0;
    win_bold = 0;
    win_standout = 0;
    win_underline = 0;
    }
  else
    {
    normal();
    win_reverse = 0;
    win_blink = 0;
    win_bold = 0;
    win_standout = 0;
    win_underline = 0;
    }
  if (*text == '\0')
    x_waddstr(" ",VX_CHECK,0,FALSE);
  else
    x_waddstr(text,VX_CHECK,0,FALSE);

  clreol();
}

/*************************/
/* a showline routine that DOES NOT use cmove(x,y) at the beginning
   to position the cursor, also writes a new line at end of line */

void showline(struct line_rec * line_table_ptr,
              char * text,
              int ly,
              int cx,
              int hilite_block)
{
  sx = 0;
  if (  (line_table_ptr->in_block == TRUE)
     && (hilite_block)
     )
    {
    normal();
    enter_inv();
    win_reverse = A_REVERSE;
    win_blink = 0;
    win_bold = 0;
    win_standout = 0;
    win_underline = 0;
    }
  else
    {
    normal();
    win_reverse = 0;
    win_blink = 0;
    win_bold = 0;
    win_standout = 0;
    win_underline = 0;
    }

  if (*text == '\0')
    x_waddstr(" ",VX_CHECK,0,FALSE);
  else
    x_waddstr(text,VX_CHECK,0,FALSE);

#ifdef MSDOS
  x_buffch(NEW_LINE);
#endif

  x_buffch('\n');
}

/*************************/
void showline_right(struct line_rec * line_table_ptr,
              char * text,
              int ly,
              int cx,
              int hilite_block)
{
  cmove(ly,cur_sx-vx);
  if (  (line_table_ptr->in_block == TRUE)
     && (hilite_block)
     )
    {
    normal();
    enter_inv();
    win_reverse = A_REVERSE;
    win_blink = 0;
    win_bold = 0;
    win_standout = 0;
    win_underline = 0;
    }
  else
    {
    normal();
    win_reverse = 0;
    win_blink = 0;
    win_bold = 0;
    win_standout = 0;
    win_underline = 0;
    }

  if (*text == '\0')
    n_waddstr(" ",VX_CHECK,cx);
  else
    n_waddstr(text,VX_CHECK,cx);

  clreol();
}

/*************************/
void show_bot_line()
{
int linecount = 0;
int newcy = 0;
struct line_rec *line_table_ptr;
struct line_rec *line_table_next;

line_table_ptr = line_table_top;

while (  (line_table_ptr != NULL)
      && (linecount <= SCREENLINES-2)
      )
  {
  if (linecount == cy)
    line_table_cur = line_table_ptr;
  line_table_next = line_table_ptr->next_line;
  if (linecount == (SCREENLINES-2))
    showline_mv(line_table_ptr,line_table_ptr->text,linecount,0,HILITE);
  line_table_bot = line_table_ptr;
  line_table_ptr = line_table_next;
  newcy = linecount;
  linecount = linecount + 1;
  }

if (line_table_cur == NULL)
  {
  line_table_cur = line_table_bot;
  cy = newcy;
  }
}

/*************************/
void showblock(int hilite)
{
int linecount = 0;
struct line_rec *line_table_ptr;
struct line_rec *line_table_next;

line_table_ptr = line_table_top;

while (  (line_table_ptr != NULL)
      && (linecount <= SCREENLINES-2)
      )
  {
  if (line_table_ptr->in_block == TRUE)
    showline_mv(line_table_ptr,line_table_ptr->text,linecount,0,hilite);

  line_table_next = line_table_ptr->next_line;
  line_table_bot = line_table_ptr;
  line_table_ptr = line_table_next;
  linecount = linecount + 1;
  }
}

/*************************/
void recalc_screen_cur()
/*
-------------
starting at line_table_top, recalc all other ptr's and
make current line the line that ends up at row cy on the screen.
-------------
*/
{
int linecount = 0;
int newcy = 0;
struct line_rec *line_table_ptr;
struct line_rec *line_table_next;

line_table_ptr = line_table_top;

line_table_cur = NULL;

while (  (line_table_ptr != NULL)
      && (linecount <= SCREENLINES-2)
      )
  {
  if (linecount == cy)
    line_table_cur = line_table_ptr;
  line_table_next = line_table_ptr->next_line;
  line_table_bot = line_table_ptr;
  line_table_ptr = line_table_next;
  newcy = linecount;
  linecount = linecount + 1;
  }

if (line_table_cur == NULL)
  {
  line_table_cur = line_table_bot;
  cy = newcy;
  }
}

/*************************/
void showscreen()

/*
-------------
display screenfull of text starting at line_table_top,
and make current line the line that ends up at row cy on the screen.
-------------
*/

{
int linecount = 0;
int newcy = 0;
struct line_rec *line_table_ptr;
struct line_rec *line_table_next;

line_table_ptr = line_table_top;

cur_sx = calc_sx_str(line_table_cur->text,cx);

/*
if (cur_sx > (vx + SCREENCOLS - 1))
  cur_sx = (vx + SCREENCOLS - 1);
else
  if (cur_sx < vx)
    {
    vx = cur_sx - (SCREENCOLS/3);
    if (vx < 0) vx = 0;
    }
*/
line_table_cur = NULL;

cmove(linecount,0);
clrscr();

while (  (line_table_ptr != NULL)
      && (linecount <= SCREENLINES-2)
      )
  {
  if (linecount <= SCREENLINES-2)
    showline(line_table_ptr,line_table_ptr->text,linecount,0,HILITE);
  if (linecount == cy)
    line_table_cur = line_table_ptr;
  line_table_next = line_table_ptr->next_line;
  line_table_bot = line_table_ptr;
  line_table_ptr = line_table_next;
  newcy = linecount;
  linecount = linecount + 1;
  flush_scr_buffer();
  }

if (line_table_cur == NULL)
  {
  line_table_cur = line_table_bot;
  cy = newcy;
  }

cur_sx = calc_sx_str(line_table_cur->text,cx);
restore_status(ALL_STATUS,SCREENLINES-1,FALSE);
}

/*************************/
void showscreen_cur()

/*
-------------
display screenfull of text starting at line_table_top,
and make current line the line that ends up at row cy on the screen,
BUT only display lines from cursor position down.
-------------
*/

{
int linecount = 0;
int newcy = 0;
struct line_rec *line_table_ptr;
struct line_rec *line_table_next;

line_table_ptr = line_table_top;

cur_sx = calc_sx_str(line_table_cur->text,cx);

/*
if (cur_sx > (vx + SCREENCOLS - 1))
  vx = cur_sx - SCREENCOLS + (SCREENCOLS/3);
else
  if (cur_sx < vx)
    {
    vx = cur_sx - (SCREENCOLS/3);
    if (vx < 0) vx = 0;
    }
*/
line_table_cur = NULL;

/*
while (  (line_table_ptr != NULL)
      && (linecount <= SCREENLINES-2)
      )
*/
while (  (line_table_ptr != NULL)
      && (linecount <= SCREENLINES-2)
      )
  {
  if (linecount >= cy)
    if (linecount <= SCREENLINES-2)
      showline_mv(line_table_ptr,line_table_ptr->text,linecount,0,HILITE);
  if (linecount == cy)
    line_table_cur = line_table_ptr;
  line_table_next = line_table_ptr->next_line;
  line_table_bot = line_table_ptr;
  line_table_ptr = line_table_next;
  newcy = linecount;
  linecount = linecount + 1;
  flush_scr_buffer();
  }

if (line_table_cur == NULL)
  {
  line_table_cur = line_table_bot;
  cy = newcy;
  }

while (linecount <= SCREENLINES-2)
  {
  cmove(linecount,0);
  clreol();
  linecount = linecount + 1;
  }

cur_sx = calc_sx_str(line_table_cur->text,cx);

cmove(cy,cur_sx-vx);

}

/************************/
void recalc_screen_cy(int y)
/*
--------
 starting at line_table_top, recalc ptr's and
 make currrent line as far down from the top to row y as possible
--------
 */
{
int linecount = 0;
struct line_rec *line_table_ptr;
struct line_rec *line_table_next;

line_table_ptr = line_table_cur;
line_table_next = line_table_ptr->prev_line;

while (  (line_table_next != NULL)
      && (linecount < y)
      )
  {
  line_table_ptr = line_table_next;
  line_table_next = line_table_ptr->prev_line;
  linecount = linecount + 1;
  }

line_table_top = line_table_ptr;
linecount = 0;

while (  (line_table_ptr != NULL)
      && (linecount <= SCREENLINES-2)
      )
  {
  if (line_table_cur == line_table_ptr)
    cy = linecount;
  line_table_next = line_table_ptr->next_line;
  line_table_bot = line_table_ptr;
  line_table_ptr = line_table_next;
  linecount = linecount + 1;
  }
}

/************************/
void showscreency(int y)
/*
--------
 show screen-full of text, with currrent line as far down from the
 top to row y as possible
--------
 */
{
int linecount = 0;
struct line_rec *line_table_ptr;
struct line_rec *line_table_next;

if (  (use_new_cy)
   && (new_cy >= 0)
   && (new_cy <= (SCREENLINES-2))
   )
  cy = new_cy;
else
  {
  line_table_ptr = line_table_cur;
  line_table_next = line_table_ptr->prev_line;

  cur_sx = calc_sx_str(line_table_cur->text,cx);

/*
  if (cur_sx > (vx + SCREENCOLS - 1))
    vx = cur_sx - SCREENCOLS + (SCREENCOLS/3);
  else
    if (cur_sx < vx)
      {
      vx = cur_sx - (SCREENCOLS/3);
      if (vx < 0) vx = 0;
      }
*/
  while (  (line_table_next != NULL)
        && (linecount < y)
        )
    {
    line_table_ptr = line_table_next;
    line_table_next = line_table_ptr->prev_line;
    linecount = linecount + 1;
    }

  line_table_top = line_table_ptr;
  linecount = 0;

  while (  (line_table_ptr != NULL)
        && (linecount <= SCREENLINES-2)
        )
    {
    if (linecount <= SCREENLINES-2)
      showline_mv(line_table_ptr,line_table_ptr->text,linecount,0,HILITE);
    if (line_table_cur == line_table_ptr)
     cy = linecount;
    line_table_next = line_table_ptr->next_line;
    line_table_bot = line_table_ptr;
    line_table_ptr = line_table_next;
    linecount = linecount + 1;
    flush_scr_buffer();
    }

  while (linecount <= SCREENLINES-2)
    {
    cmove(linecount,0);
    clreol();
    linecount = linecount + 1;
    }
  }
cur_sx = calc_sx_str(line_table_cur->text,cx);
cmove(cy,cur_sx-vx);
use_new_cy = FALSE;
new_cy = cy;
}

/************************/
void initialise()
{
int i,j,n,c;
int argerror = FALSE;
int finished = FALSE;
int tabstopvalue = 8;
int * int_ptr;
struct line_rec *line_table_new;
char temp_arg[STRINGMAX];
char * p;

struct stat fstat_buffer;

#if ( defined (CYGWIN) && defined (STATIC) )

medit_version[11] = 's';

#endif

strcpy(errortext,"finished ok.");

line_table_start = (struct line_rec *) malloc(sizeof (struct line_rec));
if (line_table_start == NULL)
  {
  strcpy(errortext,"not enough memory available");
  finish(4);
  }

line_table_start->text[0] = '\0';
line_table_start->in_block = FALSE;
line_table_start->next_line = NULL;
line_table_start->prev_line = NULL;
line_table_top = line_table_start;
line_table_cur = line_table_start;
line_table_bot = line_table_start;
line_table_end = line_table_start;
file_empty = TRUE;
last_line_deleted = NULL;

buff_table_start = buff_table_end = NULL;
line_table_block_start = line_table_block_end = NULL;

strcpy(findstr,"");
strcpy(find_text,"");
strcpy(mess_text,"");
strcpy(line_buffer,"");
strcpy(filename,"");
strcpy(keymapname,"");
strcpy(pathname,"");

strcpy(command_hist[command_end],"");

message_pending = 0;

#ifndef MSDOS
p = getenv("TERM");
if (p != NULL)
  {
  if (strcmp(p,"") == STR_SAME)
    {
    fprintf(stderr,"Your terminal type not defined (TERM variable is null).\n");
    exit(1);
    }
  }
else
  {
  fprintf(stderr,"Your terminal type not defined (TERM variable does not exist).\n");
  exit(1);
  }
#endif

setup_term();

#ifndef MSDOS

/* flush terminal input buffer & wait until no key is being pressed */

non_block_kb(0);

while ((c = x_getch()) != KB_ERR);

block_kb();

#endif

strcpy(mess_text,"");

/* ? fprintf(stderr,"%s",mess_text); */

enter_ca();

/* Once past here, we can use errortext & finish(n) on error conditions */

#ifndef MSDOS
  scr_buffer_i = 0;
  cmove(0,0);
  if (scr_buffer_i == 0)
    {
    strcpy(errortext,"Your terminal does not have cursor addressing capability.");
    finish(1);
    }
  scr_buffer_i = 0;
  ins_line();
  if (scr_buffer_i == 0)
    {
    strcpy(errortext,"Your terminal does not have 'insert line' capability.");
    finish(1);
    }
  scr_buffer_i = 0;
  scroll_down();
  if (scr_buffer_i == 0)
    {
    no_scroll = TRUE;
    }
  scr_buffer_i = 0;
  scroll_up();
  if (scr_buffer_i == 0)
    {
    no_scroll = TRUE;
    }
  scr_buffer_i = 0;
  deline();
  if (scr_buffer_i == 0)
    {
    strcpy(errortext,"Your terminal does not have 'delete line' capability.");
    finish(1);
    }
  scr_buffer_i = 0;
  clreol();
  if (scr_buffer_i == 0)
    {
    strcpy(errortext,"Your terminal does not have 'clear to end of line' capability.");
    finish(1);
    }
  scr_buffer_i = 0;
  clrscr();
  if (scr_buffer_i == 0)
    {
    strcpy(errortext,"Your terminal does not have 'clear screen' capability.");
    finish(1);
    }
  scr_buffer_i = 0;
  clrbot();
  if (scr_buffer_i == 0)
    {
    strcpy(errortext,"Your terminal does not have 'clear to bottom of screen' capability.");
    finish(1);
    }
  scr_buffer_i = 0;
#else
no_scroll = TRUE;
#endif

if (g_argc < 1)
  {
  strcpy(errortext,usage);
  finish(1);
  }

p = getenv("MEDITKEYPATH");
if (p != NULL)
  {
  strncpy(pathname,p,PATHNAME_MAX-1);
  i = 0;
  while (pathname[i] != '\0') i++;
  i--;
  if (pathname[i] != '/')
    strncat(pathname,"/",PATHNAME_MAX-1);
  }
else
  {
  strcpy(pathname,"");
  i = 0;
  while (  (g_argv[0][i] != '\0')
        && (i < (PATHNAME_MAX-1))
        )
    {
    pathname[i] = g_argv[0][i];
    i++;
    }

  pathname[i] = '\0';
  while (  (pathname[i] != '/')
        && (i >= 0)
        )
    i -= 1;
  if (i < 0)
    {
    i = 0;
    pathname[i] = '\0';
    }
  else
    if (pathname[i] == '/')
      pathname[i+1] = '\0';
  }

#ifndef MSDOS
p = getenv("TERM");
if (p != NULL)
  strncpy(termtype,p,TERMTYPE_MAX-1);
else
  strcpy(termtype,"");
#endif

j = 1;
while (  (j < g_argc)
      && (!argerror)
      && (!finished)
      )
  {
  strncpy(temp_arg,g_argv[j],STRINGMAX);
  upper_case(temp_arg);

  if (strcmp(temp_arg,"-T") == STR_SAME)
    {
    highlight_tabs = TRUE;
    j += 1;
    }
  else if (strncmp(temp_arg,"-S",2) == STR_SAME)
    {
    if (strlen(temp_arg) == 2)
       {
       j += 1;
       strncpy(temp_arg,g_argv[j],STRINGMAX);
       }
    else
       {
       shift_left_str(temp_arg,1,STRINGMAX);
       shift_left_str(temp_arg,1,STRINGMAX);
       }

    if (  (j < g_argc)
       && (temp_arg[0] != '-')
       )
      {
      if (sscanf(temp_arg,"%d",(int *) &tabstopvalue) != 1)
        {
        strcpy(errortext,"-S tabstop parameter has an invalid tabstop value.");
        argerror = TRUE;
        }
      else
        {
        if (tabstopvalue <= 0)
          {
          strcpy(errortext,"Tabstop setting must be greater than zero.");
          argerror = TRUE;
          }
        }
      j += 1;
      }
    else
      {
      strcpy(errortext,"-S tabstop parameter has no tabstop value.");
      argerror = TRUE;
      }
    }
  else if (strcmp(temp_arg,"-K") == STR_SAME)
    {
    j += 1;
    if (  (j < g_argc)
       && (g_argv[j][0] != '-')
       )
      {
      keymap = TRUE;
      strncpy(keymapname,g_argv[j],KEYMAPNAME_MAX-1);
      if (strcmp(keymapname,g_argv[j]) != STR_SAME)
        {
        sprintf(errortext,"Keymap filename > %d characters.",KEYMAPNAME_MAX-1);
        argerror = TRUE;
        }
      j += 1;
      }
    else
      {
      strcpy(errortext,"-K option had no keymap <filename>.");
      argerror = TRUE;
      }
    }
  else if (strcmp(temp_arg,"-D") == STR_SAME)
    {
    j += 1;
    debug = TRUE;
    }
  else if (strcmp(temp_arg,"-R") == STR_SAME)
    {
    j += 1;
    read_only_mode = TRUE;
    }
  else if (strcmp(temp_arg,"-?") == STR_SAME)
    {
    j += 1;
    strcpy(errortext,usage);
    finish(1);
    }
  else if (strcmp(temp_arg,"-H") == STR_SAME)
    {
    j += 1;
    strcpy(errortext,usage);
    finish(1);
    }
  else
    {
    strncpy(filename,g_argv[j],FILENAMEMAX-1);
    if (strcmp(filename,g_argv[j]) != STR_SAME)
      {
      sprintf(errortext,"Filename argument > %d characters.",FILENAMEMAX-1);
      argerror = TRUE;
      }
    finished = TRUE;
    j += 1;
    }
  }
arg_no = j;

if (argerror)
  {
  strcat(errortext,"\n\n");
  strcat(errortext,usage);
  finish(1);
  }

if (strcmp(argv0,"mread") == STR_SAME)
  {
  read_only_mode = TRUE;
  }

if (read_only_mode == TRUE)
  {
  medit_version[1]='r';
  medit_version[2]='e';
  medit_version[3]='a';
  medit_version[4]='d';
  }

if (!keymap)
  {
#ifndef MSDOS
  p = getenv("MEDIT_KEYMAPFILE");
  if (p != NULL)
    strncpy(keymapname,p,KEYMAPNAME_MAX-1);
  else
    {
#endif

    strncpy(keymapname,pathname,KEYMAPNAME_MAX-1);
    if (strcmp(termtype,"") == STR_SAME)
      strncat(keymapname,"medit.key",KEYMAPNAME_MAX-1);
    else
      {
      strncat(keymapname,"medit.key.",KEYMAPNAME_MAX-1);
      strncat(keymapname,termtype,KEYMAPNAME_MAX-1);
      }

#ifndef MSDOS
    }
#endif

  }

strcpy(file_text,"File: ");
strncat(file_text,filename,FILENAMEMAX-1);

/* Moved to immediately prior to write

p = tempnam("/tmp",NULL);
if (p == NULL)
  {
  strcpy(errortext,"Could not create temp file name - tempnam() failed\n");
  finish(1);
  }
strncpy(tempfilename,p,FILENAMEMAX-1);
*/

/* build the tab stops table */
sx = 0;
i = 1;
while (i <= (SCREENMAX-1))
  {
  sx += tabstopvalue;
  if (sx == 0)
    tabstop[i] = 32000;
  else
    tabstop[i] = sx;
  i = i + 1;
  }
/* end of tabstop code */

load_key_map();

SCREENLINES = (int)getLINES();
SCREENCOLS = (int)getCOLS();

#ifndef CYGWIN

COLS = SCREENCOLS;
LINES = SCREENLINES;

#endif

command_max = SCREENCOLS-(int)strlen(command_prompt)-1;
COMMAND_MAX = command_max;

status_fname_x = (25*(SCREENCOLS - VER_INS_LINENO_STATUS_LEN)/55) + VER_INS_LINENO_STATUS_LEN;

status_mess_len = (status_fname_x - 2) - (VER_INS_LINENO_STATUS_LEN - 1);
if (status_mess_len >= MESS_TEXT_MAX)
  status_mess_len = MESS_TEXT_MAX - 1;

if (strcmp(filename,"") == STR_SAME)
  {
  if (read_only_mode)
    {
    strcpy(errortext,"A filename must be specified.");
    finish(1);
    }
  if (message_pending < 2)
    next_mess("New file.");
  showscreen();
  strcpy(backup,"");
  }
else
  {
  readfile(filename,LOAD_FILE);
  if (read_failed)
    {
    strcpy(errortext,mess_text);
    finish(1);
    }
  }

#ifndef MSDOS
p = getenv("HOME");
if (p != NULL)
  {
  if (strcmp(p,"") == STR_SAME)
    {
    next_mess("No ~ substitution - HOME variable is null.");
    no_tilde = TRUE;
    }
  else
    {
    strncpy(home,p,PATHNAME_MAX-1);
    }
  }
else
  {
  next_mess("No ~ substitution - HOME variable not defined.");
  no_tilde = TRUE;
  }
#endif

new_count = 1;
count_lines();
lines_counted = TRUE;
message_pending = disp_mess();
strcpy(mess_text,"");

#ifdef TTSOFTBUTTON
p = getenv("TERM");
if (p != NULL)
  {
  if (strcmp(p,"ttw320") == STR_SAME)
    {
    if (strncmp(g_argv[0],"medit",6) == STR_SAME)
      printf("\033P2zS:\\MACSERV\\TEEMTALK\\TTLKWIN\\SCRIPTS\\SETBUTT.SCR(IN,MEDIT)\033\\\n");
    }
  }
#endif

}

/******************************************************************************
   Testing and setting the file write permissions flag bit.
   --------------------------------------------------------
   The flag bits for the file are in an integer. There are predifined int
   values in sys/stat.h for each of the possible file permissions (e.g. user
   write permission is S_IWUSR), and the value equals that flag bit set on
   its own.
   To test if the S_IWUSR bit is set, the file flag set is logical ANDed with
   the S_IWUSR value, and two possible values result depending on whether that
   bit is set in the file flag set:

   The bit S_IWUSR bit is set       The S_IWUSR bit is not set
               v                            v
       1010101010101010 (File flag) 0101010101010101
   AND 0000000010000000  (S_IWUSR)  0000000010000000 AND
      ------------------           ------------------
       0000000010000000  (result)   0000000000000000

   The logical AND operation only sets a bit in the result if both the
   corresponding bits are set in the two operands. So if the bit is set on in
   the file flag bit set, then the result equals the S_IWUSR, otherwise it
   equals zero.

   In the save() subroutine a similar scheme allows us to set the bit, (if we
   want to write to a read-only file), except that we use the logical OR
   operation.

   The bit S_IWUSR bit to be set    The S_IWUSR bit to be set
               v                            v
       1111111101111111 (File flag) 0000000000000000
    OR 0000000010000000  (S_IWUSR)  0000000010000000 OR
      ------------------           ------------------
       1111111111111111  (result)   0000000010000000

   The logical OR operation sets a bit in the result if either of the two
   corresponding bits are set on in the operands, otherwise it leaves the bit
   unchanged. We OR with the S_IWUSR value which has only the required bit set
   on, therefore that bit gets set but leaves the others unchanged. (If a file
   flag bit was not set, the OR will not set it as the S_IWUSR value only has
   the one bit set on. If a file flag bit was set on then it will be left set,
   logical OR never unsets bits).

   The save() subroutine must then unset the bit after writing to a read-only
   file. To do this the stat.h S_IWUSR value is 1's complemented (0's & 1's
   are flipped to the opposite value) using the ~ operator.

        S_IWUSR = 0000000010000000
       ~S_IWUSR = 1111111101111111

   The complemented value is then ANDed with the file flag bit unset:

   The S_IWUSR bit to be unset      The S_IWUSR bit to be unset
               v                            v
       1111111111111111 (File flag) 0000000010000000
   AND 1111111101111111 (~S_IWUSR)  1111111101111111 AND
      ------------------           ------------------
       1111111101111111  (result)   0000000000000000

   The way the AND operation works ensures that only the required bit gets
   unset and all the others are left unchanged.

******************************************************************************/

/*************************/
void readfile(char readfname[],int load_or_paste)
{
struct line_rec *line_table_temp;
struct line_rec *line_table_new;
struct line_rec *line_table_new_start;
struct line_rec *line_table_next;
struct line_rec *line_table_prev;
char temp_str[STRINGMAX];
char message_str[LINEMAXLEN];
int no_read_perm = FALSE;
int non_existent_file = FALSE;
int err;

struct stat fstat_buffer;
mode_t mode;

read_failed = FALSE;
text_had_nulls = FALSE;
total_chars = (total_lines = 0);

if (stat(readfname,&fstat_buffer) == -1)
  {
  if (errno == ENOENT)
    non_existent_file = TRUE;
  }
else
  {
  mode = fstat_buffer.st_mode;
  if ((mode & S_IFMT) == S_IFDIR)
    {
    strncpy(temp_str,readfname,STRINGMAX-1);
    strncat(temp_str," is a directory.",STRINGMAX-1);

    next_mess(temp_str);
    read_failed = TRUE;
    goto exit;
    }

  if ((mode & S_IFREG) != S_IFREG)
    {
    strncpy(temp_str,readfname,STRINGMAX-1);
    strncat(temp_str," is not an ordinary file.",STRINGMAX-1);
    next_mess(temp_str);
    read_failed = TRUE;
    goto exit;
    }
  }

fptr = fopen(readfname,"r");

if (fptr == NULL)
  {
  if (non_existent_file)
    {
    if (load_or_paste == PASTE_FILE)
      {
      next_mess("Non-existent file.");
      goto exit;
      }
    else
      {
      strncpy(temp_str,readfname,STRINGMAX-1);
      strncat(temp_str," does not exist.",STRINGMAX-1);

      next_mess(temp_str);
      read_failed = TRUE;
      goto exit;
      }
    }
  else
    {
    if (chmod(readfname,(mode | S_IRUSR)) != 0)
      {
      strncpy(temp_str,"Cannot get read permission on file ",STRINGMAX-1);
      strncat(temp_str,readfname,STRINGMAX-1);
      next_mess(temp_str);
      read_failed = TRUE;
      goto exit;
      }
    else
      {
      stat(readfname,&fstat_buffer);
      mode = fstat_buffer.st_mode;
      if ((mode & S_IRUSR) != S_IRUSR)
        {
        strncpy(temp_str,"Cannot get read permission on file ",STRINGMAX-1);
        strncat(temp_str,readfname,STRINGMAX-1);
        next_mess(temp_str);
        read_failed = TRUE;
        goto exit;
        }
      fptr = fopen(readfname,"r");
      if (fptr == NULL)
        {
        strncpy(temp_str,"Cannot read file ",STRINGMAX-1);
        strncat(temp_str,readfname,STRINGMAX-1);
        next_mess(temp_str);
        read_failed = TRUE;
        goto exit;
        }
      no_read_perm = TRUE;
      }
    }
  }
  err = getline2(fptr,line_buffer,LINEMAXLEN);
  if (err != UNIX_OK)
    {
    next_mess(errortext);
    fclose(fptr);
    fptr = NULL;
    read_failed = TRUE;
    goto exit;
    }
  
  total_chars = total_chars + no_of_chars;

  line_table_new_start =
    (struct line_rec *)
    malloc(sizeof (struct line_rec) + strlen(line_buffer));

  if (line_table_new_start == NULL)
    {
    next_mess("Insufficient memory.");
    fclose(fptr);
    fptr = NULL;
    read_failed = TRUE;
    goto exit;
    }
  strcpy(line_table_new_start->text,line_buffer);
  line_table_new_start->in_block = FALSE;
  line_table_new_start->prev_line = NULL;
  line_table_new_start->next_line = NULL;

  line_table_new = line_table_new_start;
  
  if (! feof(fptr))
    {
    while (! feof(fptr))
      {
      err = getline2(fptr,line_buffer,LINEMAXLEN);
      if (err != UNIX_OK)
        {
        line_table_temp = line_table_new_start;
	while (line_table_temp != NULL)
          {
          line_table_new = line_table_temp->next_line;
          free(line_table_temp);
          line_table_temp = line_table_new;
          }

        next_mess(errortext);
        fclose(fptr);
        fptr = NULL;
        read_failed = TRUE;
        goto exit;
        }
  
      if (no_of_chars > 0)
        {
        total_chars = total_chars + no_of_chars;
        line_table_next =
          (struct line_rec *)
          malloc(sizeof (struct line_rec) + strlen(line_buffer));
  
        line_table_new->next_line = line_table_next;
  
        if (line_table_next == NULL)
          {
          if (load_or_paste == PASTE_FILE)
            next_mess("Insufficient memory - PASTED FILE TRUNCATED.");
          else
            next_mess("Insufficient memory.");
          line_table_next = line_table_new;
          read_failed = TRUE;
          goto while_exit;
          }
  
        line_table_next->prev_line = line_table_new;
        line_table_next->next_line = NULL;
        line_table_next->in_block = FALSE;
        strcpy(line_table_next->text,line_buffer);
        line_table_new = line_table_next;
        }
      }
/*
    line_table_temp = line_table_new->prev_line;
    if (line_table_new != NULL)
      free(line_table_new);
    line_table_new = line_table_temp;
    line_table_new->next_line = NULL;
*/
    }

while_exit:

  line_table_prev = line_table_cur->prev_line;

  if (file_empty)
    {
    line_table_start = (line_table_top = line_table_new_start);
    free(line_table_cur);
    line_table_cur = line_table_new_start;
    line_table_bot = line_table_end = line_table_new;
    }
  else
    {
    if (line_table_prev != NULL)
      line_table_prev->next_line = line_table_new_start;
    else
      line_table_start = (line_table_top = line_table_new_start);
    line_table_new_start->prev_line = line_table_prev;
    line_table_cur->prev_line = line_table_new;
    line_table_new->next_line = line_table_cur;
    }

   if (!read_failed)
/* if (strcmp(mess_text,"") == STR_SAME) */
/* then nothing has gone wrong so far - so continue */
    {
    if (load_or_paste == PASTE_FILE)
      {
       if (!text_had_nulls)
        strcpy(message_str,"Pasted file ok. ");
      else
        strcpy(message_str,"Pasted file had NULLs. ");
      sprintf(temp_str,
             "Read %d lines, %d chars.",
              (int) total_lines,
              (int) total_chars
             );
      strcat(message_str,temp_str);
      next_mess(message_str);
      file_needs_saving = TRUE;
      }

    else
/* This is not a paste, but an initial load of a file */
      {
      if (text_had_nulls)
        strcpy(message_str,"File had NULLs. ");
      else
        strcpy(message_str,"");

      sprintf(temp_str,
             "Read %d lines, %d chars.",
              (int) total_lines,
              (int) total_chars
             );
      strcat(message_str,temp_str);
      if (message_pending < 2)
        next_mess(message_str);
      file_needs_saving = FALSE;
      }
    }

  if (no_read_perm)
    {
    /* unset the user read permissions bit */
    /* for a discussion of this see the readfile() subroutine */
    stat(readfname,&fstat_buffer);
    mode = fstat_buffer.st_mode;
    if (chmod(readfname,(mode & (~S_IRUSR))) != 0)
      next_mess("Could not reset user read permissions.");
    }

  if (total_chars > 0)
    file_empty = FALSE;
  if (  (!read_failed)
     || (load_or_paste == PASTE_FILE)
     )
    showscreency(cy);

  fclose(fptr);
  fptr = NULL;
exit:
  ;
}

/*************************
IMPORTANT - the nested if statements in here are designed to show the most
important functions first in the help screen, so that when a limited number
of lines is available on the screen the more important text is not missed out.
*/

void help()
{
int i=0;
struct key_desc_node * key_desc_ptr;
char temp_str[STRINGMAX];
char command_line_funkey[SHORTSTRINGMAX];

cmove(i,0);
clreol();

enter_inv();

x_waddstr(" Medit help - press any key to return to edit mode                             ",NO_VX_CHECK,0,FALSE);

normal();

key_desc_ptr = key_desc_table;
while (  (i < (SCREENLINES-12))
      && (key_desc_ptr != NULL)
      )
    {
    i += 1;
    cmove(i,0);
    clreol();
    if (key_desc_ptr->func_code == COMMAND_LINE)
      strcpy(command_line_funkey,key_desc_ptr->key_desc);
    sprintf(temp_str,"%s",key_desc_ptr->key_desc);
    enter_bold();
    x_waddstr(temp_str,NO_VX_CHECK,0,FALSE);
    sprintf(temp_str," - %s | ",key_desc_ptr->func_desc);
    normal();
    x_waddstr(temp_str,NO_VX_CHECK,0,FALSE);
    key_desc_ptr = key_desc_ptr->next_node;

    if (key_desc_ptr != NULL)
      {
      if (key_desc_ptr->func_code == COMMAND_LINE)
        strcpy(command_line_funkey,key_desc_ptr->key_desc);
      sprintf(temp_str,"%s",key_desc_ptr->key_desc);
      enter_bold();
      x_waddstr(temp_str,NO_VX_CHECK,0,FALSE);
      sprintf(temp_str," - %s ",key_desc_ptr->func_desc);
      normal();
      x_waddstr(temp_str,NO_VX_CHECK,0,FALSE);
      }
    else
      {
      normal();
      strcpy(temp_str,  "                                     ");
      x_waddstr(temp_str,NO_VX_CHECK,0,FALSE);
      }
    if (key_desc_ptr != NULL)
      key_desc_ptr = key_desc_ptr->next_node;
    }

while (command_line_funkey[0] == ' ')
  shift_left_str(command_line_funkey,1,STRINGMAX);

i += 1;
if (i <= SCREENLINES-2)
{
enter_inv();
cmove(i,0);
clreol();
x_waddstr(" Commands available from command line - can be abbreviated to upper-case char. ",NO_VX_CHECK,0,FALSE);

normal();
i = i + 1;

if (i <= SCREENLINES-2)
  {
  cmove(i,0);
  clreol();
  enter_bold();
  x_waddstr(" Exit [filename]",NO_VX_CHECK,0,FALSE);
  normal();
  x_waddstr(" - save and quit.        ",NO_VX_CHECK,0,FALSE);
  enter_bold();
  x_waddstr("Quit [All]",NO_VX_CHECK,0,FALSE);
  normal();
  x_waddstr(" - quit without saving.     ",NO_VX_CHECK,0,FALSE);
  i = i + 1;
  
  if (i <= SCREENLINES-2)
    {
    cmove(i,0);
    clreol();
    enter_bold();
    x_waddstr(" Open filename",NO_VX_CHECK,0,FALSE);
    normal();
    x_waddstr("   - open a new file.      ",NO_VX_CHECK,0,FALSE);
    enter_bold();
    x_waddstr("File filename",NO_VX_CHECK,0,FALSE);
    normal();
    x_waddstr("  - paste from a file.   ",NO_VX_CHECK,0,FALSE);
    i = i + 1;
    
    if (i <= SCREENLINES-2)
      {
      cmove(i,0);
      clreol();
      enter_bold();
      x_waddstr(" Write filename [Append]",NO_VX_CHECK,0,FALSE);
      normal();
      x_waddstr(" - save [append] to a new file. ",NO_VX_CHECK,0,FALSE);
      enter_bold();
      x_waddstr("Save [filename]",NO_VX_CHECK,0,FALSE);
      normal();
      x_waddstr(" - save. ",NO_VX_CHECK,0,FALSE);
      i = i + 1;
      
      if (i <= SCREENLINES-2)
        {
        cmove(i,0);
        clreol();
        enter_bold();
        x_waddstr(" 'string' [Case] [Word]",NO_VX_CHECK,0,FALSE);
        normal();
        x_waddstr(" - find string. Case = case sensitive. Word = whole word.",NO_VX_CHECK,0,FALSE);
        i = i + 1;
        
        if (i <= SCREENLINES-2)
          {
          cmove(i,0);
          clreol();
          enter_bold();
          x_waddstr(" Replace [Case] [Word] 'string1'string2' Query|All ",NO_VX_CHECK,0,FALSE);
          normal();
          x_waddstr(" - find string, and replace.",NO_VX_CHECK,0,FALSE);
          i = i + 1;
          
          if (i <= SCREENLINES-2)
            {
            cmove(i,0);
            clreol();
            enter_bold();
            x_waddstr(" eXpr'reg.expr'",NO_VX_CHECK,0,FALSE);
            normal();
            x_waddstr(" - find reg.expr",NO_VX_CHECK,0,FALSE);
            enter_bold();
            x_waddstr("   RepeXp'reg.expr'string'All",NO_VX_CHECK,0,FALSE);
            normal();
            x_waddstr(" - replace reg.expr",NO_VX_CHECK,0,FALSE);
            i = i + 1;
            
            if (i <= SCREENLINES-2)
              {
              cmove(i,0);
              clreol();
              enter_bold();
              x_waddstr(" RepeXp 'reg.expr'string' Query",NO_VX_CHECK,0,FALSE);
              normal();
              x_waddstr(" - find reg.expr, query & substitute string.",NO_VX_CHECK,0,FALSE);
              i = i + 1;
              
              if (i <= SCREENLINES-2)
                {
                cmove(i,0);
                clreol();
                x_waddstr(" RE's are caseless. Append ",NO_VX_CHECK,0,FALSE);
                enter_bold();
                x_waddstr("Case",NO_VX_CHECK,0,FALSE);
                normal();
                x_waddstr(" to make case sensitive, e.g: ",NO_VX_CHECK,0,FALSE);
                enter_bold();
                x_waddstr("RX're'string'Q C",NO_VX_CHECK,0,FALSE);
                i = i + 1;
                
                if (i <= SCREENLINES-2)
                  {
                  cmove(i,0);
                  clreol();
                  enter_bold();
                  x_waddstr(" MaceXec",NO_VX_CHECK,0,FALSE);
                  normal();
                  x_waddstr(" - Execute macro repeatedly until finished or interrupted by key press.",NO_VX_CHECK,0,FALSE);
                  i = i + 1;
                  
                  if (i <= SCREENLINES-2)
                    {
                    cmove(i,0);
                    clreol();
                    enter_bold();
                    x_waddstr(" Tab number",NO_VX_CHECK,0,FALSE);
                    normal();
                    x_waddstr(" - Set tab stops. ",NO_VX_CHECK,0,FALSE);
                    enter_bold();
                    sprintf(temp_str,"%s (function key)",command_line_funkey);
                    x_waddstr(temp_str,NO_VX_CHECK,0,FALSE);
                    normal();
                    x_waddstr(" - Goto end of command history.",NO_VX_CHECK,0,FALSE);
                    i = i + 1;
                    
                    if (i <= SCREENLINES-2)
                      {
                      cmove(i,0);
                      clreol();
                      enter_bold();
                      x_waddstr(" Cursor Up/Down",NO_VX_CHECK,0,FALSE);
                      normal();
                      x_waddstr(" - command history.",NO_VX_CHECK,0,FALSE);
                      enter_bold();
                      x_waddstr("  a number, eg 99",NO_VX_CHECK,0,FALSE);
                      normal();
                      x_waddstr(" - go to that line number.",NO_VX_CHECK,0,FALSE);
                      i = i + 1;
                      
                      if (i <= SCREENLINES-2)
                        {
                        cmove(i,0);
                        clreol();
                        enter_bold();
                        x_waddstr(" ! O.S. command",NO_VX_CHECK,0,FALSE);
                        normal();
                        x_waddstr(" - execute O.S. command. ",NO_VX_CHECK,0,FALSE);
                        enter_bold();
                        x_waddstr(" MAP",NO_VX_CHECK,0,FALSE);
                        normal();
                        x_waddstr(" - Produce keymap file.                                            ",NO_VX_CHECK,0,FALSE);
                        i = i + 1;
                        
                        if (i <= SCREENLINES-2)
                          {
                          	if ( (!copyblk_mapped) || (!deleteblk_mapped) || (!moveblk_mapped) )
                          		{
                          	    cmove(i,0);
                          	    clreol();
                          	    enter_bold();
                          	    x_waddstr(" Copy",NO_VX_CHECK,0,FALSE);
                          	    normal();
                          	    x_waddstr(" - copy block.        ",NO_VX_CHECK,0,FALSE);
                          	    enter_bold();
                          	    x_waddstr("Move",NO_VX_CHECK,0,FALSE);
                          	    normal();
                          	    x_waddstr(" - move block.        ",NO_VX_CHECK,0,FALSE);
                          	    enter_bold();
                          	    x_waddstr("Delete",NO_VX_CHECK,0,FALSE);
                          	    normal();
                          	    x_waddstr(" - delete block.    ",NO_VX_CHECK,0,FALSE);
                          	    i = i + 1;
                          		}
                          
                          if (i <= SCREENLINES-2)
                            {
                            if ( (!pasteblk_mapped) || (!markblk_mapped) )
                              {
                              cmove(i,0);
                              clreol();
                              enter_bold();
                              x_waddstr(" Paste",NO_VX_CHECK,0,FALSE);
                              normal();
                              x_waddstr(" - paste contents of buffer.                   ",NO_VX_CHECK,0,FALSE);
                              enter_bold();
                              x_waddstr("Block",NO_VX_CHECK,0,FALSE);
                              normal();
                              x_waddstr("  - mark block.      ",NO_VX_CHECK,0,FALSE);
                              i = i + 1;
                              }
                            
                            if (i <= SCREENLINES-2)
                              {
                              if ( (!macro_replay_mapped) || (!macro_define_mapped) )
                                {
                                cmove(i,0);
                                clreol();
                                enter_bold();
                                x_waddstr(" MAC",NO_VX_CHECK,0,FALSE);
                                normal();
                                x_waddstr(" - replay macro.                 ",NO_VX_CHECK,0,FALSE);
                                enter_bold();
                                x_waddstr("MacDef",NO_VX_CHECK,0,FALSE);
                                normal();
                                x_waddstr(" - define macro.                    ",NO_VX_CHECK,0,FALSE);
                                i = i + 1;
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}

while(i <= SCREENLINES-2)
  {
  /* i += 1; */
  cmove(i,0);
  clreol();
  x_waddstr("                                                                               ",NO_VX_CHECK,0,FALSE);
  i += 1;
  }

i = decode_key();

showscreen();

/* restore_status(ALL_STATUS,SCREENLINES-1,FORCE); */
}




/*************************/
void ctrl_char_help()
{
int i=0;

enter_bold();
enter_inv();
cmove(i,0);
clreol();
x_waddstr("       Medit help - press any key to return to control character mode          ",NO_VX_CHECK,0,FALSE);

normal();
enter_bold();

i += 1;
cmove(i,0);
clreol();
x_waddstr("                                                                               ",NO_VX_CHECK,0,FALSE);
i = i + 1;
cmove(i,0);
clreol();
x_waddstr("You can enter control characters in one of two ways:                           ",NO_VX_CHECK,0,FALSE);
i += 1;
cmove(i,0);
clreol();
x_waddstr("                                                                               ",NO_VX_CHECK,0,FALSE);
i = i + 1;
cmove(i,0);
clreol();
x_waddstr("1. Press the CTRL key and a letter simultaneously e.g. <CTRL><A>               ",NO_VX_CHECK,0,FALSE);
i += 1;
cmove(i,0);
clreol();
x_waddstr("                                                                               ",NO_VX_CHECK,0,FALSE);
i = i + 1;
cmove(i,0);
clreol();
x_waddstr("2. Type the ASCII code of the control character in decimal, e.g. 26 for Ctrl-Z.",NO_VX_CHECK,0,FALSE);
i += 1;
cmove(i,0);
clreol();
x_waddstr("                                                                               ",NO_VX_CHECK,0,FALSE);
i = i + 1;
cmove(i,0);
clreol();
x_waddstr("Note that option 2 must be used in the certain cases:                          ",NO_VX_CHECK,0,FALSE);
i = i + 1;
cmove(i,0);
clreol();
x_waddstr("Ascii codes > 126; Ctrl-H (used to delete typing errors); certain control     ",NO_VX_CHECK,0,FALSE);
i += 1;
cmove(i,0);
clreol();
x_waddstr("that are removed by the operating system, e.g. Ctrl-S, Q and M under Unix.     ",NO_VX_CHECK,0,FALSE);
i += 1;
cmove(i,0);
clreol();
x_waddstr("                                                                               ",NO_VX_CHECK,0,FALSE);
i = i + 1;
cmove(i,0);
clreol();
x_waddstr("The following character codes are not allowed:                                 ",NO_VX_CHECK,0,FALSE);
i = i + 1;
cmove(i,0);
clreol();
x_waddstr("0 (null), 10 (new line), any code > 255                                        ",NO_VX_CHECK,0,FALSE);
i += 1;
cmove(i,0);
clreol();
x_waddstr("To enter a newline character, press RETURN while in edit mode!                 ",NO_VX_CHECK,0,FALSE);
i += 1;
cmove(i,0);
clreol();
x_waddstr("                                                                               ",NO_VX_CHECK,0,FALSE);
i += 1;
cmove(i,0);
clreol();
x_waddstr("More than one control character can be entered with this format, but there must",NO_VX_CHECK,0,FALSE);
i = i + 1;
cmove(i,0);
clreol();
x_waddstr("be at least one space between adjacent control characters entered as a decimal ",NO_VX_CHECK,0,FALSE);
i = i + 1;
cmove(i,0);
clreol();
x_waddstr("character code; e.g. <Ctrl-A>2<space>3<Ctrl-D>                                 ",NO_VX_CHECK,0,FALSE);
i = i + 1;
cmove(i,0);
clreol();
x_waddstr("                                                                               ",NO_VX_CHECK,0,FALSE);
i += 1;
cmove(i,0);
clreol();
x_waddstr("To correct typing errors, use the <Backspace> key or Ctrl-H to backspace.      ",NO_VX_CHECK,0,FALSE);
i += 1;
cmove(i,0);
clreol();
x_waddstr("                                                                               ",NO_VX_CHECK,0,FALSE);
i = i + 1;
cmove(i,0);
clreol();
x_waddstr("Press RETURN to enter the control character(s).                                ",NO_VX_CHECK,0,FALSE);

while(i < SCREENLINES-2)
  {
  i += 1;
  cmove(i,0);
  clreol();
  x_waddstr("                                                                               ",NO_VX_CHECK,0,FALSE);
  }

i = decode_key();

showscreen();
restore_status(ALL_STATUS,SCREENLINES-1,FORCE);
}

/******************************/
void next_mess(char message[])
{
strncpy(mess_text,message,MESS_TEXT_MAX);
message_pending = 2;
}

/**************************************/
void restore_status(int update_what,int y,int force)
{
char temp_str[82];

if (  (message_pending < 1)
   || (force)
   )
  {
  if (!scrolling)
    {
    normal();
    enter_bold();
    status_blink = 0;
    status_bold = A_BOLD;
    status_standout = 0;
    status_reverse = 0;
    status_underline = 0;

    if (update_what == ALL_STATUS)
      {
      cmove(y,0);
      clreol();
      s_waddstr(medit_version,NO_VX_CHECK,0,0,SCREENCOLS-2,FALSE);
      }

    if (  (SCREENCOLS > 13)
       && (update_what != LINE_NO_ONLY)
       )
      {
      cmove(y,13);
      if (insert_mode)
        s_waddstr("Ins  ",NO_VX_CHECK,0,13,SCREENCOLS-2,FALSE);
      else
        s_waddstr("Ovr  ",NO_VX_CHECK,0,13,SCREENCOLS-2,FALSE);
      }

    if (  (SCREENCOLS > 18)
       && (update_what != INS_OVR_ONLY)
       )
      {
      cmove(y,18);
      sprintf(temp_str,"%5d:%4d",(int) (int) cur_line_no,cx+1);
      s_waddstr(temp_str,NO_VX_CHECK,0,18,SCREENCOLS-2,FALSE);
      }

    if (update_what == ALL_STATUS)
      {
      if (SCREENCOLS > 29)
        {
        cmove(y,29);
        clreol();
        if (strcmp(mess_text,"") != STR_SAME)
          {
          normal();
          enter_blink();
          status_blink = A_BLINK;
          status_bold = 0;
          status_standout = 0;
          status_reverse = 0;
          status_underline = 0;

          s_waddstr(mess_text,NO_VX_CHECK,0,29,SCREENCOLS-2,FALSE);

          normal();
          enter_bold();
          status_bold = A_BOLD;
          status_blink = 0;
          }
        else
          {
          if (power_failure)
            {
            normal();
            enter_blink();
            s_waddstr("POWER FAILURE- save and exit!",NO_VX_CHECK,0,29,SCREENCOLS-2,FALSE);
            normal();
            enter_bold();
            }
          else if (macro_state == DEFINE)
            {
            normal();
            enter_blink();
            s_waddstr("Defining macro.",NO_VX_CHECK,0,29,SCREENCOLS-2,FALSE);
            normal();
            enter_bold();
            }
          else if (file_empty)
            {
            s_waddstr("Empty file.",NO_VX_CHECK,0,29,SCREENCOLS-2,FALSE);
            }
          else if (block_marked)
            {
            normal();
            enter_blink();
            s_waddstr("Block marked.",NO_VX_CHECK,0,29,SCREENCOLS-2,FALSE);
            normal();
            enter_bold();
            }
          else if (line_table_cur->next_line == NULL)
            {
            normal();
            enter_blink();
            s_waddstr("At end of file.",NO_VX_CHECK,0,29,SCREENCOLS-2,FALSE);
            normal();
            enter_bold();
            }
          else if (line_table_cur->prev_line == NULL)
            {
            normal();
            enter_blink();
            s_waddstr("At start of file.",NO_VX_CHECK,0,29,SCREENCOLS-2,FALSE);
            normal();
            enter_bold();
            }
          else if ((int)strlen(find_text) > 0)
            {
            s_waddstr(find_text,NO_VX_CHECK,0,29,SCREENCOLS-2,FALSE);
            }
          else
            {
            s_waddstr("                        ",NO_VX_CHECK,0,29,SCREENCOLS-2,FALSE);
            }
          }
        }
      }
    if (  (update_what == ALL_STATUS)
       && (((int)strlen(mess_text)) <= status_mess_len)
       )
      {
      if (SCREENCOLS > status_fname_x)
        {
        cmove(y,status_fname_x);
        clreol();
        s_waddstr(file_text,NO_VX_CHECK,0,status_fname_x,SCREENCOLS-2,FALSE);
        }
      }
    }
  }
normal();
cmove(cy,cur_sx-vx);

}

/***********************/
void count_lines()
{
struct line_rec *line_table_ptr;
struct line_rec *table_next;

if (macexec)
	{
	return;
	}

new_count = 1;

line_table_ptr = line_table_start;
while	(	(line_table_ptr->next_line != NULL)
		&&	(line_table_ptr != line_table_cur)
		)
	{
	line_table_ptr = line_table_ptr->next_line;
	new_count += 1;
	}

if (  (new_count == 1)
	 && (file_empty)
	 )
	new_count = 0;

lines_counted = TRUE;
}

/******************************/
int disp_mess()
{
int result;

if (  (scrolling)
   || (macro_state == REPLAY)
   )
  {
  normal();
  cmove(cy,cur_sx-vx);
  return message_pending;
  }

if (message_pending > 0)
  result = (message_pending-1);
else
  result = message_pending;

if (new_count != cur_line_no)
  cur_line_no = new_count;

/* lines_counted = FALSE; */

restore_status(ALL_STATUS,SCREENLINES-1,FORCE);

normal();
cmove(cy,cur_sx-vx);

strcpy(mess_text,"");
return result;
}

/*******************************/
void finish(int errcode)
{
char * p;

normal();

empty_buffer();

empty_memory();
free(line_table_start);
free(macro_def_prev);
free(macro_def_table);

if (fptr != NULL)
  fclose(fptr);

clrbot();

flush_scr_buffer();

exit_ca();
unset_term();

fprintf(stderr,"\n\nMedit: ");
fprintf(stderr,"%s",errortext);
fprintf(stderr,"\n\n");

#ifdef TTSOFTBUTTON
p = getenv("TERM");
if (p != NULL)
  {
  if (strcmp(p,"ttw320") == STR_SAME)
    if (strncmp(g_argv[0],"medit",6) == STR_SAME)
      printf("\033P2zS:\\MACSERV\\TEEMTALK\\TTLKWIN\\SCRIPTS\\SETBUTT.SCR(OUT)\033\\\n");
  }
#endif

exit(errcode);
}

/* Unix version */
/*******************************/
int rename_file(FILE *tempf, FILE *origf)
{
char c;
int error;

c = getc(tempf);
while (  (!feof(tempf))
      && (! (error = ferror(tempf)))
      )
  {
  putc(c,origf);
  if (error = ferror(origf)) goto error_exit;
  c = getc(tempf);
  }

if (error = ferror(tempf)) goto error_exit;

return 0;

error_exit:

  return error;
}

/*******************************/
void display(char * mess, int pause)
/* This function is for debugging purposes. */
{
int c;

cmove(SCREENLINES-1,VER_INS_LINENO_STATUS_LEN);
clreol();

normal();
enter_blink();
s_waddstr(mess,NO_VX_CHECK,0,25,SCREENCOLS-2,FALSE);
normal();
enter_bold();

flush_scr_buffer();

if (message_pending == 0)
  message_pending = 1;

if (pause)
#ifndef MSDOS
    temp_error = system("sleep 3");
#else
    delay(3000);
#endif

cmove(cy,cur_sx-vx);
}

/*******************************/
int getline2(FILE *stream,char s[],int line_max)
  {
  int i,result;
  char c;

  i=0;
  s[i] = '\0';
  no_of_chars = 0;

  do
    {
    temp_error = fread(&s[i],(size_t) 1,(size_t) 1,stream);
    if (ferror(stream))
      {
      sprintf(errortext,"%s while reading file '%s'",strerror(errno),filename);
      return (!UNIX_OK);
      }


    if (! feof(stream))
      {
      c = s[i];
      if (c != '\0')
        {
        no_of_chars++;
        if (c != '\n')
          i++;
        else
          s[i] = '\0';
        }
      else
        text_had_nulls = TRUE;
      }
    else
      {
      c = '\0';
      s[i] = '\0';
      }
    }
  while  (  (i < line_max-1)
         && (! feof(stream))
         && (c != '\n')
         );

  if (  (! feof(stream))
     || (i != 0)
     )
     total_lines = total_lines + 1;

  if (i >= line_max-1)
    {
    sprintf(errortext,
           "one or more lines are > %d characters long",
           line_max-1);
    return (!UNIX_OK);
    }

return UNIX_OK;
}
