
if [ -z "${1}" ]
then
	echo "version-number parameter missing"
	echo "Usage: ${0} <version>"
	exit
fi

./clean-medit.sh
cd pcre-6.7-barebones
./clean-pcre.sh
./compile-pcre.sh
cd ..
./copy-pcre.sh
./compile-medit.sh ${1}

