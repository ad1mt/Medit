/*****************************************************************************
MEDIT.H
------------------------------------------------------------------------------
Medit - include file.
*****************************************************************************/

#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <signal.h>
#include <setjmp.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#ifdef MSDOS
#include <termios.h>
#endif
#ifdef  CYGWIN
#include <ncurses/curses.h>
#endif

#ifndef FALSE
#define FALSE (0)
#endif

#ifndef TRUE
#define TRUE (!FALSE)
#endif

#define KB_ERR (-1)
#define SCREENMAX (82)

#define STR_SAME 0
#define STR_NOT_SAME 1

#ifndef MSDOS
#  define LINE100K
#endif

#ifdef LINE100K
  #define LINEMAXLEN (131072)
#else
  #define LINEMAXLEN (20480)
#endif
#define SCR_BUFFER_LEN (1024)

#define ERRORTEXT_MAX LINEMAXLEN
extern char errortext[ERRORTEXT_MAX];

extern int scr_buffer_i;
extern char scr_buffer[SCR_BUFFER_LEN];

extern int macexec;

extern int temp_error;

#ifdef CYGWIN

enum COLORNAMES {
    BLACK,		    /* dark colors */
    RED,
    GREEN,
    YELLOW,
    BLUE,
    MAGENTA,
    CYAN,
    WHITE
};
#endif


#ifdef MICROSOFT

extern void clrscr();

enum COLORNAMES {
    BLACK,		    /* dark colors */
    BLUE,
    GREEN,
    CYAN,
    RED,
    MAGENTA,
    BROWN,
    LIGHTGRAY,
    DARKGRAY,		    /* light colors */
    LIGHTBLUE,
    LIGHTGREEN,
    LIGHTCYAN,
    LIGHTRED,
    LIGHTMAGENTA,
    YELLOW,
    WHITE
};
#endif

/*
#ifndef A_REVERSE
#define A_REVERSE 0x00040000
#endif

#ifndef A_BOLD
#define A_BOLD    0x00200000
#endif

#ifndef A_UNDERLINE
#define A_UNDERLINE 0x00020000
#endif

#ifndef A_BLINK
#define A_BLINK 0x00010000
#endif
*/

#define badsig -1

#define SCREENMAX (82)
#define STRINGMAX (16384)
#define SHORTSTRINGMAX (256)
#define VER_INS_LINENO_STATUS_LEN 29
#define ERRORTEXT_MAX LINEMAXLEN
#define MESS_TEXT_MAX SCREENMAX
#define FINDSTR_MAX STRINGMAX
#define FIND_TEXT_MAX SCREENMAX
#define FILENAMEMAX STRINGMAX
#define KEYMAPNAME_MAX STRINGMAX
#define PATHNAME_MAX STRINGMAX
#define TERMTYPE_MAX STRINGMAX
#define FILE_TEXT_MAX STRINGMAX
#define PREV_COMMAND_MAX STRINGMAX
#define LINE_BUFFER_MAX LINEMAXLEN
#define FILE_BUFFER_MAX (10240)
#define TEMP_STR_MAX LINEMAXLEN
#define TABSTOP_MAX SCREENMAX


#define FORWARDS TRUE
#define BACKWARDS FALSE
#define FROM_DELETEBLOCK TRUE
#define NOT_FROM_DELETEBLOCK FALSE
#define NOT_IN_STR NULL
#define SAVE_FILE_FLAG FALSE
#define SAVE_BLOCK_FLAG TRUE
#define CASE_SENS TRUE
#define NOT_CASE_SENS FALSE
#define ALL_STATUS 0
#define LINE_NO_ONLY 1
#define INS_OVR_ONLY 2
#define DELETE_OLD TRUE
#define LEAVE_OLD FALSE
#define UNIX_OK 0
#define LOAD_FILE 0
#define PASTE_FILE 1
#define FUNKEYS_ALLOWED TRUE
#define NO_FUNKEYS FALSE
#define SAVE_COMMAND TRUE
#define NO_SAVE FALSE
#define SQUASH_SPACES TRUE
#define NO_SQUASH FALSE
#define QUOTED TRUE
#define NOT_QUOTED FALSE
#define CTRL_ALLOWED TRUE
#define NO_CTRL FALSE
#define TAB_ENDS_INPUT TRUE
#define NO_TAB_ENDS_INPUT FALSE
#define FROM_MOVEBLOCK TRUE
#define NOT_FROM_MOVEBLOCK FALSE
#define TRUNC_TRAILING_SPACES FALSE
#define LEAVE_TRAILING_SPACES TRUE
#define NO_VX_CHECK TRUE
#define VX_CHECK FALSE
#define SAME_LEVEL (TRUE)
#define NEXT_LEVEL (FALSE)
#define FOREVER (TRUE)
#define PAUSE (TRUE)
#define NO_PAUSE (FALSE)
#define HILITE (TRUE)
#define NO_HILITE (FALSE)
#define KB_ERR (-1)
#define MAC_NULL (0)
#define DEFINE (1)
#define REPLAY (2)
#define MACEXEC (3)
#define FORCE (TRUE)
#define NO_FORCE (FALSE)
#define IN_BLOCK (1)

#ifndef MSDOS
#ifndef SIG_IGN
#define SIG_IGN (1)
#endif

#define sigHUP  1       /* hangup */

#define sigINT  2       /* interrupt (rubout) */
#define sigQUIT 3       /* quit (ASCII FS) */
#define sigILL  4       /* illegal instruction (not reset when caught) */
#define sigTRAP 5       /* trace trap (not reset when caught) */
#define sigSEGV 11      /* segmentation violation */
#define sigIOT  6       /* IOT instruction */
#define sigABRT 6       /* used by abort, replace SIGIOT in the future */
#define sigEMT  7       /* EMT instruction */
#define sigFPE  8       /* floating point exception */
#define sigKILL 9       /* kill (cannot be caught or ignored) */
#define sigBUS  10      /* bus error */
#define sigSYS  12      /* bad argument to system call */
#define sigPIPE 13      /* write on a pipe with no one to read it */
#define sigALRM 14      /* alarm clock */
#define sigTERM 15      /* software termination signal from kill */
#define sigUSR1 16      /* user defined signal 1 */
#define sigUSR2 17      /* user defined signal 2 */
#define sigCLD  18      /* child status change */
#define sigCHLD 18      /* child status change alias (POSIX) */
#define sigPWR  19      /* power-fail restart */
#define sigWINCH 20     /* window size change */
#define sigURG  21      /* urgent socket condition */
#define sigPOLL 22      /* pollable event occured */
#define sigIO   sigPOLL /* socket I/O possible (SIGPOLL alias) */
#define sigSTOP 23      /* stop (cannot be caught or ignored) */
#define sigTSTP 24      /* user stop requested from tty */
#endif

/* ASCII codes */

#define CHAR_NULL  0
#define CHAR_TAB   9
#define CHAR_SPACE 32
#define CHAR_DEL   127
#define CHAR_255   255

/* Standard key escape sequences */

#define KB_BACKSPACE  8
#define KB_TAB        9
#define KB_NEW_LINE  10
#define KB_RETURN    13

#ifdef MSDOS

#define KB_DEL      183
#define KB_F1       159
#define KB_F2       160
#define KB_F3       161
#define KB_F4       162
#define KB_F5       163
#define KB_F6       164
#define KB_F7       165
#define KB_F8       166
#define KB_F9       167
#define KB_F10      168
#define KB_F11      233
#define KB_F12      234
#define KB_UP       172
#define KB_DOWN     180
#define KB_LEFT     175
#define KB_RIGHT    177
#define KB_INS      182
#define KB_DEL      183
#define KB_HOME     171
#define KB_END      179
#define KB_PGUP     173
#define KB_PGDN     181
#define KB_CTRL_DEL 247
#define KB_SHIFT_F7 190
#define KB_SHIFT_F8 191
#define KB_CTRL_F8  201
#define KB_CTRL_HOME 219
#define KB_CTRL_END 217

#else

#define KB_DEL      127

#endif

#define KB_CTRL_A  1
#define KB_CTRL_B  2
#define KB_CTRL_C  3
#define KB_CTRL_D  4
#define KB_CTRL_E  5
#define KB_CTRL_F  6
#define KB_CTRL_G  7
#define KB_CTRL_H  8
#define KB_CTRL_I  9
#define KB_CTRL_J  10
#define KB_CTRL_K  11
#define KB_CTRL_L  12
#define KB_CTRL_M  13
#define KB_CTRL_N  14
#define KB_CTRL_O  15
#define KB_CTRL_P  16
#define KB_CTRL_Q  17
#define KB_CTRL_R  18
#define KB_CTRL_S  19
#define KB_CTRL_T  20
#define KB_CTRL_U  21
#define KB_CTRL_V  22
#define KB_CTRL_W  23
#define KB_CTRL_X  24
#define KB_CTRL_Y  25
#define KB_CTRL_Z  26

/*
   BACKSPACE & NEWLINE & TAB MUST HAVE COMMAND CODES = ASCII CODES
   SO THAT THEY DEFAULT TO THE CORRECT VALUE IF UN-MAPPED
*/
#define BACKSPACE     KB_BACKSPACE
#define TAB           KB_TAB

#ifdef MSDOS
#define NEW_LINE      KB_RETURN
#else
#define NEW_LINE      KB_NEW_LINE
#endif

#define COMMAND_LINE 1001
#define CLEAR_LINE 1002
#define PAGEUP     1003
#define PAGEDOWN   1004
#define START_LINE 1005
#define END_LINE   1006
#define HELP       1007
#define MARK_BLOCK 1008
#define COPY_BLOCK 1009
#define MOVE_BLOCK 1010
#define DEL_LINE   1011
#define FIND_FOR   1012
#define FIND_BACK  1013
#define START_FILE 1014
#define END_FILE   1015
#define CLEAR_MARK 1016
#define DEL_BLOCK  1017
#define PASTE_BLOCK 1018
#define CONTROL_CHAR 1019
#define TOGGLE_INS   1020
#define DEL_CHAR     1021
#define CURSOR_UP    1022
#define CURSOR_DOWN  1023
#define CURSOR_LEFT  1024
#define CURSOR_RIGHT 1025
#define DEFINE_MACRO 1026
#define REPLAY_MACRO 1027
#define TOGGLE_CASE  1028
#define W_TOGGLE_CASE 1029
#define MOVE_TO_WORD 1030
#define BACK_TO_WORD 1031
#define SCROLL_RIGHT 1032
#define SCROLL_LEFT  1033
#define UNDELETE_LINE 1034
#define GOTO_MARKED_BLOCK 1035
#define SAVE_FILE_FUNCTION 1036
#define NO_COMMAND   0

